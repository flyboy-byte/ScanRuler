import { create } from "zustand";
create(() => ({ running: null, progress: null }));
const busyChecks = /* @__PURE__ */ new Map();
const busyStores = /* @__PURE__ */ new Map();
const busyStops = /* @__PURE__ */ new Map();
function registerBusy(id, check, stores = [], stop) {
  if (busyChecks.has(id)) throw new Error(`Two busy checks share the id "${id}".`);
  busyChecks.set(id, check);
  busyStores.set(id, stores);
  if (stop) busyStops.set(id, stop);
  return () => {
    if (busyChecks.get(id) !== check) return;
    busyChecks.delete(id);
    busyStores.delete(id);
    busyStops.delete(id);
  };
}
async function stopPluginWork(done) {
  const stops = [];
  for (const [id, stop] of busyStops) {
    try {
      if (busyChecks.get(id)?.()) stops.push(stop(done).catch(() => {
      }));
    } catch {
    }
  }
  await Promise.all(stops);
}
export {
  busyChecks,
  busyStops,
  busyStores,
  registerBusy,
  stopPluginWork
};
//# sourceMappingURL=activity.mjs.map
