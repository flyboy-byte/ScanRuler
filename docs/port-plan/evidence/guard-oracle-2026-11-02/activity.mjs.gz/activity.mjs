import { create } from "zustand";
create(() => ({ running: null, progress: null }));
const FREE = { busy: () => null };
let guard = FREE;
function configureCommands(next) {
  guard = next;
  return () => {
    guard = FREE;
  };
}
const commandGuard = () => guard;
export {
  commandGuard,
  configureCommands
};
//# sourceMappingURL=activity.mjs.map
