import { create } from "zustand";
const ELEMENT_KINDS = [
  { id: "point", label: "Point", noun: "point" },
  { id: "line", label: "Line", noun: "line" },
  { id: "plane", label: "Plane", noun: "plane" },
  { id: "sphere", label: "Sphere", noun: "sphere" },
  { id: "cylinder", label: "Cylinder", noun: "cylinder" },
  { id: "cone", label: "Cone", noun: "cone" },
  { id: "circle", label: "Circle", noun: "circle" },
  { id: "torus", label: "Torus", noun: "round" }
];
function elementKindInfo(id) {
  const info = ELEMENT_KINDS.find((k) => k.id === id);
  if (!info) throw new Error(`Unknown element type "${id}".`);
  return info;
}
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [
  a[1] * b[2] - a[2] * b[1],
  a[2] * b[0] - a[0] * b[2],
  a[0] * b[1] - a[1] * b[0]
];
const len = (a) => Math.hypot(a[0], a[1], a[2]);
const scale = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const addScaled = (a, b, s) => [
  a[0] + b[0] * s,
  a[1] + b[1] * s,
  a[2] + b[2] * s
];
const mid = (a, b) => [
  (a[0] + b[0]) / 2,
  (a[1] + b[1]) / 2,
  (a[2] + b[2]) / 2
];
function normalize(a) {
  const l = len(a);
  if (l < 1e-12) return null;
  return [a[0] / l, a[1] / l, a[2] / l];
}
function acuteAngle(a, b) {
  const c = Math.min(1, Math.abs(dot(a, b)));
  return Math.acos(c) * 180 / Math.PI;
}
function footOnLine(point, origin, dir) {
  return addScaled(origin, dir, dot(sub(point, origin), dir));
}
function solveLinear(n, a, b) {
  let maxAbs = 0;
  for (let i = 0; i < n * n; i++) maxAbs = Math.max(maxAbs, Math.abs(a[i]));
  const tiny = Math.max(maxAbs, 1) * 1e-13;
  const x = b.slice();
  for (let col = 0; col < n; col++) {
    let pivotRow = col;
    let best = Math.abs(a[col * n + col]);
    for (let r = col + 1; r < n; r++) {
      const v = Math.abs(a[r * n + col]);
      if (v > best) {
        best = v;
        pivotRow = r;
      }
    }
    if (best < tiny) return null;
    if (pivotRow !== col) {
      for (let c = col; c < n; c++) {
        const t2 = a[col * n + c];
        a[col * n + c] = a[pivotRow * n + c];
        a[pivotRow * n + c] = t2;
      }
      const t = x[col];
      x[col] = x[pivotRow];
      x[pivotRow] = t;
    }
    const piv = a[col * n + col];
    for (let r = col + 1; r < n; r++) {
      const f = a[r * n + col] / piv;
      if (f === 0) continue;
      for (let c = col; c < n; c++) a[r * n + c] -= f * a[col * n + c];
      x[r] -= f * x[col];
    }
  }
  for (let row = n - 1; row >= 0; row--) {
    let s = x[row];
    for (let c = row + 1; c < n; c++) s -= a[row * n + c] * x[c];
    x[row] = s / a[row * n + row];
  }
  return x;
}
function normalizeOrZ(v) {
  const len3 = Math.hypot(v[0], v[1], v[2]);
  if (!(len3 > 1e-20)) return [0, 0, 1];
  return [v[0] / len3, v[1] / len3, v[2] / len3];
}
function orthoBasis(n) {
  const ax = Math.abs(n[0]);
  const ay = Math.abs(n[1]);
  const az = Math.abs(n[2]);
  const helper = ax <= ay && ax <= az ? [1, 0, 0] : ay <= az ? [0, 1, 0] : [0, 0, 1];
  const u = normalizeOrZ(cross(n, helper));
  const v = normalizeOrZ(cross(n, u));
  return [u, v];
}
const MM_PER_INCH = 25.4;
function lengthDecimals(mmDecimals, units) {
  return units === "in" ? Math.max(3, mmDecimals + 1) : mmDecimals;
}
function unitWord(units, power = 1) {
  return units + (power === 2 ? "²" : power === 3 ? "³" : "");
}
function fixed(v, decimals, signed) {
  const text = v.toFixed(decimals);
  if (Number(text) === 0) return 0 .toFixed(decimals);
  return signed && v > 0 ? `+${text}` : text;
}
function fmt(value, units, mmDecimals, power, opts) {
  const text = fixed(value / (units === "in" ? MM_PER_INCH ** power : 1), lengthDecimals(mmDecimals, units), opts?.signed ?? false);
  return opts?.bare ? text : `${text} ${unitWord(units, power)}`;
}
function fmtLen(mm, units, mmDecimals = 3, opts) {
  return fmt(mm, units, mmDecimals, 1, opts);
}
const ROLE_PROVIDERS = {
  point: ["point", "sphere", "circle"],
  axis: ["line", "cylinder", "cone", "circle", "torus"],
  plane: ["plane"]
};
function providesRole(kind, role) {
  return ROLE_PROVIDERS[role].includes(kind);
}
function roleOf(kind) {
  if (kind === "plane") return "plane";
  if (kind === "line" || kind === "cylinder" || kind === "cone" || kind === "torus") return "axis";
  return "point";
}
function slotTakes(slot, kind) {
  return slot.roles.some((role) => providesRole(kind, role)) && (!slot.kinds || slot.kinds.includes(kind));
}
function refPoint(fit) {
  return fit.kind === "point" || fit.kind === "sphere" || fit.kind === "circle" ? fit.center : null;
}
function refAxis(fit) {
  if (fit.kind === "cylinder" || fit.kind === "cone")
    return { origin: fit.center, dir: fit.axis, halfLength: fit.length / 2 };
  if (fit.kind === "line") return { origin: fit.center, dir: fit.dir, halfLength: fit.length / 2 };
  if (fit.kind === "torus") return { origin: fit.center, dir: fit.axis, halfLength: fit.minorRadius };
  if (fit.kind === "circle") return { origin: fit.center, dir: fit.normal, halfLength: fit.radius };
  return null;
}
function refPlane(fit) {
  return fit.kind === "plane" ? fit : null;
}
class ConstructionError extends Error {
}
const found = (p) => ({ ...p, hidden: true });
function takesSurface(m) {
  return m.mode === "fit" || m.surface === true;
}
const XYZ = [
  { key: "x", label: "X", unit: "mm" },
  // units-ok: an id
  { key: "y", label: "Y", unit: "mm" },
  // units-ok: an id
  { key: "z", label: "Z", unit: "mm" }
  // units-ok: an id
];
const CREATION_METHODS = [
  // ---- Point ---------------------------------------------------------------
  {
    id: "pick",
    kind: "point",
    mode: "pick",
    label: "Pick on scan",
    hint: "Click the point on the scan you want to measure to.",
    slots: [],
    params: []
  },
  {
    id: "point-coords",
    kind: "point",
    mode: "construct",
    label: "From coordinates",
    hint: "A fixed reference point, e.g. a datum from the drawing.",
    slots: [],
    params: XYZ
  },
  {
    id: "point-centroid",
    kind: "point",
    mode: "construct",
    label: "Centroid of the scan",
    hint: "The centre of the volume the scan encloses, read off the mesh the moment this is chosen. An open scan gets the centre of its surface instead, and says so; a marked surface gets the centre of the marking.",
    slots: [],
    params: XYZ.map(found),
    surface: true
  },
  {
    id: "point-midpoint",
    kind: "point",
    mode: "construct",
    label: "Midpoint of two points",
    hint: "Halfway between two points or sphere centers.",
    slots: [
      { role: "point", label: "Point A" },
      { role: "point", label: "Point B" }
    ],
    params: []
  },
  {
    id: "point-line-plane",
    kind: "point",
    mode: "construct",
    label: "Line–plane intersection",
    hint: "Where a line or cylinder axis pierces a plane.",
    slots: [
      { role: "axis", label: "Line or cylinder" },
      { role: "plane", label: "Plane" }
    ],
    params: []
  },
  // ---- Line ----------------------------------------------------------------
  {
    id: "line-two-points",
    kind: "line",
    mode: "construct",
    label: "Through two points",
    hint: "The line through two points or sphere centers.",
    slots: [
      { role: "point", label: "Point A" },
      { role: "point", label: "Point B" }
    ],
    params: []
  },
  {
    id: "line-axis",
    kind: "line",
    mode: "construct",
    label: "Cylinder axis",
    hint: "A cylinder's axis as a standalone line element.",
    slots: [{ role: "axis", label: "Cylinder" }],
    params: []
  },
  {
    id: "line-plane-plane",
    kind: "line",
    mode: "construct",
    label: "Plane–plane intersection",
    hint: "The edge line where two planes meet.",
    slots: [
      { role: "plane", label: "Plane A" },
      { role: "plane", label: "Plane B" }
    ],
    params: []
  },
  // ---- Plane ---------------------------------------------------------------
  {
    id: "fit",
    kind: "plane",
    mode: "fit",
    label: "Fit to scan",
    hint: "Click a point on the flat surface in the 3D view.",
    slots: [],
    params: []
  },
  {
    id: "plane-three-points",
    kind: "plane",
    mode: "construct",
    label: "Through three points",
    hint: "The plane spanned by three points or sphere centers.",
    slots: [
      { role: "point", label: "Point A" },
      { role: "point", label: "Point B" },
      { role: "point", label: "Point C" }
    ],
    params: []
  },
  {
    id: "plane-offset",
    kind: "plane",
    mode: "construct",
    label: "Offset from plane",
    hint: "A parallel plane, shifted along the source normal.",
    slots: [{ role: "plane", label: "Plane" }],
    params: [{ key: "offset", label: "Offset", unit: "mm" }]
    // units-ok: an id
  },
  {
    id: "plane-midplane",
    kind: "plane",
    mode: "construct",
    label: "Midplane of two planes",
    hint: "The symmetry plane between two (near-parallel) planes.",
    slots: [
      { role: "plane", label: "Plane A" },
      { role: "plane", label: "Plane B" }
    ],
    params: []
  },
  {
    id: "plane-coords",
    kind: "plane",
    mode: "construct",
    label: "From coordinates",
    hint: "A fixed datum plane: a normal direction and a point it passes through.",
    slots: [],
    params: [
      { key: "nx", label: "Normal X" },
      { key: "ny", label: "Normal Y" },
      { key: "nz", label: "Normal Z" },
      ...XYZ.map((p) => ({ ...p, key: "p" + p.key, label: "Point " + p.label }))
    ]
  },
  {
    id: "plane-symmetry",
    kind: "plane",
    mode: "construct",
    label: "Symmetry plane of the scan",
    hint: "The mirror plane the part matches itself across, found by reflecting the scan and fitting the reflection back onto it — from the best of the three principal planes, or from a plane you choose as the seed. Mark the surface by hand to keep a fixture or a broken patch out of the search.",
    slots: [],
    params: [
      found({ key: "nx", label: "Normal X" }),
      found({ key: "ny", label: "Normal Y" }),
      found({ key: "nz", label: "Normal Z" }),
      ...XYZ.map((p) => found({ ...p, key: "p" + p.key, label: "Point " + p.label })),
      found({ key: "rms", label: "Mirror RMS", unit: "mm" }),
      // units-ok: an id
      found({ key: "matched", label: "Matched samples" }),
      found({ key: "sampled", label: "Samples" })
    ],
    surface: true
  },
  // ---- Sphere / Cylinder / Cone --------------------------------------------
  {
    id: "fit",
    kind: "sphere",
    mode: "fit",
    label: "Fit to scan",
    hint: "Click a point on the sphere in the 3D view.",
    slots: [],
    params: []
  },
  {
    id: "fit",
    kind: "cylinder",
    mode: "fit",
    label: "Fit to scan",
    hint: "Click a point on the cylindrical surface in the 3D view.",
    slots: [],
    params: []
  },
  {
    id: "fit",
    kind: "cone",
    mode: "fit",
    label: "Fit to scan",
    hint: "Click a point on the tapered surface in the 3D view.",
    slots: [],
    params: []
  },
  {
    id: "fit",
    kind: "torus",
    mode: "fit",
    label: "Fit to scan",
    hint: "Click a point on the middle of a round — a fillet, a bend, an O-ring seat — in the 3D view.",
    slots: [],
    params: []
  },
  // ---- Circle ----------------------------------------------------------------
  {
    id: "circle-points",
    kind: "circle",
    mode: "pick",
    label: "Through picked points (3+)",
    hint: "Click three or more points around the feature — a hole rim, a boss edge. More points refine the fit.",
    slots: [],
    params: [],
    minPicks: 3
  },
  {
    id: "circle-plane-cylinder",
    kind: "circle",
    mode: "construct",
    label: "Plane–cylinder intersection",
    hint: "The circle where a cylinder crosses a plane — a bore's rim, a boss at its base.",
    slots: [
      { role: "plane", label: "Plane" },
      { role: "axis", label: "Cylinder", kinds: ["cylinder"] }
    ],
    params: []
  },
  {
    id: "circle-plane-sphere",
    kind: "circle",
    mode: "construct",
    label: "Plane–sphere intersection",
    hint: "The circle where a sphere crosses a plane.",
    slots: [
      { role: "plane", label: "Plane" },
      { role: "point", label: "Sphere", kinds: ["sphere"] }
    ],
    params: []
  },
  {
    id: "circle-coords",
    kind: "circle",
    mode: "construct",
    label: "From coordinates",
    hint: "A fixed reference circle: its diameter, the normal of its plane and its center.",
    slots: [],
    params: [
      { key: "d", label: "Diameter", unit: "mm" },
      // units-ok: an id
      { key: "nx", label: "Normal X" },
      { key: "ny", label: "Normal Y" },
      { key: "nz", label: "Normal Z" },
      ...XYZ.map((p) => ({ ...p, key: "c" + p.key, label: "Center " + p.label }))
    ]
  }
];
function creationMethod(kind, id) {
  const m = CREATION_METHODS.find((c) => c.kind === kind && c.id === id);
  if (!m) throw new Error(`Unknown creation method "${id}" for ${kind}.`);
  return m;
}
const NO_FIT_STATS = { sigma: 0, usedPoints: 0, regionSize: 0 };
function planeAt(center, normal, fallbackSize) {
  const [basisU, basisV] = orthoBasis(normal);
  const extent = Math.max(fallbackSize * 0.3, 1);
  return {
    kind: "plane",
    center,
    normal,
    basisU,
    basisV,
    extentU: extent,
    extentV: extent
  };
}
const need = (v, what) => {
  if (v === null) throw new ConstructionError(`Missing ${what}.`);
  return v;
};
function pointOf(fit, label) {
  return need(refPoint(fit), `a point from ${label}`);
}
const INTERSECT_MIN_ANGLE = 0.2;
const SECTION_MAX_TILT = 5;
function evaluateConstruction(method, refs, params, fallbackSize) {
  switch (method) {
    case "point-coords":
    case "point-centroid": {
      const [x, y, z] = params;
      if (![x, y, z].every(Number.isFinite))
        throw new ConstructionError(
          method === "point-centroid" ? "The centroid has not been measured yet." : "Enter all three coordinates."
        );
      return { kind: "point", center: [x, y, z], ...NO_FIT_STATS };
    }
    case "point-midpoint": {
      const a = pointOf(refs[0], "point A");
      const b = pointOf(refs[1], "point B");
      return { kind: "point", center: mid(a, b), ...NO_FIT_STATS };
    }
    case "point-line-plane": {
      const axis = need(refAxis(refs[0]), "a line or cylinder axis");
      const pl = need(refPlane(refs[1]), "the plane");
      if (90 - acuteAngle(axis.dir, pl.normal) < INTERSECT_MIN_ANGLE)
        throw new ConstructionError("The line runs parallel to the plane — they never meet.");
      const t = dot(sub(pl.center, axis.origin), pl.normal) / dot(axis.dir, pl.normal);
      return {
        kind: "point",
        center: addScaled(axis.origin, axis.dir, t),
        ...NO_FIT_STATS
      };
    }
    case "line-two-points": {
      const a = pointOf(refs[0], "point A");
      const b = pointOf(refs[1], "point B");
      const dir = normalize(sub(b, a));
      if (!dir) throw new ConstructionError("The two points coincide — no line direction.");
      return {
        kind: "line",
        center: mid(a, b),
        dir,
        length: len(sub(b, a)),
        ...NO_FIT_STATS
      };
    }
    case "line-axis": {
      const axis = need(refAxis(refs[0]), "an axis from the cylinder");
      return {
        kind: "line",
        center: axis.origin,
        dir: axis.dir,
        length: Math.max(axis.halfLength * 2, fallbackSize * 0.1),
        ...NO_FIT_STATS
      };
    }
    case "line-plane-plane": {
      const pa = need(refPlane(refs[0]), "plane A");
      const pb = need(refPlane(refs[1]), "plane B");
      if (acuteAngle(pa.normal, pb.normal) < INTERSECT_MIN_ANGLE)
        throw new ConstructionError("The planes are parallel — they have no intersection line.");
      const dirRaw = cross(pa.normal, pb.normal);
      const dir = normalize(dirRaw);
      const da = dot(pa.normal, pa.center);
      const db = dot(pb.normal, pb.center);
      const d2 = dot(dirRaw, dirRaw);
      const p = scale(add(scale(cross(pb.normal, dirRaw), da), scale(cross(dirRaw, pa.normal), db)), 1 / d2);
      const anchor = footOnLine(mid(pa.center, pb.center), p, dir);
      const length = Math.max(
        Math.max(pa.extentU, pa.extentV, pb.extentU, pb.extentV) * 2,
        fallbackSize * 0.05
      );
      return { kind: "line", center: anchor, dir, length, ...NO_FIT_STATS };
    }
    case "plane-three-points": {
      const a = pointOf(refs[0], "point A");
      const b = pointOf(refs[1], "point B");
      const c = pointOf(refs[2], "point C");
      const ab = sub(b, a);
      const ac = sub(c, a);
      const nRaw = cross(ab, ac);
      const span = Math.max(len(ab), len(ac));
      if (span < 1e-9 || len(nRaw) < 1e-6 * span * span)
        throw new ConstructionError("The three points are collinear — they do not span a plane.");
      const normal = normalize(nRaw);
      const center = [
        (a[0] + b[0] + c[0]) / 3,
        (a[1] + b[1] + c[1]) / 3,
        (a[2] + b[2] + c[2]) / 3
      ];
      const basisU = normalize(ab);
      const basisV = cross(normal, basisU);
      let eu = 0;
      let ev = 0;
      for (const p of [a, b, c]) {
        const r = sub(p, center);
        eu = Math.max(eu, Math.abs(dot(r, basisU)));
        ev = Math.max(ev, Math.abs(dot(r, basisV)));
      }
      const pad = Math.max(eu, ev) * 0.15;
      return {
        kind: "plane",
        center,
        normal,
        basisU,
        basisV,
        extentU: eu + pad,
        extentV: ev + pad,
        ...NO_FIT_STATS
      };
    }
    case "plane-offset": {
      const p = need(refPlane(refs[0]), "the source plane");
      const [offset] = params;
      if (!Number.isFinite(offset)) throw new ConstructionError("Enter the offset distance.");
      return {
        ...p,
        ...NO_FIT_STATS,
        center: addScaled(p.center, p.normal, offset)
      };
    }
    case "plane-midplane": {
      const pa = need(refPlane(refs[0]), "plane A");
      const pb = need(refPlane(refs[1]), "plane B");
      if (90 - acuteAngle(pa.normal, pb.normal) < INTERSECT_MIN_ANGLE)
        throw new ConstructionError("The planes are perpendicular — no midplane between them.");
      const nb = dot(pa.normal, pb.normal) < 0 ? scale(pb.normal, -1) : pb.normal;
      const normal = normalize(add(pa.normal, nb));
      const center = mid(pa.center, pb.center);
      const u = normalize(addScaled(pa.basisU, normal, -dot(pa.basisU, normal)));
      const basisU = u ?? orthoBasis(normal)[0];
      const basisV = cross(normal, basisU);
      return {
        kind: "plane",
        center,
        normal,
        basisU,
        basisV,
        extentU: Math.max(pa.extentU, pb.extentU),
        extentV: Math.max(pa.extentV, pb.extentV),
        ...NO_FIT_STATS
      };
    }
    case "plane-coords": {
      const [nx, ny, nz, px, py, pz] = params;
      if (![nx, ny, nz, px, py, pz].every(Number.isFinite))
        throw new ConstructionError("Enter the normal direction and a point on the plane.");
      const normal = normalize([nx, ny, nz]);
      if (!normal) throw new ConstructionError("The normal direction must not be zero.");
      return {
        ...planeAt([px, py, pz], normal, fallbackSize),
        ...NO_FIT_STATS
      };
    }
    case "plane-symmetry": {
      const [nx, ny, nz, px, py, pz, rms, matched, sampled] = params;
      if (![nx, ny, nz, px, py, pz].every(Number.isFinite))
        throw new ConstructionError("Find the symmetry plane first.");
      const normal = normalize([nx, ny, nz]);
      if (!normal) throw new ConstructionError("The symmetry plane has no direction.");
      return {
        ...planeAt([px, py, pz], normal, fallbackSize),
        // The mirror registration's residual stands where a fit's sigma
        // does: how far the part is from symmetric about this plane, over
        // the samples that found their mirror image on the scan.
        sigma: Number.isFinite(rms) ? rms : 0,
        usedPoints: Number.isFinite(matched) ? matched : 0,
        regionSize: Number.isFinite(sampled) ? sampled : 0
      };
    }
    case "circle-plane-cylinder": {
      const pl = need(refPlane(refs[0]), "the plane");
      const cyl = refs[1];
      if (cyl.kind !== "cylinder")
        throw new ConstructionError("The second reference must be a cylinder.");
      const tilt = acuteAngle(cyl.axis, pl.normal);
      if (90 - tilt < INTERSECT_MIN_ANGLE)
        throw new ConstructionError("The cylinder runs parallel to the plane — they never meet.");
      if (tilt > SECTION_MAX_TILT)
        throw new ConstructionError(
          `The cylinder leans ${tilt.toFixed(1)}° against the plane — the section is an ellipse, not a circle.`
        );
      const t = dot(sub(pl.center, cyl.center), pl.normal) / dot(cyl.axis, pl.normal);
      return {
        kind: "circle",
        center: addScaled(cyl.center, cyl.axis, t),
        normal: pl.normal,
        radius: cyl.radius,
        ...NO_FIT_STATS
      };
    }
    case "circle-plane-sphere": {
      const pl = need(refPlane(refs[0]), "the plane");
      const sph = refs[1];
      if (sph.kind !== "sphere")
        throw new ConstructionError("The second reference must be a sphere.");
      const d = dot(sub(sph.center, pl.center), pl.normal);
      if (Math.abs(d) >= sph.radius) {
        throw new ConstructionError(
          Math.abs(d) - sph.radius < sph.radius * 1e-6 ? "The plane only touches the sphere — the circle would have no size." : "The plane misses the sphere — there is no intersection."
        );
      }
      return {
        kind: "circle",
        center: addScaled(sph.center, pl.normal, -d),
        normal: pl.normal,
        radius: Math.sqrt(sph.radius * sph.radius - d * d),
        ...NO_FIT_STATS
      };
    }
    case "circle-coords": {
      const [d, nx, ny, nz, cx, cy, cz] = params;
      if (![d, nx, ny, nz, cx, cy, cz].every(Number.isFinite))
        throw new ConstructionError("Enter the diameter, the normal direction and the center.");
      if (!(d > 0)) throw new ConstructionError("The diameter must be positive.");
      const normal = normalize([nx, ny, nz]);
      if (!normal) throw new ConstructionError("The normal direction must not be zero.");
      return {
        kind: "circle",
        center: [cx, cy, cz],
        normal,
        radius: d / 2,
        ...NO_FIT_STATS
      };
    }
    default:
      throw new ConstructionError(`Unknown construction "${method}".`);
  }
}
const CYLINDER_SIDES = ["start", "end"];
const PLANE_SIDES = ["uMin", "uMax", "vMin", "vMax"];
const MIN_SIZE = 1e-3;
function isExtendable(fit) {
  return fit !== void 0 && (fit.kind === "cylinder" || fit.kind === "plane");
}
function zeroExtension(fit) {
  return fit.kind === "cylinder" ? { kind: "cylinder", start: 0, end: 0 } : { kind: "plane", uMin: 0, uMax: 0, vMin: 0, vMax: 0 };
}
function extensionOf(fit, ext) {
  return ext && ext.kind === fit.kind ? ext : zeroExtension(fit);
}
function isExtended(ext) {
  if (!ext) return false;
  return sides(ext).some((s) => sideValue(ext, s) !== 0);
}
function fitsInside(ext) {
  return ext?.kind === "cylinder" && ext.fitInside === true;
}
function withFitInside(ext, on) {
  if (ext.kind !== "cylinder") return ext;
  if (on) return { ...ext, fitInside: true };
  const { fitInside: _off, ...rest } = ext;
  return rest;
}
function sides(ext) {
  return ext.kind === "cylinder" ? CYLINDER_SIDES : PLANE_SIDES;
}
function sideValue(ext, side) {
  return ext[side];
}
function opposite(side) {
  if (side === "start") return "end";
  if (side === "end") return "start";
  if (side === "uMin") return "uMax";
  if (side === "uMax") return "uMin";
  return side === "vMin" ? "vMax" : "vMin";
}
function fittedSpan(fit, side) {
  if (fit.kind === "cylinder") return fit.length;
  return 2 * (side === "uMin" || side === "uMax" ? fit.extentU : fit.extentV);
}
function minSide(fit, ext, side) {
  const far = sideValue(ext, opposite(side));
  return MIN_SIZE - fittedSpan(fit, side) - far;
}
function withSide(fit, ext, side, value) {
  const v = Number.isFinite(value) ? Math.max(value, minSide(fit, ext, side)) : 0;
  return { ...ext, [side]: v };
}
function squareExtension(fit, ext) {
  const e = extensionOf(fit, ext);
  if (e.kind !== "plane") return e;
  const u = 2 * fit.extentU + e.uMin + e.uMax;
  const v = 2 * fit.extentV + e.vMin + e.vMax;
  const side = Math.max(u, v);
  const du = (side - u) / 2;
  const dv = (side - v) / 2;
  return {
    kind: "plane",
    uMin: e.uMin + du,
    uMax: e.uMax + du,
    vMin: e.vMin + dv,
    vMax: e.vMax + dv
  };
}
function hasDiameter(fit) {
  return fit !== void 0 && (fit.kind === "sphere" || fit.kind === "cylinder" || fit.kind === "circle");
}
const TOLERANCE_TYPES = [
  {
    id: "form-flatness",
    family: "tolerance",
    group: "form",
    label: "Flatness",
    stem: "Flatness",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "How far the measured face strays from a perfect plane: the peak-to-peak deviation of its points.",
    slots: [{ roles: ["plane"], label: "Plane" }]
  },
  {
    id: "form-cylindricity",
    family: "tolerance",
    group: "form",
    label: "Cylindricity",
    stem: "Cylindricity",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "How far the measured wall strays from a perfect cylinder, peak to peak.",
    slots: [{ roles: ["axis"], kinds: ["cylinder"], label: "Cylinder" }]
  },
  {
    id: "form-circularity",
    family: "tolerance",
    group: "form",
    label: "Circularity",
    stem: "Circularity",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "How far the picked points stray from a perfect circle, radially, peak to peak.",
    slots: [{ roles: ["point"], kinds: ["circle"], label: "Circle" }]
  },
  {
    id: "form-sphericity",
    family: "tolerance",
    group: "form",
    label: "Sphericity",
    stem: "Sphericity",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "How far the measured surface strays from a perfect sphere, peak to peak.",
    slots: [{ roles: ["point"], kinds: ["sphere"], label: "Sphere" }]
  },
  {
    id: "orient-parallelism",
    family: "tolerance",
    group: "orientation",
    label: "Parallelism",
    stem: "Parallelism",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "The width of the narrowest zone parallel to the datum that holds the feature — a face by its measured surface, a cylinder by its axis.",
    slots: [
      { roles: ["plane", "axis"], label: "Feature" },
      { roles: ["plane", "axis"], label: "Datum" }
    ]
  },
  {
    id: "orient-perpendicularity",
    family: "tolerance",
    group: "orientation",
    label: "Perpendicularity",
    stem: "Perpendicularity",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "The width of the narrowest zone square to the datum that holds the feature — a face by its measured surface, a cylinder by its axis.",
    slots: [
      { roles: ["plane", "axis"], label: "Feature" },
      { roles: ["plane", "axis"], label: "Datum" }
    ]
  },
  {
    id: "orient-angularity",
    family: "tolerance",
    group: "orientation",
    label: "Angularity",
    stem: "Angularity",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "The width of the narrowest zone at the basic angle to the datum that holds the feature — a face by its measured surface, a cylinder by its axis.",
    slots: [
      { roles: ["plane", "axis"], label: "Feature" },
      { roles: ["plane", "axis"], label: "Datum" }
    ]
  },
  {
    id: "loc-coaxiality",
    family: "tolerance",
    group: "location",
    label: "Coaxiality",
    stem: "Coaxiality",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "The diameter of the narrowest zone about the datum axis that holds the feature axis — or, for a sphere or a circle, its centre: twice the furthest it strays.",
    slots: [
      {
        roles: ["axis", "point"],
        kinds: ["cylinder", "cone", "line", "sphere", "circle"],
        label: "Feature"
      },
      { roles: ["axis"], label: "Datum axis" }
    ]
  }
];
const stemKey = (info) => info.stem.toLowerCase();
const DIMENSIONS = [
  {
    id: "dist-point-point",
    family: "dimension",
    group: "distance",
    label: "Point – Point",
    stem: "Distance",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "Straight-line distance between two points or sphere centers.",
    slots: [
      { roles: ["point"], label: "From" },
      { roles: ["point"], label: "To" }
    ]
  },
  {
    id: "dist-point-axis",
    family: "dimension",
    group: "distance",
    label: "Point – Axis",
    stem: "Distance",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "Perpendicular distance from a point to a cylinder axis or line.",
    slots: [
      { roles: ["point"], label: "Point" },
      { roles: ["axis"], label: "Axis" }
    ]
  },
  {
    id: "dist-point-plane",
    family: "dimension",
    group: "distance",
    label: "Point – Plane",
    stem: "Distance",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "Perpendicular distance from a point to a fitted plane, signed along the plane normal — the CMM way to measure a width, free of the in-plane offset two picked points carry.",
    slots: [
      { roles: ["point"], label: "Point" },
      { roles: ["plane"], label: "Plane" }
    ]
  },
  {
    id: "dist-axis-axis",
    family: "dimension",
    group: "distance",
    label: "Axis – Axis",
    stem: "Distance",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "Distance between two near-parallel axes, or at the closest approach of skew axes.",
    slots: [
      { roles: ["axis"], label: "Axis A" },
      { roles: ["axis"], label: "Axis B" }
    ]
  },
  {
    id: "dist-axis-plane",
    family: "dimension",
    group: "distance",
    label: "Axis – Plane",
    stem: "Distance",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "Distance from the middle of an axis to a near-parallel plane, signed along the normal.",
    slots: [
      { roles: ["axis"], label: "Axis" },
      { roles: ["plane"], label: "Plane" }
    ]
  },
  {
    id: "dist-plane-plane",
    family: "dimension",
    group: "distance",
    label: "Plane – Plane",
    stem: "Distance",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "Distance between two near-parallel planes, measured from the center of the first.",
    slots: [
      { roles: ["plane"], label: "From" },
      { roles: ["plane"], label: "To" }
    ]
  },
  {
    id: "angle-axis-axis",
    family: "dimension",
    group: "angle",
    label: "Axis – Axis",
    stem: "Angle",
    unit: "°",
    hint: "Angle between two axes (0–90°).",
    slots: [
      { roles: ["axis"], label: "Axis A" },
      { roles: ["axis"], label: "Axis B" }
    ]
  },
  {
    id: "angle-axis-plane",
    family: "dimension",
    group: "angle",
    label: "Axis – Plane",
    stem: "Angle",
    unit: "°",
    hint: "Angle between an axis and a plane surface (0–90°).",
    slots: [
      { roles: ["axis"], label: "Axis" },
      { roles: ["plane"], label: "Plane" }
    ]
  },
  {
    id: "angle-plane-plane",
    family: "dimension",
    group: "angle",
    label: "Plane – Plane",
    stem: "Angle",
    unit: "°",
    hint: "Angle between two plane surfaces via their outward normals (0–180°).",
    slots: [
      { roles: ["plane"], label: "Plane A" },
      { roles: ["plane"], label: "Plane B" }
    ]
  },
  {
    id: "size-diameter",
    family: "dimension",
    group: "size",
    label: "Diameter",
    stem: "Diameter",
    unit: "mm",
    // units-ok: the value's kind, an id — printed through unitWord
    hint: "The fitted diameter of a sphere, a cylinder or a circle — so a size can carry a nominal and a tolerance.",
    slots: [{ roles: ["point", "axis"], kinds: ["sphere", "cylinder", "circle"], label: "Feature" }]
  }
];
function dimensionTypes() {
  return [...DIMENSIONS, ...TOLERANCE_TYPES];
}
function dimensionTypeInfo(id) {
  const info = dimensionTypes().find((t) => t.id === id);
  if (!info) throw new Error(`Unknown dimension type "${id}".`);
  return info;
}
function seatSelection(info, kinds) {
  if (kinds.length > info.slots.length) return null;
  const taken = new Array(info.slots.length).fill(false);
  const seats = [];
  const place = (i) => {
    if (i === kinds.length) return true;
    const kind = kinds[i];
    const preferred = roleOf(kind);
    const order = info.slots.map((slot, s) => ({ slot, s })).filter(({ slot, s }) => !taken[s] && slotTakes(slot, kind)).sort((a, b) => Number(b.slot.roles.includes(preferred)) - Number(a.slot.roles.includes(preferred)));
    for (const { s } of order) {
      taken[s] = true;
      seats[i] = s;
      if (place(i + 1)) return true;
      taken[s] = false;
    }
    return false;
  };
  return place(0) ? seats : null;
}
function resolveDimensionType(currentType, kinds) {
  const current = dimensionTypeInfo(currentType);
  if (seatSelection(current, kinds)) return currentType;
  const candidates = dimensionTypes().filter(
    (t) => t.family === current.family && seatSelection(t, kinds) !== null
  );
  if (candidates.length === 0) return currentType;
  const pool = candidates.some((t) => t.group === current.group) ? candidates.filter((t) => t.group === current.group) : candidates;
  const homogeneous = kinds.length === 1 && pool.find((t) => t.slots.every((s) => slotTakes(s, kinds[0])));
  return (homogeneous || pool[0]).id;
}
function selectionFits(family, kinds) {
  return dimensionTypes().some((t) => t.family === family && seatSelection(t, kinds) !== null);
}
function assignDimensionRefs(type, selected) {
  const info = dimensionTypeInfo(type);
  const refs = info.slots.map(() => null);
  const seats = seatSelection(
    info,
    selected.map((s) => s.kind)
  );
  if (seats) {
    seats.forEach((s, i) => refs[s] = selected[i].id);
    return refs;
  }
  for (const sel of selected) {
    const s = info.slots.findIndex((slot, i) => refs[i] === null && slotTakes(slot, sel.kind));
    if (s >= 0) refs[s] = sel.id;
  }
  return refs;
}
function identityRigid() {
  return { r: Float64Array.from([1, 0, 0, 0, 1, 0, 0, 0, 1]), t: new Float64Array(3) };
}
function rigidFromQuaternion(w, x, y, z) {
  const n = Math.hypot(w, x, y, z);
  if (!(n > 1e-20)) return identityRigid();
  w /= n;
  x /= n;
  y /= n;
  z /= n;
  return {
    r: Float64Array.from([
      1 - 2 * (y * y + z * z),
      2 * (x * y - w * z),
      2 * (x * z + w * y),
      2 * (x * y + w * z),
      1 - 2 * (x * x + z * z),
      2 * (y * z - w * x),
      2 * (x * z - w * y),
      2 * (y * z + w * x),
      1 - 2 * (x * x + y * y)
    ]),
    t: new Float64Array(3)
  };
}
function rigidFromAxisAngle(axis, angle) {
  const len3 = Math.hypot(axis[0], axis[1], axis[2]);
  if (!(len3 > 1e-20) || !(Math.abs(angle) > 1e-20)) return identityRigid();
  const half = angle / 2;
  const s = Math.sin(half) / len3;
  return rigidFromQuaternion(Math.cos(half), axis[0] * s, axis[1] * s, axis[2] * s);
}
function rigidApply(m, x, y, z, out) {
  const r = m.r;
  out[0] = r[0] * x + r[1] * y + r[2] * z + m.t[0];
  out[1] = r[3] * x + r[4] * y + r[5] * z + m.t[1];
  out[2] = r[6] * x + r[7] * y + r[8] * z + m.t[2];
}
function rigidRotate(m, x, y, z, out) {
  const r = m.r;
  out[0] = r[0] * x + r[1] * y + r[2] * z;
  out[1] = r[3] * x + r[4] * y + r[5] * z;
  out[2] = r[6] * x + r[7] * y + r[8] * z;
}
function rigidCompose(a, b) {
  const r = new Float64Array(9);
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      r[i * 3 + j] = a.r[i * 3] * b.r[j] + a.r[i * 3 + 1] * b.r[3 + j] + a.r[i * 3 + 2] * b.r[6 + j];
    }
  }
  const t = new Float64Array(3);
  rigidApply(a, b.t[0], b.t[1], b.t[2], t);
  return { r, t };
}
function rigidApplyToPoints(m, xyz) {
  const r = m.r;
  const t = m.t;
  for (let i = 0; i < xyz.length; i += 3) {
    const x = xyz[i];
    const y = xyz[i + 1];
    const z = xyz[i + 2];
    xyz[i] = r[0] * x + r[1] * y + r[2] * z + t[0];
    xyz[i + 1] = r[3] * x + r[4] * y + r[5] * z + t[1];
    xyz[i + 2] = r[6] * x + r[7] * y + r[8] * z + t[2];
  }
}
function rigidRotateVectors(m, xyz) {
  const r = m.r;
  for (let i = 0; i < xyz.length; i += 3) {
    const x = xyz[i];
    const y = xyz[i + 1];
    const z = xyz[i + 2];
    xyz[i] = r[0] * x + r[1] * y + r[2] * z;
    xyz[i + 1] = r[3] * x + r[4] * y + r[5] * z;
    xyz[i + 2] = r[6] * x + r[7] * y + r[8] * z;
  }
}
const ALIGN_PICK_COUNT = {
  primary: 3,
  secondary: 2,
  origin: 1
};
const tmp = new Float64Array(3);
function movePoint(m, p) {
  rigidApply(m, p[0], p[1], p[2], tmp);
  return [tmp[0], tmp[1], tmp[2]];
}
function moveDir(m, d) {
  rigidRotate(m, d[0], d[1], d[2], tmp);
  return normalize([tmp[0], tmp[1], tmp[2]]) ?? [tmp[0], tmp[1], tmp[2]];
}
function transformFit(fit, m) {
  switch (fit.kind) {
    case "point":
    case "sphere":
      return { ...fit, center: movePoint(m, fit.center) };
    case "line":
      return { ...fit, center: movePoint(m, fit.center), dir: moveDir(m, fit.dir) };
    case "cylinder":
    case "cone":
    case "torus":
      return { ...fit, center: movePoint(m, fit.center), axis: moveDir(m, fit.axis) };
    case "circle":
      return { ...fit, center: movePoint(m, fit.center), normal: moveDir(m, fit.normal) };
    case "plane":
      return {
        ...fit,
        center: movePoint(m, fit.center),
        normal: moveDir(m, fit.normal),
        basisU: moveDir(m, fit.basisU),
        basisV: moveDir(m, fit.basisV)
      };
  }
}
const BASE_PLANES = [
  { id: -1, name: "XY plane", normal: [0, 0, 1] },
  { id: -2, name: "YZ plane", normal: [1, 0, 0] },
  { id: -3, name: "XZ plane", normal: [0, 1, 0] }
];
function basePlaneOf(id) {
  return BASE_PLANES.find((p) => p.id === id);
}
function referenceNormal(ref, fitOf) {
  const base = basePlaneOf(ref);
  if (base) return base.normal;
  const fit = fitOf(ref);
  return fit?.kind === "plane" ? fit.normal : null;
}
function isOrientRef(ref, elements) {
  return basePlaneOf(ref) !== void 0 || elements.some((e) => e.id === ref && e.kind === "plane");
}
function refThroughMotion(ref, turn) {
  const base = basePlaneOf(ref);
  if (!base) return ref;
  const normal = turn(base.normal);
  return BASE_PLANES.find((p) => acuteAngle(normal, p.normal) <= ORIENT_TOLERANCE_DEG)?.id ?? null;
}
const ORIENT_TOLERANCE_DEG = 2;
const ORIENTABLE_KINDS = [
  "plane",
  "line",
  "cylinder",
  "cone",
  "circle",
  "torus"
];
function isOrientable(fit) {
  return fit !== void 0 && ORIENTABLE_KINDS.includes(fit.kind);
}
function directionOf(fit) {
  if (fit.kind === "plane" || fit.kind === "circle") return fit.normal;
  if (fit.kind === "line") return fit.dir;
  return fit.axis;
}
class OrientError extends Error {
}
function targetDirection(dir, normal, relation) {
  if (relation === "normal") {
    return dot(dir, normal) < 0 ? [-normal[0], -normal[1], -normal[2]] : normal;
  }
  const projected = normalize(addScaled(dir, normal, -dot(dir, normal)));
  if (!projected) {
    throw new OrientError(
      "Cannot align: the direction stands straight on the reference plane, so there is no way to lay it into it."
    );
  }
  return projected;
}
function orientFit(fit, reference, relation) {
  if (!isOrientable(fit)) return { fit, deviationDeg: 0, warning: null };
  const dir = directionOf(fit);
  const target = targetDirection(dir, reference.normal, relation);
  const deviationDeg = acuteAngle(dir, target);
  const warning = deviationDeg > ORIENT_TOLERANCE_DEG ? `Measured ${deviationDeg.toFixed(2)}° off the aligned direction — more than the ${ORIENT_TOLERANCE_DEG}° an aligned feature is expected to be within. Check that the right reference and relation are chosen.` : null;
  const axis = cross(dir, target);
  const sin = len(axis);
  const cos = dot(dir, target);
  const angle = Math.atan2(sin, cos);
  let turned = fit;
  if (angle > 1e-12) {
    const rotAxis = sin > 1e-12 ? axis : anyPerpendicular(dir);
    const rot = rigidFromAxisAngle(rotAxis, angle);
    const c = fit.center;
    const rc = [
      rot.r[0] * c[0] + rot.r[1] * c[1] + rot.r[2] * c[2],
      rot.r[3] * c[0] + rot.r[4] * c[1] + rot.r[5] * c[2],
      rot.r[6] * c[0] + rot.r[7] * c[1] + rot.r[8] * c[2]
    ];
    rot.t[0] = c[0] - rc[0];
    rot.t[1] = c[1] - rc[1];
    rot.t[2] = c[2] - rc[2];
    turned = transformFit(fit, rot);
  }
  const exact = withDirection(turned, target, fit.center);
  return { fit: exact, deviationDeg, warning };
}
function withDirection(fit, d, center) {
  if (fit.kind === "plane" || fit.kind === "circle") return { ...fit, normal: d, center };
  if (fit.kind === "line") return { ...fit, dir: d, center };
  return { ...fit, axis: d, center };
}
function anyPerpendicular(d) {
  const trial = Math.abs(d[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0];
  return cross(d, trial);
}
const SECTION_REF_KINDS = ["plane", "cylinder", "cone", "line", "circle"];
function canCutAlong(kind) {
  return SECTION_REF_KINDS.includes(kind);
}
function isWorldAxis(ref) {
  return ref === "x" || ref === "y" || ref === "z";
}
function isRadialRef(ref) {
  return typeof ref === "object" && ref !== null && "axis" in ref && "angleDeg" in ref;
}
function sectionRefElement(ref) {
  if (typeof ref === "number") return ref;
  return isRadialRef(ref) && typeof ref.axis === "number" ? ref.axis : null;
}
function worldAxisDir(axis) {
  return axis === "x" ? [1, 0, 0] : axis === "y" ? [0, 1, 0] : [0, 0, 1];
}
function worldCutAxis(axis, through = [0, 0, 0]) {
  const dir = worldAxisDir(axis);
  const basisU = axis === "x" ? [0, 1, 0] : axis === "y" ? [0, 0, 1] : [1, 0, 0];
  return { origin: addScaled(through, dir, -dot(through, dir)), dir, basisU };
}
function cutAxisOf(fit) {
  switch (fit.kind) {
    case "plane":
      return { origin: fit.center, dir: fit.normal, basisU: fit.basisU };
    case "cylinder":
    case "cone":
      return { origin: fit.center, dir: fit.axis };
    case "line":
      return { origin: fit.center, dir: fit.dir };
    case "circle":
      return { origin: fit.center, dir: fit.normal };
    default:
      return null;
  }
}
function axisLineOf(fit) {
  switch (fit.kind) {
    case "cylinder":
    case "cone":
      return { origin: fit.center, dir: fit.axis };
    case "line":
      return { origin: fit.center, dir: fit.dir };
    case "circle":
      return { origin: fit.center, dir: fit.normal };
    default:
      return null;
  }
}
function radialFrame(axis, angleDeg) {
  let up = normalize(axis.dir);
  if (!up || !Number.isFinite(angleDeg)) return null;
  let k = 0;
  for (let i = 1; i < 3; i++) if (Math.abs(up[i]) > Math.abs(up[k])) k = i;
  if (up[k] < 0) up = [-up[0], -up[1], -up[2]];
  const zero = inPlaneX(up, sketchXAxis(up));
  const quarter = cross(up, zero);
  const a = angleDeg * Math.PI / 180;
  const basisU = normalize(addScaled([zero[0] * Math.cos(a), zero[1] * Math.cos(a), zero[2] * Math.cos(a)], quarter, Math.sin(a)));
  return { origin: axis.origin, normal: cross(basisU, up), basisU, basisV: up };
}
function radialCutAxis(axis, angleDeg) {
  const f = radialFrame(axis, angleDeg);
  return f && { origin: f.origin, dir: f.normal, basisU: f.basisU };
}
function sectionRefAxis(ref, elements, centre) {
  if (isWorldAxis(ref)) return worldCutAxis(ref, centre);
  if (isRadialRef(ref)) {
    const { axis } = ref;
    if (isWorldAxis(axis)) return radialCutAxis({ origin: [0, 0, 0], dir: worldAxisDir(axis) }, ref.angleDeg);
    const fit = elements.find((e) => e.id === axis)?.fit;
    const line = fit ? axisLineOf(fit) : null;
    return line && radialCutAxis(line, ref.angleDeg);
  }
  const el = elements.find((e) => e.id === ref);
  return el?.fit && canCutAlong(el.kind) ? cutAxisOf(el.fit) : null;
}
function sectionFrameAlong(axis, offset, seedU) {
  const normal = normalize(axis.dir);
  if (!normal) return null;
  const origin = addScaled(axis.origin, normal, Number.isFinite(offset) ? offset : 0);
  const basisU = inPlaneX(normal, seedU ?? axis.basisU);
  return { origin, normal, basisU, basisV: cross(normal, basisU) };
}
function sketchXAxis(normal) {
  const a = [Math.abs(normal[0]), Math.abs(normal[1]), Math.abs(normal[2])];
  const nearest = a[0] >= a[1] && a[0] >= a[2] ? 0 : a[1] >= a[2] ? 1 : 2;
  const next = (nearest + 1) % 3;
  return next === 0 ? [1, 0, 0] : next === 1 ? [0, 1, 0] : [0, 0, 1];
}
function axisOfFrame(frame, offset) {
  return {
    origin: addScaled(frame.origin, frame.normal, -(Number.isFinite(offset) ? offset : 0)),
    dir: frame.normal,
    basisU: frame.basisU
  };
}
function transformAxis(axis, m) {
  const out = new Float64Array(3);
  rigidApply(m, axis.origin[0], axis.origin[1], axis.origin[2], out);
  const origin = [out[0], out[1], out[2]];
  rigidRotate(m, axis.dir[0], axis.dir[1], axis.dir[2], out);
  const dir = [out[0], out[1], out[2]];
  if (!axis.basisU) return { origin, dir };
  rigidRotate(m, axis.basisU[0], axis.basisU[1], axis.basisU[2], out);
  return { origin, dir, basisU: [out[0], out[1], out[2]] };
}
function inPlaneX(normal, want) {
  if (want) {
    const flat = normalize(addScaled(want, normal, -dot(want, normal)));
    if (flat) return flat;
  }
  return orthoBasis(normal)[0];
}
function transformFrame(frame, m) {
  const out = new Float64Array(3);
  const move = (p) => {
    rigidApply(m, p[0], p[1], p[2], out);
    return [out[0], out[1], out[2]];
  };
  const turn = (d) => {
    rigidRotate(m, d[0], d[1], d[2], out);
    return [out[0], out[1], out[2]];
  };
  return {
    origin: move(frame.origin),
    normal: turn(frame.normal),
    basisU: turn(frame.basisU),
    basisV: turn(frame.basisV)
  };
}
function sectionPlane(frame, cut) {
  const { origin, normal, basisU, basisV } = frame;
  let center = origin;
  let extentU = 0;
  let extentV = 0;
  const pts = cut?.points;
  if (pts && pts.length >= 3) {
    let u0 = Infinity;
    let u1 = -Infinity;
    let v0 = Infinity;
    let v1 = -Infinity;
    for (let i = 0; i + 2 < pts.length; i += 3) {
      const d = [pts[i] - origin[0], pts[i + 1] - origin[1], pts[i + 2] - origin[2]];
      const u = dot(d, basisU);
      const v = dot(d, basisV);
      if (u < u0) u0 = u;
      if (u > u1) u1 = u;
      if (v < v0) v0 = v;
      if (v > v1) v1 = v;
    }
    center = addScaled(addScaled(origin, basisU, (u0 + u1) / 2), basisV, (v0 + v1) / 2);
    extentU = (u1 - u0) / 2;
    extentV = (v1 - v0) / 2;
  }
  return { kind: "plane", center, normal, basisU, basisV, extentU, extentV, sigma: 0, usedPoints: 0, regionSize: 0 };
}
function frameKey(frame) {
  const v = (a) => a.map((x) => x.toFixed(4)).join(",");
  return `${v(frame.origin)}|${v(frame.normal)}|${v(frame.basisU)}`;
}
function transformCut(cut, m) {
  const points = cut.points.slice();
  rigidApplyToPoints(m, points);
  const shadow = cut.shadow ? { shadow: { ...cut.shadow, frame: transformFrame(cut.shadow.frame, m) } } : {};
  if (!cut.normals) return { points, offsets: cut.offsets, ...shadow };
  const normals = cut.normals.slice();
  rigidRotateVectors(m, normals);
  return { points, offsets: cut.offsets, normals, ...shadow };
}
const LMB = 1;
const RMB = 2;
const MMB = 4;
const SCHEMES = [
  {
    id: "cnckitchen",
    label: "CNC Kitchen",
    hint: "left-drag orbit · right-drag pan · scroll zoom",
    bindings: [
      { buttons: LMB, action: "orbit" },
      { buttons: RMB, action: "pan" }
    ]
  },
  {
    id: "fusion",
    label: "Autodesk Fusion",
    wheelZoomsOut: true,
    hint: "Shift+middle orbit · middle pan · scroll zoom (up = out)",
    bindings: [
      { buttons: MMB, shift: true, action: "orbit" },
      { buttons: MMB, action: "pan" },
      { buttons: MMB, shift: true, ctrl: true, action: "zoom" }
    ]
  },
  {
    id: "inventor",
    label: "Autodesk Inventor",
    wheelZoomsOut: true,
    hint: "Shift+middle orbit · middle pan · scroll zoom (up = out)",
    bindings: [
      { buttons: MMB, shift: true, action: "orbit" },
      { buttons: MMB, action: "pan" }
    ]
  },
  {
    id: "bambu",
    label: "Bambu Studio / Orca / Prusa",
    hint: "left-drag orbit · right-drag pan · scroll zoom",
    bindings: [
      { buttons: LMB, action: "orbit" },
      { buttons: RMB, action: "pan" },
      { buttons: MMB, action: "pan" }
    ]
  },
  {
    id: "blender",
    label: "Blender",
    hint: "middle orbit · Shift+middle pan · scroll zoom",
    bindings: [
      { buttons: MMB, action: "orbit" },
      { buttons: MMB, shift: true, action: "pan" },
      { buttons: MMB, ctrl: true, action: "zoom" }
    ]
  },
  {
    id: "catia",
    label: "CATIA",
    catiaZoomTick: true,
    hint: "middle pan · middle+hold left/right orbit · middle+click left/right then drag zoom",
    bindings: [
      { buttons: MMB, action: "pan" },
      { buttons: MMB | LMB, action: "orbit" },
      { buttons: MMB | RMB, action: "orbit" },
      { buttons: MMB, ctrl: true, action: "zoom" }
    ]
  },
  {
    id: "freecad",
    label: "FreeCAD",
    hint: "middle pan · middle+left orbit · scroll zoom",
    bindings: [
      { buttons: MMB, action: "pan" },
      { buttons: MMB | LMB, action: "orbit" },
      { buttons: MMB | RMB, action: "orbit" }
    ]
  },
  {
    id: "nx",
    label: "Siemens NX",
    wheelZoomsOut: true,
    hint: "middle orbit · Shift+middle pan · Ctrl+middle zoom · scroll (up = out)",
    bindings: [
      { buttons: MMB, action: "orbit" },
      { buttons: MMB, shift: true, action: "pan" },
      { buttons: MMB | RMB, action: "pan" },
      { buttons: MMB, ctrl: true, action: "zoom" },
      { buttons: MMB | LMB, action: "zoom" }
    ]
  },
  {
    id: "onshape",
    label: "Onshape",
    hint: "right-drag orbit · middle pan · scroll zoom",
    bindings: [
      { buttons: RMB, action: "orbit" },
      { buttons: MMB, action: "pan" },
      { buttons: RMB, ctrl: true, action: "pan" }
    ]
  },
  {
    id: "rhino",
    label: "Rhino",
    hint: "right-drag orbit · Shift+right pan · Ctrl+right zoom",
    bindings: [
      { buttons: RMB, action: "orbit" },
      { buttons: RMB, shift: true, action: "pan" },
      { buttons: RMB, ctrl: true, action: "zoom" },
      { buttons: MMB, action: "pan" }
    ]
  },
  {
    id: "sketchup",
    label: "SketchUp",
    hint: "middle orbit · Shift+middle pan · scroll zoom",
    bindings: [
      { buttons: MMB, action: "orbit" },
      { buttons: MMB, shift: true, action: "pan" }
    ]
  },
  {
    id: "solidedge",
    label: "Solid Edge",
    hint: "middle orbit · Shift+middle pan · Alt+middle zoom",
    bindings: [
      { buttons: MMB, action: "orbit" },
      { buttons: MMB, shift: true, action: "pan" },
      { buttons: MMB, alt: true, action: "zoom" }
    ]
  },
  {
    id: "solidworks",
    label: "SolidWorks",
    wheelZoomsOut: true,
    hint: "middle orbit · Ctrl+middle pan · Shift+middle zoom · scroll (up = out)",
    bindings: [
      { buttons: MMB, action: "orbit" },
      { buttons: MMB, ctrl: true, action: "pan" },
      { buttons: MMB, shift: true, action: "zoom" }
    ]
  },
  {
    id: "tinkercad",
    label: "Tinkercad",
    hint: "right-drag orbit · middle pan · scroll zoom",
    bindings: [
      { buttons: RMB, action: "orbit" },
      { buttons: LMB, ctrl: true, action: "orbit" },
      { buttons: MMB, action: "pan" },
      { buttons: RMB, shift: true, action: "pan" }
    ]
  }
];
function schemeById(id) {
  return SCHEMES.find((s) => s.id === id) ?? SCHEMES[0];
}
function table(hex) {
  const s = hex.replace(/\s+/g, "");
  const out = new Uint8Array(s.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(s.slice(i * 2, i * 2 + 2), 16);
  return out;
}
table(`
  44015444025645045745055946075a46085c460a5d460b5e470d60470e61471063471164471365481467481668481769
  48186a481a6c481b6d481c6e481d6f481f70482071482173482374482475482576482677482878482979472a7a472c7a
  472d7b472e7c472f7d46307e46327e46337f463480453581453781453882443983443a83443b84433d84433e85423f85
  4240864241864142874144874045884046883f47883f48893e49893e4a893e4c8a3d4d8a3d4e8a3c4f8a3c508b3b518b
  3b528b3a538b3a548c39558c39568c38588c38598c375a8c375b8d365c8d365d8d355e8d355f8d34608d34618d33628d
  33638d32648e32658e31668e31678e31688e30698e306a8e2f6b8e2f6c8e2e6d8e2e6e8e2e6f8e2d708e2d718e2c718e
  2c728e2c738e2b748e2b758e2a768e2a778e2a788e29798e297a8e297b8e287c8e287d8e277e8e277f8e27808e26818e
  26828e26828e25838e25848e25858e24868e24878e23888e23898e238a8d228b8d228c8d228d8d218e8d218f8d21908d
  21918c20928c20928c20938c1f948c1f958b1f968b1f978b1f988b1f998a1f9a8a1e9b8a1e9c891e9d891f9e891f9f88
  1fa0881fa1881fa1871fa28720a38620a48621a58521a68522a78522a88423a98324aa8325ab8225ac8226ad8127ad81
  28ae8029af7f2ab07f2cb17e2db27d2eb37c2fb47c31b57b32b67a34b67935b77937b87838b9773aba763bbb753dbc74
  3fbc7340bd7242be7144bf7046c06f48c16e4ac16d4cc26c4ec36b50c46a52c56954c56856c66758c7655ac8645cc863
  5ec96260ca6063cb5f65cb5e67cc5c69cd5b6ccd5a6ece5870cf5773d05675d05477d1537ad1517cd2507fd34e81d34d
  84d44b86d54989d5488bd6468ed64590d74393d74195d84098d83e9bd93c9dd93ba0da39a2da37a5db36a8db34aadc32
  addc30b0dd2fb2dd2db5de2bb8de29bade28bddf26c0df25c2df23c5e021c8e020cae11fcde11dd0e11cd2e21bd5e21a
  d8e219dae319dde318dfe318e2e418e5e419e7e419eae51aece51befe51cf1e51df4e61ef6e620f8e621fbe723fde725
`);
table(`
  00000401000501010601010802010902020b02020d03030f03031204041405041606051806051a07061c08071e090720
  0a08220b09240c09260d0a290e0b2b100b2d110c2f120d31130d34140e36150e38160f3b180f3d19103f1a10421c1044
  1d11471e114920114b21114e22115024125325125527125829115a2a115c2c115f2d11612f1163311165331067341069
  36106b38106c390f6e3b0f703d0f713f0f72400f74420f75440f764510774710784910784a10794c117a4e117b4f127b
  51127c52137c54137d56147d57157e59157e5a167e5c167f5d177f5f187f601880621980641a80651a80671b80681c81
  6a1c816b1d816d1d816e1e81701f81721f817320817521817621817822817922827b23827c23827e2482802582812581
  8326818426818627818827818928818b29818c29818e2a81902a81912b81932b80942c80962c80982d80992d809b2e7f
  9c2e7f9e2f7fa02f7fa1307ea3307ea5317ea6317da8327daa337dab337cad347cae347bb0357bb2357bb3367ab5367a
  b73779b83779ba3878bc3978bd3977bf3a77c03a76c23b75c43c75c53c74c73d73c83e73ca3e72cc3f71cd4071cf4070
  d0416fd2426fd3436ed5446dd6456cd8456cd9466bdb476adc4869de4968df4a68e04c67e24d66e34e65e44f64e55064
  e75263e85362e95462ea5661eb5760ec5860ed5a5fee5b5eef5d5ef05f5ef1605df2625df2645cf3655cf4675cf4695c
  f56b5cf66c5cf66e5cf7705cf7725cf8745cf8765cf9785df9795df97b5dfa7d5efa7f5efa815ffb835ffb8560fb8761
  fc8961fc8a62fc8c63fc8e64fc9065fd9266fd9467fd9668fd9869fd9a6afd9b6bfe9d6cfe9f6dfea16efea36ffea571
  fea772fea973feaa74feac76feae77feb078feb27afeb47bfeb67cfeb77efeb97ffebb81febd82febf84fec185fec287
  fec488fec68afec88cfeca8dfecc8ffecd90fecf92fed194fed395fed597fed799fed89afdda9cfddc9efddea0fde0a1
  fde2a3fde3a5fde5a7fde7a9fde9aafdebacfcecaefceeb0fcf0b2fcf2b4fcf4b6fcf6b8fcf7b9fcf9bbfcfbbdfcfdbf
`);
table(`
  0d088710078813078916078a19068c1b068d1d068e20068f2206902406912605912805922a05932c05942e05952f0596
  31059733059735049837049938049a3a049a3c049b3e049c3f049c41049d43039e44039e46039f48039f4903a04b03a1
  4c02a14e02a25002a25102a35302a35502a45601a45801a45901a55b01a55c01a65e01a66001a66100a76300a76400a7
  6600a76700a86900a86a00a86c00a86e00a86f00a87100a87201a87401a87501a87701a87801a87a02a87b02a87d03a8
  7e03a88004a88104a78305a78405a78606a68707a68808a68a09a58b0aa58d0ba58e0ca48f0da4910ea3920fa39410a2
  9511a19613a19814a099159f9a169f9c179e9d189d9e199da01a9ca11b9ba21d9aa31e9aa51f99a62098a72197a82296
  aa2395ab2494ac2694ad2793ae2892b02991b12a90b22b8fb32c8eb42e8db52f8cb6308bb7318ab83289ba3388bb3488
  bc3587bd3786be3885bf3984c03a83c13b82c23c81c33d80c43e7fc5407ec6417dc7427cc8437bc9447aca457acb4679
  cc4778cc4977cd4a76ce4b75cf4c74d04d73d14e72d24f71d35171d45270d5536fd5546ed6556dd7566cd8576bd9586a
  da5a6ada5b69db5c68dc5d67dd5e66de5f65de6164df6263e06363e16462e26561e26660e3685fe4695ee56a5de56b5d
  e66c5ce76e5be76f5ae87059e97158e97257ea7457eb7556eb7655ec7754ed7953ed7a52ee7b51ef7c51ef7e50f07f4f
  f0804ef1814df1834cf2844bf3854bf3874af48849f48948f58b47f58c46f68d45f68f44f79044f79143f79342f89441
  f89540f9973ff9983ef99a3efa9b3dfa9c3cfa9e3bfb9f3afba139fba238fca338fca537fca636fca835fca934fdab33
  fdac33fdae32fdaf31fdb130fdb22ffdb42ffdb52efeb72dfeb82cfeba2cfebb2bfebd2afebe2afec029fdc229fdc328
  fdc527fdc627fdc827fdca26fdcb26fccd25fcce25fcd025fcd225fbd324fbd524fbd724fad824fada24f9dc24f9dd25
  f8df25f8e125f7e225f7e425f6e626f6e826f5e926f5eb27f4ed27f3ee27f3f027f2f227f1f426f1f525f0f724f0f921
`);
table(`
  00000401000501010601010802010a02020c02020e03021004031204031405041706041907051b08051d09061f0a0722
  0b07240c08260d08290e092b10092d110a30120a32140b34150b37160b39180c3c190c3e1b0c411c0c431e0c451f0c48
  210c4a230c4c240c4f260c51280b53290b552b0b572d0b592f0a5b310a5c320a5e340a5f3609613809623909633b0964
  3d09653e0966400a67420a68440a68450a69470b6a490b6a4a0c6b4c0c6b4d0d6c4f0d6c510e6c520e6d540f6d550f6d
  57106e59106e5a116e5c126e5d126e5f136e61136e62146e64156e65156e67166e69166e6a176e6c186e6d186e6f196e
  71196e721a6e741a6e751b6e771c6d781c6d7a1d6d7c1d6d7d1e6d7f1e6c801f6c82206c84206b85216b87216b88226a
  8a226a8c23698d23698f24699025689225689326679526679727669827669a28659b29649d29649f2a63a02a63a22b62
  a32c61a52c60a62d60a82e5fa92e5eab2f5ead305dae305cb0315bb1325ab3325ab43359b63458b73557b93556ba3655
  bc3754bd3853bf3952c03a51c13a50c33b4fc43c4ec63d4dc73e4cc83f4bca404acb4149cc4248ce4347cf4446d04545
  d24644d34743d44842d54a41d74b3fd84c3ed94d3dda4e3cdb503bdd513ade5238df5337e05536e15635e25734e35933
  e45a31e55c30e65d2fe75e2ee8602de9612bea632aeb6429eb6628ec6726ed6925ee6a24ef6c23ef6e21f06f20f1711f
  f1731df2741cf3761bf37819f47918f57b17f57d15f67e14f68013f78212f78410f8850ff8870ef8890cf98b0bf98c0a
  f98e09fa9008fa9207fa9407fb9606fb9706fb9906fb9b06fb9d07fc9f07fca108fca309fca50afca60cfca80dfcaa0f
  fcac11fcae12fcb014fcb216fcb418fbb61afbb81dfbba1ffbbc21fbbe23fac026fac228fac42afac62df9c72ff9c932
  f9cb35f8cd37f8cf3af7d13df7d340f6d543f6d746f5d949f5db4cf4dd4ff4df53f4e156f3e35af3e55df2e661f2e865
  f2ea69f1ec6df1ed71f1ef75f1f179f2f27df2f482f3f586f3f68af4f88ef5f992f6fa96f8fb9af9fc9dfafda1fcffa4
`);
table(`
  00204d00214e00225000225200235300245500255700255800265a00275c00275e002860002961002a63002a65002b67
  002c69002c6a002d6c002e6e002e6f002f6f002f6f00306f00306f00316f00326f00336f00336f00346f00356e01366e
  06366e0b376e0f386e12386d15396d183a6d1a3b6d1d3b6d1f3c6d213d6d233e6c243e6c263f6c28406c2a406c2b416c
  2d426c2e436c30436c31446b32456b34456b35466b36476b38486b39486b3a496b3b4a6b3d4a6b3e4b6b3f4c6b404d6b
  414d6b424e6b434f6b444f6b46506b47516b48526b49526b4a536b4b546c4c546c4d556c4e566c4f576c50576c51586c
  52596c53596c545a6c555b6d565c6d575c6d585d6d595e6d595f6d5a5f6d5b606e5c616e5d616e5e626e5f636e60646f
  61646f62656f63666f64666f646770656870666970676970686a71696b716a6c716b6c716c6d726c6e726d6e726e6f73
  6f70737071737171747272747273747374757474757575757676767777767877777878777979777a7a787b7a787c7b78
  7d7c787e7d787f7d78807e79817f798280798380798481798482798583798683798784798885798986798a87798b8779
  8c88798d89798e8a798f8a79908b79918c78928d78938e78948e78958f789690789791789892789992789a93779b9477
  9c95779d96779e96779f9777a09877a19976a29a76a39a76a49b76a59c76a69d75a89e75a99f75aa9f75aba074aca174
  ada274aea374afa473b0a473b1a573b2a672b3a772b4a872b5a971b6a971b7aa71b8ab70b9ac70baad70bbae6fbcaf6f
  beaf6fbfb06ec0b16ec1b26dc2b36dc3b46dc4b56cc5b56cc6b66bc7b76bc8b86ac9b96acbba69ccbb69cdbc68cebc68
  cfbd67d0be67d1bf66d2c066d3c165d4c264d6c364d7c463d8c563d9c562dac661dbc761dcc860ddc95fdeca5fe0cb5e
  e1cc5de2cd5ce3ce5ce4cf5be5d05ae6d159e8d259e9d358ead357ebd456ecd555edd654efd753f0d852f1d951f2da50
  f3db4ff4dc4ef6dd4df7de4cf8df4bf9e04afae149fbe248fde346fee445ffe544ffe642ffe742ffe843ffe944ffea46
`);
table(`
  0b04050d04060e05080f060910060a11070c12080d13090f140910150a12160b13170c15180d16190e181a0e191b0f1a
  1c101c1d111d1e111f1f122020132221142322142523152624162825172926172b27182d28192e291930291a312a1b33
  2b1c352c1c362d1d382e1e392e1e3b2f1f3d30203e31214031214232224333234534244734254835254a35264c36274d
  37284f372851382953382a54392b563a2c583a2c593b2d5b3b2e5d3b2f5f3c30603c31623d31643d32663e33673e3469
  3e356b3f366d3f366f3f3770403872403974403a76403b78403c79413d7b413e7d413e7f413f80414082414184414285
  41438741448840468a40478b40488d40498e3f4a8f3f4b903f4c923e4d933e4f943e50953d51953d52963c53973c5598
  3b56983b57993b589a3a599a3a5b9b3a5c9b395d9c395e9c385f9c38619d38629d38639d37649e37659e37669e37689f
  36699f366a9f366b9f366ca0366da0366fa03670a03671a03572a13573a13574a13575a13576a23578a23579a2357aa2
  357ba3357ca3357da3357ea4347fa43480a43482a43483a53484a53485a53486a53487a63488a63489a6348ba6348ca7
  348da7348ea7348fa73490a83491a83492a83493a83495a93496a93497a93498a93499aa349aaa359baa359caa359eaa
  359fab35a0ab35a1ab36a2ab36a3ab36a4ab37a5ac37a6ac37a8ac38a9ac38aaac39abac39acac3aadac3aaead3bafad
  3cb1ad3cb2ad3db3ad3eb4ad3fb5ad3fb6ad40b7ad41b8ad42b9ad43baad44bcad45bdad46bead47bfad48c0ad49c1ad
  4bc2ad4cc3ad4dc4ad4fc5ad50c6ad52c7ad53c9ad55caad57cbad59ccad5bcdad5ecdad60ceac62cfac65d0ad68d1ad
  6ad2ad6dd3ad70d4ad73d4ad76d5ae79d6ae7cd6af7fd7af82d8b085d9b188d9b18bdab28edbb391dbb494dcb596ddb5
  99ddb69cdeb79edfb8a1dfb9a4e0bba6e1bca9e1bdabe2beaee3c0b0e4c1b2e4c2b5e5c4b7e6c5b9e6c7bbe7c8bee8ca
  c0e9ccc2e9cdc4eacfc6ebd1c8ecd2caedd4ccedd6ceeed7d0efd9d2f0dbd4f1dcd6f1ded8f2e0daf3e1dcf4e3def5e5
`);
table(`
  03051a04051a05061b06071c07071d08081e0a091f0b09200d0a210e0b22100b23110c24130d25140e26160e27170f28
  180f291a102a1b112b1d112c1e122d20122e2113302213312414322514332715342815352a16362b16372d17382e1739
  30173a31183b33183c34193d35193e37193f381a403a1a413c1a423d1a423f1b43401b44421b45431c46451c47461c48
  481c48491d494b1d4a4c1d4b4e1d4b501d4c511e4d531e4d541e4e561e4f581e4f591e505b1e515c1e515e1f52601f52
  611f53631f53641f54661f54681f55691f556b1f566d1f566e1f57701f57711f57731f58751f58761f58781f597a1f59
  7b1f597d1f5a7f1e5a811e5a821e5a841e5a861e5b871e5b891e5b8b1d5b8c1d5b8e1d5b901d5b921c5b931c5b951c5b
  971c5b981b5b9a1b5b9c1b5b9e1a5b9f1a5ba11a5ba3195ba4195ba6195aa8185aaa185aab185aad1759af1759b01759
  b21758b41658b51657b71657b91657ba1656bc1656bd1655bf1654c11754c21753c41753c51852c71951c81951ca1a50
  cb1b4fcd1c4ece1d4ecf1e4dd11f4cd2204cd3214bd5224ad62449d72549d82748d92847db2946dc2b46dd2c45de2e44
  df2f44e03143e13342e23442e33641e43841e53940e63b40e73d3fe83f3fe8403ee9423eea443eeb463eeb483eec4a3e
  ec4c3eed4e3eed503eee523fee543fef5640ef5840ef5a41f05c42f05e42f06043f16244f16445f16646f26747f26948
  f26b49f26d4bf26f4cf3714df3734ef37450f37651f37852f47a54f47c55f47d57f47f58f4815af4835bf4845df4865e
  f58860f58a61f58b63f58d64f58f66f59067f59269f5946bf5966cf5976ef59970f69b71f69c73f69e75f6a077f6a178
  f6a37af6a47cf6a67ef6a880f6a981f6ab83f6ad85f6ae87f6b089f6b18bf6b38df6b48ff6b691f6b893f6b995f6bb97
  f6bc99f6be9bf6bf9df6c19ff7c2a2f7c4a4f7c6a6f7c7a8f7c9aaf7caacf7ccaff7cdb1f7cfb3f7d0b5f8d1b8f8d3ba
  f8d4bcf8d6bef8d7c0f8d9c3f8dac5f8dcc7f9ddc9f9dfcbf9e0cdf9e2d0f9e3d2f9e5d4fae6d6fae8d8fae9dafaebdd
`);
table(`
  30123b32154333184a341b51351e5836215f37246638276d392a733a2d793b2f803c32863d358b3e38913f3b973f3e9c
  4040a24143a74146ac4249b1424bb5434eba4451bf4454c34456c74559cb455ccf455ed34661d64664da4666dd4669e0
  466be3476ee64771e94773eb4776ee4778f0477bf2467df44680f64682f84685fa4687fb458afc458cfd448ffe4391fe
  4294ff4196ff4099ff3e9bfe3d9efe3ba0fd3aa3fc38a5fb37a8fa35abf833adf731aff52fb2f42eb4f22cb7f02ab9ee
  28bceb27bee925c0e723c3e422c5e220c7df1fc9dd1ecbda1ccdd81bd0d51ad2d21ad4d019d5cd18d7ca18d9c818dbc5
  18ddc218dec018e0bd19e2bb19e3b91ae4b61ce6b41de7b21fe9af20eaac22ebaa25eca727eea42aefa12cf09e2ff19b
  32f29835f39438f4913cf58e3ff68a43f78746f8844af8804ef97d52fa7a55fa7659fb735dfc6f61fc6c65fd6969fd66
  6dfe6271fe5f75fe5c79fe597dff5680ff5384ff5188ff4e8bff4b8fff4992ff4796fe4499fe429cfe409ffd3fa1fd3d
  a4fc3ca7fc3aa9fb39acfb38affa37b1f936b4f836b7f735b9f635bcf534bef434c1f334c3f134c6f034c8ef34cbed34
  cdec34d0ea34d2e935d4e735d7e535d9e436dbe236dde037dfdf37e1dd37e3db38e5d938e7d739e9d539ebd339ecd13a
  eecf3aefcd3af1cb3af2c93af4c73af5c53af6c33af7c13af8be39f9bc39faba39fbb838fbb637fcb336fcb136fdae35
  fdac34fea933fea732fea431fea130fe9e2ffe9b2dfe992cfe962bfe932afe9029fd8d27fd8a26fc8725fc8423fb8122
  fb7e21fa7b1ff9781ef9751df8721cf76f1af66c19f56918f46617f36315f26014f15d13f05b12ef5811ed5510ec530f
  eb500eea4e0de84b0ce7490ce5470be4450ae2430ae14109df3f08dd3d08dc3b07da3907d83706d63506d43305d23105
  d02f05ce2d04cc2b04ca2a04c82803c52603c32503c12302be2102bc2002b91e02b71d02b41b01b21a01af1801ac1701
  a91601a71401a41301a112019e10019b0f01980e01950d01920b018e0a018b09028808028507028106027e05027a0403
`);
const UNMEASURED_RGB = [126, 131, 138];
Uint8Array.from([0, 0, 255, 0, 255, 255, 0, 200, 0, 255, 255, 0, 255, 0, 0]);
const STAGE_LIGHT = 14605526;
const STAGE = STAGE_LIGHT;
const VIEW_THEMES = [
  {
    id: "studio",
    label: "Studio grey",
    hint: "Matt grey part, evenly lit",
    stage: STAGE,
    // The machined-aluminium grey a map's unmeasured patches wear too — the two
    // mean the same thing here, that nothing has been measured on this surface.
    surface: UNMEASURED_RGB,
    nominal: 6063805,
    backface: 10247024,
    finish: { roughness: 0.62, metalness: 0.05 },
    lights: { sky: 16777215, ground: 12170926, hemisphere: 1, ambient: 0.35, key: 1.6 },
    // Ink on grey: every dark accent reads on the matt surface, and the brush
    // ring can afford to wear the marking's own tint.
    accents: {
      brushRing: null,
      brushErase: 2500650,
      marqueeStroke: "#12161a",
      marqueeFill: "rgba(255, 255, 255, 0.14)",
      marqueeEraseStroke: "#fbfaf7",
      marqueeEraseFill: "rgba(18, 22, 26, 0.16)",
      callout: 2500650,
      ghost: 9343640
    },
    // On the dark stage the ink goes the other way, the same way the scanner
    // scheme's does on its blue: the callouts and the marquee are drawn over
    // the stage and would vanish into it. The erase footprint stays ink — it
    // sits on the part, which is still grey.
    darkAccents: {
      brushRing: null,
      brushErase: 2500650,
      marqueeStroke: "#ffffff",
      marqueeFill: "rgba(255, 255, 255, 0.14)",
      marqueeEraseStroke: "#f0a63c",
      marqueeEraseFill: "rgba(18, 22, 26, 0.2)",
      callout: 15262938,
      ghost: 12765132
    }
  },
  {
    id: "scanner",
    label: "Scanner blue",
    hint: "Glossy blue under a hard light — surface detail stands out",
    stage: STAGE,
    // Deeper and duller than the first of the element colours (a saturated
    // #1877c0), which is painted straight onto this surface and has to read as
    // a patch on it. The hard key lifts it back to the familiar scanner blue —
    // this is the albedo, not what is seen.
    surface: [20, 92, 141],
    // Amber, not the studio's blue: here the scan itself is blue, and the point
    // of the reference's colour is that it is not the scan's.
    nominal: 14522943,
    backface: 12609662,
    // Glossy enough for a tight highlight, with just enough metalness to keep
    // the unlit side from going flat — but no further: the deviation ramp is
    // painted onto this same surface, and a mirror would blow its colours out.
    finish: { roughness: 0.3, metalness: 0.16 },
    // A hard key against very little fill: it is the difference between the lit
    // and the unlit side that gives a surface its form, and a bright fill would
    // flatten out exactly the shallow detail this scheme exists to show.
    lights: { sky: 10930666, ground: 2896440, hemisphere: 0.42, ambient: 0.08, key: 2.6 },
    // Ink vanishes on the blue, and so does the blue half of the element
    // palette — so the working marks go the other way: white for what a
    // gesture would take, amber (the scheme's own second colour) for what it
    // would hand back. Both read on the lit and the shadowed side alike.
    accents: {
      brushRing: 16777215,
      brushErase: 15771196,
      marqueeStroke: "#ffffff",
      marqueeFill: "rgba(255, 255, 255, 0.14)",
      marqueeEraseStroke: "#f0a63c",
      marqueeEraseFill: "rgba(18, 22, 26, 0.2)",
      callout: 15262938,
      ghost: 12765132
    }
  }
];
const DEFAULT_THEME = VIEW_THEMES.find((t) => t.id === "scanner") ?? VIEW_THEMES[0];
function themeById(id) {
  return VIEW_THEMES.find((t) => t.id === id) ?? DEFAULT_THEME;
}
const CREASE_ANGLE_DEG = 30;
const CREASE_ANGLE_MIN = 5;
const CREASE_ANGLE_MAX = 120;
function creaseAngleOf(value) {
  const v = typeof value === "number" ? value : typeof value === "string" && value.trim() !== "" ? Number(value) : NaN;
  if (!Number.isFinite(v)) return CREASE_ANGLE_DEG;
  return Math.min(Math.max(v, CREASE_ANGLE_MIN), CREASE_ANGLE_MAX);
}
const PALETTE = ["#1877c0", "#e8590c", "#2e7d46", "#b5179e", "#c99a0a", "#0f9b9b", "#b3361c", "#6d4bbd"];
function elementColor(num) {
  return PALETTE[(num - 1) % PALETTE.length];
}
function withoutRegion(r) {
  const { region: _region, told: _told, ...fit } = r;
  return fit;
}
function freshDraft$1(kind, method, settings, edit) {
  const m = creationMethod(kind, method);
  const d = {
    kind,
    method,
    picks: [],
    pickPoints: [],
    settings,
    refs: m.slots.map(() => null),
    params: m.params.map(() => NaN),
    status: "empty",
    ...edit
  };
  return { ...d, pickSlot: nextPointPick(d) };
}
function nextPointPick(d) {
  if (!picksItsPoints(d)) return null;
  const empty = d.refs.findIndex((r) => r === null);
  return empty >= 0 ? empty : null;
}
function picksItsPoints(d) {
  const m = creationMethod(d.kind, d.method);
  return m.mode === "construct" && m.slots.length > 0 && m.slots.every((sl) => sl.role === "point" && !sl.kinds);
}
function keptOf(d) {
  if (!d?.selection || d.selection.length === 0) return null;
  return takesSurface(creationMethod(d.kind, d.method)) ? d : null;
}
function pickMethodOf(kind) {
  return kind === "circle" ? "circle-points" : "pick";
}
function methodOf(el) {
  if (el.source.type === "constructed") return el.source.method;
  return el.source.type === "picked" ? pickMethodOf(el.kind) : "fit";
}
function draftFromElement(el, elements, modelSize, settings) {
  const base = {
    kind: el.kind,
    method: methodOf(el),
    picks: [],
    pickPoints: [],
    settings: el.source.type === "fitted" ? el.source.settings : settings,
    refs: [],
    params: [],
    status: el.fit ? "ready" : "empty",
    // The draft works on the measurement; the alignment is put back on top
    // of it the same way it was the first time.
    fit: el.measured ?? el.fit,
    extend: el.extend,
    assumed: el.assumed,
    orient: el.orient,
    editId: el.id,
    name: el.name
  };
  if (el.source.type === "constructed") {
    return evalConstructDraft(
      {
        ...base,
        refs: [...el.source.refs],
        params: [...el.source.params],
        selection: el.source.selection
      },
      elements,
      modelSize
    );
  }
  if (el.source.type === "picked") return base;
  const { seeds, selection } = el.source;
  const picks = [];
  for (let i = 0; i + 2 < seeds.length; i += 3) picks.push([seeds[i], seeds[i + 1], seeds[i + 2]]);
  return { ...base, picks, selection };
}
function blockedRefs(editId, elements) {
  return editId === void 0 ? /* @__PURE__ */ new Set() : dependentsOf(editId, elements, true);
}
function defaultMethod(kind) {
  if (kind === "point") return "pick";
  if (kind === "line") return "line-two-points";
  if (kind === "circle") return "circle-points";
  return "fit";
}
function orientElement(el, byId) {
  if (!el.orient) return el;
  const measured = el.measured ?? el.fit;
  if (!measured) return el;
  const normal = referenceNormal(el.orient.ref, (id) => byId.get(id));
  let fit = measured;
  if (normal && isOrientable(measured)) {
    try {
      fit = orientFit(measured, { normal }, el.orient.relation).fit;
    } catch {
      fit = measured;
    }
  }
  return el.fit && sameFit(el.fit, fit) && el.measured === measured ? el : { ...el, fit, measured };
}
function evalConstructDraft(d, elements, modelSize) {
  const m = creationMethod(d.kind, d.method);
  if (m.mode !== "construct") return d;
  if (d.refs.some((r) => r === null) || d.params.some((p) => !Number.isFinite(p))) {
    return { ...d, status: "empty", fit: void 0, message: void 0 };
  }
  const fits = [];
  for (const id of d.refs) {
    const el = elements.find((e) => e.id === id);
    if (!el?.fit) return { ...d, status: "failed", fit: void 0, message: "A reference is unavailable." };
    fits.push(el.fit);
  }
  try {
    const fit = evaluateConstruction(d.method, fits, d.params, modelSize);
    return { ...d, status: "ready", fit, message: void 0 };
  } catch (e) {
    return {
      ...d,
      status: "failed",
      fit: void 0,
      message: e instanceof ConstructionError ? e.message : "Construction failed."
    };
  }
}
function reevaluateConstructions(elements, modelSize, planes = []) {
  const byId = /* @__PURE__ */ new Map();
  for (const p of planes) if (p.fit) byId.set(p.id, p.fit);
  for (const el of elements) if (el.fit) byId.set(el.id, el.fit);
  const settle = (el) => {
    const out = orientElement(el, byId);
    if (out.fit) byId.set(out.id, out.fit);
    return out;
  };
  return elements.map((el) => {
    if (el.source.type !== "constructed") return settle(el);
    const { method, refs, params } = el.source;
    const fits = [];
    for (const id of refs) {
      const f = byId.get(id);
      if (f) fits.push(f);
    }
    if (fits.length !== refs.length) {
      byId.delete(el.id);
      return { ...el, fit: void 0, measured: void 0, message: "A source element is unavailable." };
    }
    try {
      const fit = evaluateConstruction(method, fits, params, modelSize);
      const measured = el.orient ? fit : void 0;
      const next = el.fit && !el.orient && sameFit(el.fit, fit) ? el : { ...el, fit, measured, message: void 0 };
      return settle(next);
    } catch (e) {
      byId.delete(el.id);
      return {
        ...el,
        fit: void 0,
        measured: void 0,
        message: e instanceof ConstructionError ? e.message : "Construction failed."
      };
    }
  });
}
function sameFit(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}
function transformSource(source, m) {
  if (source.type !== "constructed") return source;
  if (source.method === "point-coords" || source.method === "point-centroid") {
    const p = transformFit(
      { kind: "point", center: source.params.slice(0, 3), sigma: 0, usedPoints: 0, regionSize: 0 },
      m
    );
    return { ...source, params: [...p.center] };
  }
  if (source.method === "plane-coords" || source.method === "plane-symmetry") {
    const [nx, ny, nz, px, py, pz, ...rest] = source.params;
    const moved = transformFit(
      { kind: "line", center: [px, py, pz], dir: [nx, ny, nz], length: 0, sigma: 0, usedPoints: 0, regionSize: 0 },
      m
    );
    if (moved.kind !== "line") return source;
    return { ...source, params: [...moved.dir, ...moved.center, ...rest] };
  }
  if (source.method === "circle-coords") {
    const [d, nx, ny, nz, cx, cy, cz] = source.params;
    const moved = transformFit(
      { kind: "line", center: [cx, cy, cz], dir: [nx, ny, nz], length: 0, sigma: 0, usedPoints: 0, regionSize: 0 },
      m
    );
    if (moved.kind !== "line") return source;
    return { ...source, params: [d, ...moved.dir, ...moved.center] };
  }
  return source;
}
function dependentsOf(id, elements, withOrient = false) {
  const doomed = /* @__PURE__ */ new Set([id]);
  let grew = true;
  while (grew) {
    grew = false;
    for (const el of elements) {
      if (doomed.has(el.id)) continue;
      const built = el.source.type === "constructed" && el.source.refs.some((r) => doomed.has(r));
      const aligned = withOrient && el.orient !== void 0 && doomed.has(el.orient.ref);
      if (built || aligned) {
        doomed.add(el.id);
        grew = true;
      }
    }
  }
  return doomed;
}
const freshCounters = () => ({
  point: 1,
  line: 1,
  plane: 1,
  sphere: 1,
  cylinder: 1,
  cone: 1,
  circle: 1,
  torus: 1
});
function alignSlotPicks(ad, slot) {
  return slot === "primary" ? ad.primaryPicks : slot === "secondary" ? ad.secondaryPicks : ad.originPicks;
}
function withSlotRef(ad, slot, id) {
  const base = { ...ad, pickSlot: ad.pickSlot === slot ? null : ad.pickSlot, proposal: void 0 };
  if (slot === "primary")
    return { ...base, primary: id, primaryPicks: [], primaryPickNormals: [] };
  if (slot === "secondary") return { ...base, secondary: id, secondaryPicks: [] };
  return { ...base, origin: id, originPicks: [] };
}
function withSlotPicks(ad, slot, picks, normals = []) {
  const base = { ...ad, proposal: void 0 };
  if (slot === "primary")
    return { ...base, primary: null, primaryPicks: picks, primaryPickNormals: normals };
  if (slot === "secondary") return { ...base, secondary: null, secondaryPicks: picks };
  return { ...base, origin: null, originPicks: picks };
}
function fitCircle2d(pu0, pv0) {
  const n = pu0.length;
  if (n < 3) return null;
  let mu = 0, mv = 0;
  for (let i = 0; i < n; i++) {
    mu += pu0[i];
    mv += pv0[i];
  }
  mu /= n;
  mv /= n;
  const pu = new Float64Array(n);
  const pv = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    pu[i] = pu0[i] - mu;
    pv[i] = pv0[i] - mv;
  }
  let suu = 0, suv = 0, svv = 0, su = 0, sv = 0, sub3 = 0, svb = 0, sb = 0;
  for (let i = 0; i < n; i++) {
    const b = pu[i] * pu[i] + pv[i] * pv[i];
    suu += pu[i] * pu[i];
    suv += pu[i] * pv[i];
    svv += pv[i] * pv[i];
    su += pu[i];
    sv += pv[i];
    sub3 += pu[i] * b;
    svb += pv[i] * b;
    sb += b;
  }
  const a = new Float64Array([
    4 * suu,
    4 * suv,
    2 * su,
    4 * suv,
    4 * svv,
    2 * sv,
    2 * su,
    2 * sv,
    n
  ]);
  const sol = solveLinear(3, a, new Float64Array([2 * sub3, 2 * svb, sb]));
  if (!sol) return null;
  let cu = sol[0];
  let cv = sol[1];
  const r2 = sol[2] + cu * cu + cv * cv;
  if (!(r2 > 0) || !Number.isFinite(r2)) return null;
  let r = Math.sqrt(r2);
  for (let iter = 0; iter < 100; iter++) {
    let sd = 0, sxu = 0, sxv = 0, m = 0;
    for (let i = 0; i < n; i++) {
      const du = pu[i] - cu;
      const dv = pv[i] - cv;
      const dist = Math.hypot(du, dv);
      if (dist < 1e-12) continue;
      sd += dist;
      sxu += du / dist;
      sxv += dv / dist;
      m++;
    }
    if (m === 0) break;
    const rNew = sd / m;
    const nu = su / n - rNew * (sxu / m);
    const nv = sv / n - rNew * (sxv / m);
    const move = Math.hypot(nu - cu, nv - cv);
    cu = nu;
    cv = nv;
    r = rNew;
    if (move < 1e-10 * Math.max(1, r)) break;
  }
  if (!Number.isFinite(cu) || !Number.isFinite(cv) || !Number.isFinite(r) || !(r > 0)) return null;
  return { cu: cu + mu, cv: cv + mv, r };
}
const SHADOW_TOLERANCE = 0.1;
const SHADOW_SMOOTH_DEG = 30;
function shiftShadow(cut, to) {
  const sh = cut.shadow;
  if (!sh) return null;
  const from = sh.frame;
  const same = (a, b) => Math.abs(a[0] - b[0]) < 1e-9 && Math.abs(a[1] - b[1]) < 1e-9 && Math.abs(a[2] - b[2]) < 1e-9;
  if (!same(from.normal, to.normal) || !same(from.basisU, to.basisU) || !same(from.basisV, to.basisV)) return null;
  const dx = to.origin[0] - from.origin[0];
  const dy = to.origin[1] - from.origin[1];
  const dz = to.origin[2] - from.origin[2];
  const along2 = dx * to.normal[0] + dy * to.normal[1] + dz * to.normal[2];
  if (Math.hypot(dx - along2 * to.normal[0], dy - along2 * to.normal[1], dz - along2 * to.normal[2]) > 1e-9) return null;
  const points = cut.points.slice();
  for (let i = 0; i < points.length; i += 3) {
    points[i] += dx;
    points[i + 1] += dy;
    points[i + 2] += dz;
  }
  return {
    points,
    offsets: cut.offsets,
    ...cut.normals ? { normals: cut.normals } : {},
    shadow: { ...sh, frame: to, extent: { min: sh.extent.min - along2, max: sh.extent.max - along2 } }
  };
}
const isShadow = (s) => s?.kind === "shadow";
const SHADOW_PLAY = 1;
function shadowParams(s) {
  const play = s.play !== void 0 && Number.isFinite(s.play) ? s.play : SHADOW_PLAY;
  const tolerance = s.tolerance !== void 0 && s.tolerance > 0 ? s.tolerance : SHADOW_TOLERANCE;
  const smoothDeg = s.smoothDeg !== void 0 && s.smoothDeg >= 0 ? Math.min(s.smoothDeg, 180) : SHADOW_SMOOTH_DEG;
  return { play, tolerance, smoothDeg, extrude: s.extrude ?? true };
}
function sectionKeyOf(frame, spec) {
  if (!isShadow(spec)) return frameKey(frame);
  const { play, tolerance, smoothDeg } = shadowParams(spec);
  return `${frameKey(frame)}|shadow|${play}|${tolerance}|${smoothDeg}`;
}
function specFields(s) {
  if (!isShadow(s)) return {};
  return {
    kind: "shadow",
    ...s.play !== void 0 ? { play: s.play } : {},
    ...s.tolerance !== void 0 ? { tolerance: s.tolerance } : {},
    ...s.smoothDeg !== void 0 ? { smoothDeg: s.smoothDeg } : {},
    ...s.extrude !== void 0 ? { extrude: s.extrude } : {}
  };
}
function sectionMeasureRefs(sections) {
  return sections.map((sec) => ({
    id: sec.id,
    name: sec.name,
    kind: "plane",
    color: sec.color,
    fit: sectionPlane(sec.frame, sec.cut),
    section: true
  }));
}
function dimensionRefsOf(elements, sections) {
  return sections.length === 0 ? [...elements] : [...elements, ...sectionMeasureRefs(sections)];
}
function settleSectionDraft(d) {
  const frame = d.axis ? sectionFrameAlong(d.axis, d.offset, d.seedU) : null;
  if (!frame) return { ...d, frame: null, status: "empty", message: void 0 };
  const ready = d.cut !== void 0 && d.cutKey === sectionKeyOf(frame, d);
  return { ...d, frame, status: ready ? "ready" : "slicing", message: void 0 };
}
function centreShadowDraft(d) {
  const sh = d.cut?.shadow;
  if (!isShadow(d) || !sh || !d.frame || d.cutKey !== sectionKeyOf(d.frame, d)) return d;
  const mid3 = (sh.extent.min + sh.extent.max) / 2;
  if (!(Math.abs(mid3) > 1e-6)) return d;
  const moved = settleSectionDraft({ ...d, offset: d.offset + mid3 });
  const cut = moved.frame ? shiftShadow(d.cut, moved.frame) : null;
  if (!moved.frame || !cut) return d;
  return settleSectionDraft({ ...moved, cut, cutKey: sectionKeyOf(moved.frame, moved) });
}
function sectionDraftReady(d) {
  return d !== null && d.status === "ready" && d.cut !== void 0 && d.cut.offsets.length > 1;
}
const NAV_SCHEME_KEY = "scanruler.navscheme";
const VIEW_THEME_KEY = "scanruler.viewtheme";
const STEP_STYLE_KEY = "scanruler.stepstyle";
const CLOUD_FORMAT_KEY = "scanruler.cloudformat";
const CREASE_KEY = "scanruler.crease";
const CREASE_ANGLE_KEY = "scanruler.creaseangle";
const storedNavScheme = () => {
  try {
    return schemeById(localStorage.getItem(NAV_SCHEME_KEY)).id;
  } catch {
    return SCHEMES[0].id;
  }
};
const storedViewTheme = () => {
  try {
    return themeById(localStorage.getItem(VIEW_THEME_KEY)).id;
  } catch {
    return DEFAULT_THEME.id;
  }
};
const storedStepStyle = () => {
  try {
    return localStorage.getItem(STEP_STYLE_KEY) === "surfaces" ? "surfaces" : "solids";
  } catch {
    return "solids";
  }
};
const storedCloudFormat = () => {
  try {
    return localStorage.getItem(CLOUD_FORMAT_KEY) === "xyz" ? "xyz" : "ply";
  } catch {
    return "ply";
  }
};
const storedCreaseMode = () => {
  try {
    const v = localStorage.getItem(CREASE_KEY);
    return v === "auto" || v === "off" ? v : "on";
  } catch {
    return "on";
  }
};
const storedCreaseAngle = () => {
  try {
    return creaseAngleOf(localStorage.getItem(CREASE_ANGLE_KEY));
  } catch {
    return creaseAngleOf(null);
  }
};
function freshScanState() {
  return {
    elements: [],
    draft: null,
    // A marking indexes the vertices of the scan it was made on.
    discarded: null,
    dimensions: [],
    dimDraft: null,
    alignDraft: null,
    // Sections are cuts through this scan and go with it.
    sections: [],
    sectionDraft: null,
    nextSectionNumber: 1,
    appliedAlignment: null,
    nextNumber: 1,
    nextOfKind: freshCounters(),
    nextOfDimGroup: { distance: 1, angle: 1 },
    vertexCount: 0,
    triangleCount: 0,
    scanHidden: false,
    elementsHidden: false
  };
}
function rebuilt(elements, s) {
  return reevaluateConstructions(elements, s.modelSize, sectionMeasureRefs(s.sections));
}
function withoutRefs(s, doomed) {
  const keepRef = (r) => r !== null && doomed.has(r) ? null : r;
  const dropOrient = (e) => e.orient && doomed.has(e.orient.ref) ? { ...e, orient: void 0, fit: e.measured ?? e.fit, measured: void 0 } : e;
  const dropDraftRefs = (d) => {
    const out = d.orient && doomed.has(d.orient.ref) ? { ...d, orient: void 0 } : d;
    return out.seed != null && doomed.has(out.seed) ? { ...out, seed: null } : out;
  };
  const sections = s.sections.filter((sec) => !doomed.has(sec.id));
  const elements = rebuilt(s.elements.filter((e) => !doomed.has(e.id)).map(dropOrient), { ...s, sections });
  const dimensions = s.dimensions.filter((d) => !d.refs.some((r) => doomed.has(r)));
  const dd = s.dimDraft;
  return {
    elements,
    dimensions,
    // A section keeps its frozen plane whatever happens to the element
    // it was cut along; only the name in the record goes.
    sections: sections.map(
      (sec) => doomed.has(sectionRefElement(sec.ref) ?? -1) ? { ...sec, ref: null } : sec
    ),
    sectionDraft: s.sectionDraft?.editId !== void 0 && doomed.has(s.sectionDraft.editId) ? null : s.sectionDraft && doomed.has(sectionRefElement(s.sectionDraft.ref) ?? -1) ? { ...s.sectionDraft, ref: null } : s.sectionDraft,
    alignDraft: s.alignDraft ? {
      ...s.alignDraft,
      primary: keepRef(s.alignDraft.primary),
      secondary: keepRef(s.alignDraft.secondary),
      origin: keepRef(s.alignDraft.origin)
    } : null,
    // A dimension open for editing that went with the rest closes.
    dimDraft: !dd || dd.editId !== void 0 && !dimensions.some((d) => d.id === dd.editId) ? null : { ...dd, refs: dd.refs.map((r) => r !== null && doomed.has(r) ? null : r) },
    // Deleting the element that is open for editing closes the editor —
    // there is nothing left to write back to.
    draft: s.draft?.editId !== void 0 && doomed.has(s.draft.editId) ? null : s.draft && s.draft.refs.some((r) => r !== null && doomed.has(r)) ? evalConstructDraft(
      dropDraftRefs({
        ...s.draft,
        refs: s.draft.refs.map((r) => r !== null && doomed.has(r) ? null : r)
      }),
      dimensionRefsOf(elements, sections),
      s.modelSize
    ) : s.draft ? dropDraftRefs(s.draft) : null
  };
}
create()((set, get) => ({
  projectName: null,
  setProjectName: (name) => set({ projectName: name?.trim() || null }),
  fileName: null,
  ...freshScanState(),
  modelSize: 1,
  modelCenter: [0, 0, 0],
  busy: false,
  working: null,
  statusText: "",
  progress: null,
  errorText: null,
  nextId: 1,
  nextDimensionId: 1,
  settings: { method: "gaussian", sigma: 3 },
  selectMode: "auto",
  showLabels: true,
  showBackfaces: true,
  translucent: false,
  wireframe: false,
  scanColors: false,
  showScanColors: true,
  navScheme: storedNavScheme(),
  viewTheme: storedViewTheme(),
  stepStyle: storedStepStyle(),
  cloudFormat: storedCloudFormat(),
  creaseMode: storedCreaseMode(),
  creaseAngle: storedCreaseAngle(),
  imprintOpen: false,
  setStatus: (statusText) => set({ statusText, progress: null }),
  setError: (errorText) => set({ errorText }),
  setWorking: (working) => set({ working }),
  beginLoad: (name) => set({
    busy: true,
    fileName: name,
    statusText: "Reading file…",
    errorText: null,
    ...freshScanState()
  }),
  // The brush is sized to the part it will be used on — see markStore, which
  // holds it for both workspaces.
  finishLoad: (vertexCount, triangleCount, modelSize, modelCenter) => set({ busy: false, vertexCount, triangleCount, modelSize, modelCenter }),
  loadFailed: (message) => set({ busy: false, fileName: null, statusText: "", errorText: message }),
  resolveFit: (id, r) => set((s) => ({
    elements: rebuilt(
      s.elements.map(
        (e) => e.id === id ? {
          ...e,
          status: "done",
          fit: withoutRegion(r),
          // An aligned element re-fits onto its measurement; the
          // re-evaluation pass puts the alignment back on top.
          measured: e.orient ? withoutRegion(r) : void 0
        } : e
      ),
      s
    )
  })),
  // A failed re-fit keeps the element's previous result; a failed first fit
  // removes the placeholder entry.
  failFit: (id, message) => set((s) => ({
    errorText: message,
    elements: s.elements.flatMap((e) => {
      if (e.id !== id) return [e];
      return e.fit ? [{ ...e, status: "done" }] : [];
    })
  })),
  // Deleting an element takes every construction built on it along, and every
  // dimension that references anything removed.
  removeElement: (id) => set((s) => withoutRefs(s, dependentsOf(id, s.elements))),
  toggleElementVisible: (id) => set((s) => ({
    elements: s.elements.map((e) => e.id === id ? { ...e, visible: !e.visible } : e)
  })),
  setAllElementsVisible: (visible) => set((s) => ({ elements: s.elements.map((e) => e.visible === visible ? e : { ...e, visible }) })),
  startDraft: (kind) => set((s) => ({
    draft: freshDraft$1(kind, defaultMethod(kind), s.settings),
    discarded: null,
    dimDraft: null,
    alignDraft: null,
    sectionDraft: null,
    errorText: null
  })),
  // How the surface of a re-opened fit was chosen comes back with it: an
  // element marked by hand opens with the marking tools out, one grown from a
  // click opens ready to be clicked again.
  editElement: (id) => set((s) => {
    const el = s.elements.find((e) => e.id === id);
    if (!el) return {};
    const draft = draftFromElement(el, dimensionRefsOf(s.elements, s.sections), s.modelSize, s.settings);
    return {
      draft,
      discarded: null,
      selectMode: el.source.type === "picked" ? s.selectMode : el.source.selection ? "paint" : el.source.type === "fitted" || takesSurface(creationMethod(el.kind, el.source.method)) ? "auto" : s.selectMode,
      alignDraft: null,
      sectionDraft: null,
      errorText: null
    };
  }),
  setDraftName: (name) => set((s) => s.draft ? { draft: { ...s.draft, name } } : {}),
  setDraftMethod: (method) => set((s) => {
    if (!s.draft) return {};
    const { editId, name, settings } = s.draft;
    return {
      draft: evalConstructDraft(
        freshDraft$1(s.draft.kind, method, settings, { editId, name }),
        s.elements,
        s.modelSize
      )
    };
  }),
  setDraftPicks: (picks, points) => set((s) => {
    if (!s.draft) return {};
    const min = creationMethod(s.draft.kind, s.draft.method).minPicks ?? 1;
    return {
      draft: {
        ...s.draft,
        picks,
        pickPoints: points ?? [],
        fit: void 0,
        message: void 0,
        status: picks.length >= min ? "fitting" : "empty"
      }
    };
  }),
  setDraftPickPoints: (points) => set((s) => s.draft ? { draft: { ...s.draft, pickPoints: points } } : {}),
  setDraftSelection: (selection) => set((s) => {
    if (!s.draft) return {};
    const m = creationMethod(s.draft.kind, s.draft.method);
    if (m.mode === "construct") {
      return {
        draft: {
          ...s.draft,
          selection: selection ?? void 0,
          params: m.params.map(() => NaN),
          fit: void 0,
          message: void 0,
          note: selection ? `The search is confined to the ${selection.length.toLocaleString("en-US")} marked points.` : void 0,
          status: "empty"
        }
      };
    }
    return {
      draft: {
        ...s.draft,
        selection: selection ?? void 0,
        fit: void 0,
        message: void 0,
        status: selection ? "fitting" : "empty"
      }
    };
  }),
  setDraftRef: (slot, id) => set((s) => {
    if (!s.draft) return {};
    if (id !== null && blockedRefs(s.draft.editId, s.elements).has(id)) return {};
    const refs = s.draft.refs.map((r, i) => i === slot ? id : r);
    const draft = evalConstructDraft({ ...s.draft, refs }, dimensionRefsOf(s.elements, s.sections), s.modelSize);
    const waiting = s.draft.pickSlot;
    const pickSlot = waiting != null && refs[waiting] === null ? waiting : nextPointPick(draft);
    return { draft: { ...draft, pickSlot } };
  }),
  beginDraftPick: (slot) => set((s) => {
    if (!s.draft) return {};
    const m = creationMethod(s.draft.kind, s.draft.method);
    if (m.mode !== "construct" || m.slots[slot]?.role !== "point") return {};
    const refs = s.draft.refs.map((r, i) => i === slot ? null : r);
    return {
      draft: { ...evalConstructDraft({ ...s.draft, refs }, dimensionRefsOf(s.elements, s.sections), s.modelSize), pickSlot: slot },
      errorText: null
    };
  }),
  cancelDraftPick: () => set((s) => s.draft && s.draft.pickSlot != null ? { draft: { ...s.draft, pickSlot: null } } : {}),
  pickDraftPoint: (point) => {
    const d = get().draft;
    if (!d || d.pickSlot == null) return null;
    const slot = d.pickSlot;
    const fit = { kind: "point", center: point, sigma: 0, usedPoints: 0, regionSize: 0 };
    const id = get().nextId;
    const num = get().nextNumber;
    const ofKind = get().nextOfKind.point;
    set((s) => {
      if (!s.draft) return {};
      const elements = [
        ...s.elements,
        {
          id,
          kind: "point",
          name: `${elementKindInfo("point").label} ${ofKind}`,
          color: elementColor(num),
          source: { type: "picked" },
          status: "done",
          visible: true,
          fit
        }
      ];
      const refs = s.draft.refs.map((r, i) => i === slot ? id : r);
      const draft = evalConstructDraft({ ...s.draft, refs, pickSlot: null }, dimensionRefsOf(elements, s.sections), s.modelSize);
      return {
        nextId: id + 1,
        nextNumber: num + 1,
        nextOfKind: { ...s.nextOfKind, point: ofKind + 1 },
        elements,
        draft: { ...draft, pickSlot: nextPointPick(draft) }
      };
    });
    return id;
  },
  setDraftParam: (index, value) => set((s) => {
    if (!s.draft) return {};
    const params = s.draft.params.map((p, i) => i === index ? value : p);
    return { draft: evalConstructDraft({ ...s.draft, params }, dimensionRefsOf(s.elements, s.sections), s.modelSize) };
  }),
  setDraftParams: (params, note) => set((s) => {
    if (!s.draft) return {};
    return {
      draft: { ...evalConstructDraft({ ...s.draft, params }, dimensionRefsOf(s.elements, s.sections), s.modelSize), note }
    };
  }),
  setDraftWorking: (note) => set(
    (s) => s.draft ? { draft: { ...s.draft, status: "fitting", message: void 0, note } } : {}
  ),
  setDraftSeed: (id) => set((s) => s.draft ? { draft: { ...s.draft, seed: id } } : {}),
  setDraftExtend: (side, value) => set((s) => {
    const d = s.draft;
    if (!d || !isExtendable(d.fit)) return {};
    const ext = extensionOf(d.fit, d.extend);
    return { draft: { ...d, extend: withSide(d.fit, ext, side, value) } };
  }),
  squareDraftExtend: () => set((s) => {
    const d = s.draft;
    if (!d || d.fit?.kind !== "plane") return {};
    return { draft: { ...d, extend: squareExtension(d.fit, d.extend) } };
  }),
  setDraftFitInside: (on) => set((s) => {
    const d = s.draft;
    if (!d || d.fit?.kind !== "cylinder") return {};
    return { draft: { ...d, extend: withFitInside(extensionOf(d.fit, d.extend), on) } };
  }),
  resetDraftExtend: () => set((s) => {
    const d = s.draft;
    if (!d || !isExtendable(d.fit)) return {};
    const zero = zeroExtension(d.fit);
    return { draft: { ...d, extend: withFitInside(zero, fitsInside(d.extend)) } };
  }),
  setDraftAssumed: (value) => set((s) => {
    const d = s.draft;
    if (!d || !hasDiameter(d.fit)) return {};
    if (value === void 0) return { draft: { ...d, assumed: void 0 } };
    if (!Number.isFinite(value) || value <= 0) return {};
    return { draft: { ...d, assumed: value } };
  }),
  setDraftOrientRef: (ref) => set((s) => {
    const d = s.draft;
    if (!d) return {};
    if (ref === null) return { draft: { ...d, orient: void 0 } };
    if (!isOrientRef(ref, dimensionRefsOf(s.elements, s.sections)) || blockedRefs(d.editId, s.elements).has(ref)) return {};
    return { draft: { ...d, orient: { ref, relation: d.orient?.relation ?? "normal" } } };
  }),
  setDraftOrientRelation: (relation) => set((s) => {
    const d = s.draft;
    if (!d?.orient) return {};
    return { draft: { ...d, orient: { ...d.orient, relation } } };
  }),
  resolveDraft: (r) => set(
    (s) => s.draft ? { draft: { ...s.draft, status: "ready", fit: withoutRegion(r), message: void 0 } } : {}
  ),
  // A failed preview keeps the picks so the user can undo the bad one instead
  // of starting over.
  failDraft: (message) => set((s) => s.draft ? { draft: { ...s.draft, status: "failed", message } } : {}),
  cancelDraft: () => set((s) => ({
    draft: null,
    discarded: keptOf(s.draft),
    // A pick that was feeding a dimension slot is abandoned with it.
    dimDraft: s.dimDraft ? { ...s.dimDraft, pickSlot: null } : null
  })),
  restartDraft: () => set(
    (s) => s.draft && s.draft.editId === void 0 ? { draft: freshDraft$1(s.draft.kind, s.draft.method, s.draft.settings), errorText: null } : {}
  ),
  restoreDraft: () => set((s) => {
    const d = s.discarded;
    if (!d || s.draft) return {};
    const alive = (id) => id != null && (s.elements.some((e) => e.id === id) || s.sections.some((sec) => sec.id === id));
    const edit = alive(d.editId) ? { editId: d.editId, name: d.name } : { editId: void 0, name: void 0 };
    return {
      draft: {
        ...d,
        ...edit,
        seed: alive(d.seed) || d.seed != null && d.seed < 0 ? d.seed : null,
        refs: d.refs.map((r) => alive(r) ? r : null),
        orient: d.orient && (alive(d.orient.ref) || basePlaneOf(d.orient.ref) !== void 0) ? d.orient : void 0,
        status: "empty",
        fit: void 0,
        message: void 0,
        note: void 0
      },
      selectMode: "paint",
      discarded: null,
      alignDraft: null,
      sectionDraft: null,
      errorText: null
    };
  }),
  forgetDiscarded: () => set({ discarded: null }),
  commitDraft: () => {
    const d = get().draft;
    if (!d || d.status !== "ready" || !d.fit) return null;
    const m = creationMethod(d.kind, d.method);
    const extend = isExtendable(d.fit) && d.extend?.kind === d.fit.kind && isExtended(d.extend) ? d.extend : void 0;
    const assumed = hasDiameter(d.fit) && d.assumed !== void 0 && d.assumed > 0 ? d.assumed : void 0;
    const orient = isOrientable(d.fit) && d.orient && isOrientRef(d.orient.ref, dimensionRefsOf(get().elements, get().sections)) ? d.orient : void 0;
    const measured = orient ? d.fit : void 0;
    const source = m.mode === "fit" ? d.selection ? { type: "fitted", seeds: [], selection: d.selection, settings: d.settings } : { type: "fitted", seeds: d.picks.flat(), settings: d.settings } : m.mode === "pick" ? { type: "picked" } : {
      type: "constructed",
      method: d.method,
      refs: d.refs,
      params: d.params,
      // The surface a scan search was confined to goes with the
      // element, so it re-opens marked and searches the same again.
      ...d.selection && takesSurface(m) ? { selection: d.selection } : {}
    };
    if (d.editId !== void 0) {
      const editId = d.editId;
      set((s) => ({
        draft: null,
        elements: rebuilt(
          s.elements.map(
            (e) => e.id === editId ? {
              ...e,
              name: d.name?.trim() || e.name,
              source,
              status: "done",
              fit: d.fit,
              measured,
              orient,
              extend,
              assumed,
              message: void 0
            } : e
          ),
          s
        )
      }));
      return editId;
    }
    const id = get().nextId;
    const num = get().nextNumber;
    const ofKind = get().nextOfKind[d.kind];
    const forSlot = get().dimDraft?.pickSlot != null && d.kind === "point";
    set((s) => ({
      nextId: id + 1,
      nextNumber: num + 1,
      nextOfKind: { ...s.nextOfKind, [d.kind]: ofKind + 1 },
      draft: forSlot ? null : freshDraft$1(d.kind, d.method, d.settings),
      elements: rebuilt(
        [
          ...s.elements,
          {
            id,
            kind: d.kind,
            name: `${elementKindInfo(d.kind).label} ${ofKind}`,
            color: elementColor(num),
            source,
            status: "done",
            visible: true,
            fit: d.fit,
            measured,
            orient,
            extend,
            assumed
          }
        ],
        s
      ),
      // A point picked for a dimension slot drops straight into it.
      dimDraft: s.dimDraft && s.dimDraft.pickSlot !== null && d.kind === "point" ? {
        ...s.dimDraft,
        refs: s.dimDraft.refs.map((r, i) => i === s.dimDraft.pickSlot ? id : r),
        pickSlot: null
      } : s.dimDraft
    }));
    return id;
  },
  startAlignment: () => set((s) => ({
    alignDraft: {
      primary: null,
      primaryPicks: [],
      primaryPickNormals: [],
      // The face the part stands on is the one beginners are told to pick,
      // so "bottom" — outward normal down — is the default reading of it.
      primaryAxis: "z-",
      secondary: null,
      secondaryPicks: [],
      secondaryAxis: "x+",
      origin: null,
      originPicks: [],
      pickSlot: null
    },
    draft: null,
    discarded: keptOf(s.draft),
    dimDraft: null,
    sectionDraft: null,
    errorText: null
  })),
  proposeAlignment: (proposal, note) => set((s) => ({
    alignDraft: {
      primary: null,
      primaryPicks: proposal.primary,
      primaryPickNormals: proposal.primaryNormals,
      primaryAxis: "z-",
      secondary: null,
      secondaryPicks: proposal.secondary,
      secondaryAxis: "x+",
      origin: null,
      originPicks: [proposal.origin],
      pickSlot: null,
      proposal: note
    },
    draft: null,
    discarded: keptOf(s.draft),
    dimDraft: null,
    sectionDraft: null,
    errorText: null
  })),
  cancelAlignment: () => set({ alignDraft: null }),
  startSection: () => set((s) => ({
    sectionDraft: { ref: null, offset: 0, axis: null, frame: null, status: "empty" },
    draft: null,
    discarded: keptOf(s.draft),
    dimDraft: null,
    alignDraft: null,
    errorText: null
  })),
  // The draft opens on the frozen plane, sliding along its own normal: the
  // element it was cut along may have been re-fitted or deleted since, and
  // opening the editor must not move a section nobody has touched.
  editSection: (id) => set((s) => {
    const sec = s.sections.find((x) => x.id === id);
    if (!sec) return {};
    const refEl = sectionRefElement(sec.ref);
    const refAlive = sec.ref !== null && (refEl === null || s.elements.some((e) => e.id === refEl && e.fit));
    return {
      sectionDraft: settleSectionDraft({
        ref: refAlive ? sec.ref : null,
        offset: sec.offset,
        axis: axisOfFrame(sec.frame, sec.offset),
        refDir: sec.refDir,
        seedU: sec.frame.basisU,
        frame: sec.frame,
        status: "ready",
        cut: sec.cut,
        cutKey: sec.cutKey,
        editId: sec.id,
        name: sec.name,
        ...specFields(sec)
      }),
      draft: null,
      discarded: keptOf(s.draft),
      dimDraft: null,
      alignDraft: null,
      errorText: null
    };
  }),
  cancelSection: () => set({ sectionDraft: null }),
  setSectionDraftRef: (ref) => set((s) => {
    const d = s.sectionDraft;
    if (!d) return {};
    if (ref === null)
      return { sectionDraft: settleSectionDraft({ ...d, ref: null, axis: null, refDir: void 0 }) };
    if (isWorldAxis(ref)) {
      const c = s.modelCenter;
      const axis2 = worldCutAxis(ref, c);
      const offset = d.ref === ref ? d.offset : c[0] * axis2.dir[0] + c[1] * axis2.dir[1] + c[2] * axis2.dir[2];
      return { sectionDraft: settleSectionDraft({ ...d, ref, axis: axis2, refDir: axis2.dir, offset }) };
    }
    if (isRadialRef(ref)) {
      const axis2 = sectionRefAxis(ref, s.elements, s.modelCenter);
      if (!axis2) return {};
      const offset = isRadialRef(d.ref) && d.ref.axis === ref.axis ? d.offset : 0;
      return { sectionDraft: settleSectionDraft({ ...d, ref, axis: axis2, refDir: axis2.dir, offset, seedU: void 0 }) };
    }
    const el = s.elements.find((e) => e.id === ref);
    if (!el?.fit || !canCutAlong(el.kind)) return {};
    const axis = cutAxisOf(el.fit);
    if (!axis) return {};
    return { sectionDraft: settleSectionDraft({ ...d, ref, axis, refDir: axis.dir }) };
  }),
  setSectionDraftAxis: (axis) => set((s) => {
    const d = s.sectionDraft;
    if (!d || !d.axis) return {};
    return { sectionDraft: settleSectionDraft({ ...d, axis }) };
  }),
  setSectionDraftOffset: (mm) => set((s) => {
    const d = s.sectionDraft;
    if (!d || !Number.isFinite(mm)) return {};
    return { sectionDraft: settleSectionDraft({ ...d, offset: mm }) };
  }),
  setSectionDraftName: (name) => set((s) => s.sectionDraft ? { sectionDraft: { ...s.sectionDraft, name } } : {}),
  setSectionDraftKind: (kind) => set((s) => {
    const d = s.sectionDraft;
    if (!d || (d.kind ?? "cut") === kind) return {};
    return { sectionDraft: settleSectionDraft({ ...d, kind, cut: void 0, cutKey: void 0 }) };
  }),
  setSectionDraftShadow: (patch) => set((s) => {
    const d = s.sectionDraft;
    if (!d) return {};
    const next = { ...d };
    if (patch.play !== void 0 && Number.isFinite(patch.play)) next.play = patch.play;
    if (patch.tolerance !== void 0 && Number.isFinite(patch.tolerance) && patch.tolerance > 0) next.tolerance = patch.tolerance;
    if (patch.smoothDeg !== void 0 && Number.isFinite(patch.smoothDeg) && patch.smoothDeg >= 0) next.smoothDeg = Math.min(patch.smoothDeg, 180);
    if (patch.extrude !== void 0) next.extrude = patch.extrude;
    return { sectionDraft: settleSectionDraft(next) };
  }),
  resolveSectionDraft: (cutKey, cut) => set((s) => {
    const d = s.sectionDraft;
    if (!d) return {};
    return { sectionDraft: centreShadowDraft(settleSectionDraft({ ...d, cut, cutKey })) };
  }),
  failSectionDraft: (message) => set(
    (s) => s.sectionDraft ? { sectionDraft: { ...s.sectionDraft, status: "failed", message } } : {}
  ),
  commitSection: () => {
    const d = get().sectionDraft;
    if (!d || !sectionDraftReady(d) || !d.frame || !d.cut) return null;
    const frame = d.frame;
    const cut = d.cut;
    const cutKey = sectionKeyOf(frame, d);
    if (d.editId !== void 0) {
      const editId = d.editId;
      set((s) => {
        const sections = s.sections.map((sec) => {
          if (sec.id !== editId) return sec;
          const { kind: _kind, play: _play, tolerance: _tolerance, smoothDeg: _smooth, extrude: _extrude, ...rest } = sec;
          return {
            ...rest,
            ...specFields(d),
            name: d.name?.trim() || sec.name,
            frame,
            ref: d.ref,
            refDir: d.refDir,
            offset: d.offset,
            cut,
            cutKey,
            message: void 0
          };
        });
        return { sectionDraft: null, sections, elements: rebuilt(s.elements, { ...s, sections }) };
      });
      return editId;
    }
    const id = get().nextId;
    const num = get().nextNumber;
    const n = get().nextSectionNumber;
    set((s) => ({
      nextId: id + 1,
      nextNumber: num + 1,
      nextSectionNumber: n + 1,
      sectionDraft: null,
      sections: [
        ...s.sections,
        {
          id,
          name: `Section ${n}`,
          color: elementColor(num),
          visible: true,
          frame,
          ref: d.ref,
          refDir: d.refDir,
          offset: d.offset,
          ...specFields(d),
          cut,
          cutKey
        }
      ]
    }));
    return id;
  },
  // A dimension taken from the section goes with it, and a construction
  // built on it, as they do with a deleted element.
  removeSection: (id) => set((s) => withoutRefs(s, dependentsOf(id, s.elements))),
  toggleSectionVisible: (id) => set((s) => ({
    sections: s.sections.map((sec) => sec.id === id ? { ...sec, visible: !sec.visible } : sec)
  })),
  setAllSectionsVisible: (visible) => set((s) => ({
    sections: s.sections.map((sec) => sec.visible === visible ? sec : { ...sec, visible })
  })),
  // The cut says where on its plane the section lies, which is where a
  // construction on it is drawn and measured from — so they follow.
  resolveSection: (id, cutKey, cut) => set((s) => {
    const sections = s.sections.map(
      (sec) => sec.id === id && sectionKeyOf(sec.frame, sec) === cutKey ? { ...sec, cut, cutKey, message: void 0 } : sec
    );
    return { sections, elements: rebuilt(s.elements, { ...s, sections }) };
  }),
  failSection: (id, message) => set((s) => ({
    sections: s.sections.map((sec) => sec.id === id ? { ...sec, message } : sec)
  })),
  setAlignmentRef: (slot, id) => set((s) => s.alignDraft ? { alignDraft: withSlotRef(s.alignDraft, slot, id) } : {}),
  beginAlignmentPick: (slot) => set(
    (s) => s.alignDraft ? { alignDraft: { ...withSlotPicks(s.alignDraft, slot, []), pickSlot: slot } } : {}
  ),
  addAlignmentPick: (point, normal) => set((s) => {
    const ad = s.alignDraft;
    if (!ad || ad.pickSlot === null) return {};
    const slot = ad.pickSlot;
    const picks = [...alignSlotPicks(ad, slot), point];
    const normals = slot === "primary" ? [...ad.primaryPickNormals, normal] : [];
    const full = picks.length >= ALIGN_PICK_COUNT[slot];
    return {
      alignDraft: { ...withSlotPicks(ad, slot, picks, normals), pickSlot: full ? null : slot }
    };
  }),
  undoAlignmentPick: () => set((s) => {
    const ad = s.alignDraft;
    if (!ad || ad.pickSlot === null) return {};
    const picks = alignSlotPicks(ad, ad.pickSlot);
    if (picks.length === 0) return {};
    return {
      alignDraft: {
        ...withSlotPicks(
          ad,
          ad.pickSlot,
          picks.slice(0, -1),
          ad.pickSlot === "primary" ? ad.primaryPickNormals.slice(0, -1) : []
        ),
        pickSlot: ad.pickSlot
      }
    };
  }),
  cancelAlignmentPick: () => set((s) => {
    const ad = s.alignDraft;
    if (!ad || ad.pickSlot === null) return {};
    return { alignDraft: { ...withSlotPicks(ad, ad.pickSlot, []), pickSlot: null } };
  }),
  setAlignmentAxis: (slot, axis) => set((s) => {
    if (!s.alignDraft) return {};
    if (slot === "secondary") return { alignDraft: { ...s.alignDraft, secondaryAxis: axis } };
    const secondaryAxis = axis[0] === s.alignDraft.secondaryAxis[0] ? axis[0] === "z" ? "x+" : "z+" : s.alignDraft.secondaryAxis;
    return { alignDraft: { ...s.alignDraft, primaryAxis: axis, secondaryAxis } };
  }),
  selectAlignmentElement: (id) => set((s) => {
    const ad = s.alignDraft;
    if (!ad) return {};
    const el = s.elements.find((e) => e.id === id);
    if (!el?.fit) return {};
    if (ad.primary === id) return { alignDraft: withSlotRef(ad, "primary", null) };
    if (ad.secondary === id) return { alignDraft: withSlotRef(ad, "secondary", null) };
    if (ad.origin === id) return { alignDraft: withSlotRef(ad, "origin", null) };
    const role = roleOf(el.kind);
    if (role === "point") return { alignDraft: withSlotRef(ad, "origin", id) };
    if (ad.primary === null && ad.primaryPicks.length === 0)
      return { alignDraft: withSlotRef(ad, "primary", id) };
    return { alignDraft: withSlotRef(ad, "secondary", id) };
  }),
  applyAlignment: (m) => set((s) => {
    const moved = new Float64Array(3);
    rigidApply(m, s.modelCenter[0], s.modelCenter[1], s.modelCenter[2], moved);
    const turn = (v) => {
      if (!v) return v;
      const out = new Float64Array(3);
      rigidRotate(m, v[0], v[1], v[2], out);
      return [out[0], out[1], out[2]];
    };
    const moveSection = (sec) => {
      const frame = transformFrame(sec.frame, m);
      return {
        ...sec,
        frame,
        refDir: turn(sec.refDir),
        cut: sec.cut ? transformCut(sec.cut, m) : void 0,
        cutKey: sec.cut ? sectionKeyOf(frame, sec) : void 0
      };
    };
    const moveDraft = (d) => {
      const frame = d.frame ? transformFrame(d.frame, m) : null;
      return settleSectionDraft({
        ...d,
        axis: d.axis ? transformAxis(d.axis, m) : null,
        refDir: turn(d.refDir),
        seedU: turn(d.seedU),
        frame,
        cut: d.cut ? transformCut(d.cut, m) : void 0,
        cutKey: d.cut && frame ? sectionKeyOf(frame, d) : void 0
      });
    };
    const sections = s.sections.map(moveSection);
    return {
      alignDraft: null,
      appliedAlignment: s.appliedAlignment ? rigidCompose(m, s.appliedAlignment) : m,
      modelCenter: [moved[0], moved[1], moved[2]],
      elements: rebuilt(
        s.elements.map((el) => {
          const out = {
            ...el,
            source: transformSource(el.source, m),
            fit: el.fit ? transformFit(el.fit, m) : el.fit,
            measured: el.measured ? transformFit(el.measured, m) : el.measured
          };
          if (!out.orient) return out;
          const ref = refThroughMotion(out.orient.ref, (v) => turn(v));
          return ref === null ? { ...out, orient: void 0, fit: out.measured ?? out.fit, measured: void 0 } : { ...out, orient: { ...out.orient, ref } };
        }),
        { ...s, sections }
      ),
      sections,
      sectionDraft: s.sectionDraft ? moveDraft(s.sectionDraft) : null
    };
  }),
  clearAppliedAlignment: () => set({ appliedAlignment: null }),
  // One thing in hand at a time: a dimension closes the element draft, as
  // an alignment or a section does, so a click in the viewport has one
  // taker — the slot. A marked surface is kept (see `discarded`).
  startDimension: (type) => set((s) => ({
    dimDraft: {
      type,
      refs: dimensionTypeInfo(type).slots.map(() => null),
      anchor: "center",
      pickSlot: null
    },
    draft: null,
    discarded: keptOf(s.draft),
    alignDraft: null,
    sectionDraft: null
  })),
  editDimension: (id) => set((s) => {
    const d = s.dimensions.find((x) => x.id === id);
    if (!d) return {};
    return {
      dimDraft: {
        type: d.type,
        refs: [...d.refs],
        anchor: d.anchor ?? "center",
        pickSlot: null,
        editId: d.id,
        name: d.name,
        limit: d.limit,
        basic: d.basic
      },
      draft: null,
      discarded: keptOf(s.draft),
      alignDraft: null,
      sectionDraft: null
    };
  }),
  setDimensionName: (name) => set((s) => s.dimDraft ? { dimDraft: { ...s.dimDraft, name } } : {}),
  setDimensionType: (type) => set((s) => {
    if (!s.dimDraft) return {};
    const slots = dimensionTypeInfo(type).slots;
    const signature = (t) => dimensionTypeInfo(t).slots.map((sl) => `${sl.roles.join("|")}:${(sl.kinds ?? []).join("|")}`).join(",");
    const sameRoles = signature(type) === signature(s.dimDraft.type);
    const sameUnit = dimensionTypeInfo(type).unit === dimensionTypeInfo(s.dimDraft.type).unit;
    return {
      dimDraft: {
        ...s.dimDraft,
        type,
        // Keep the picked references when the new type takes the same roles
        // (switching Axis–Axis distance → Axis–Axis angle, say).
        refs: sameRoles ? s.dimDraft.refs : slots.map(() => null),
        // A limit in millimetres means nothing to an angle, and the other
        // way round.
        limit: sameUnit ? s.dimDraft.limit : void 0,
        pickSlot: null
      }
    };
  }),
  setDimensionRef: (slot, id) => set(
    (s) => s.dimDraft ? { dimDraft: { ...s.dimDraft, refs: s.dimDraft.refs.map((r, i) => i === slot ? id : r) } } : {}
  ),
  selectDimensionElement: (id) => set((s) => {
    const dd = s.dimDraft;
    if (!dd) return {};
    const family = dimensionTypeInfo(dd.type).family;
    const pool = family === "dimension" ? dimensionRefsOf(s.elements, s.sections) : s.elements;
    const el = pool.find((e) => e.id === id);
    if (!el?.fit) return {};
    if (dd.refs.includes(id)) {
      return { dimDraft: { ...dd, refs: dd.refs.map((r) => r === id ? null : r) } };
    }
    const held = dd.refs.flatMap((r) => {
      const ref = r !== null ? pool.find((e) => e.id === r) : void 0;
      return ref ? [{ id: ref.id, kind: ref.kind }] : [];
    });
    const pick = { id, kind: el.kind };
    const grown = [...held, pick];
    const selected = selectionFits(
      family,
      grown.map((sel) => sel.kind)
    ) ? grown : [...held.slice(0, -1), pick];
    const type = resolveDimensionType(dd.type, selected.map((sel) => sel.kind));
    return {
      dimDraft: { ...dd, type, refs: assignDimensionRefs(type, selected), pickSlot: null }
    };
  }),
  setDimensionAnchor: (anchor) => set((s) => s.dimDraft ? { dimDraft: { ...s.dimDraft, anchor } } : {}),
  setDimensionLimit: (limit) => set((s) => s.dimDraft ? { dimDraft: { ...s.dimDraft, limit } } : {}),
  setDimensionBasic: (basic) => set((s) => s.dimDraft ? { dimDraft: { ...s.dimDraft, basic } } : {}),
  beginDimensionPick: (slot) => set(
    (s) => s.dimDraft ? {
      dimDraft: { ...s.dimDraft, pickSlot: slot },
      draft: freshDraft$1("point", "pick", s.settings),
      discarded: keptOf(s.draft),
      errorText: null
    } : {}
  ),
  cancelDimension: () => set({ dimDraft: null }),
  commitDimension: () => set((s) => {
    const dd = s.dimDraft;
    if (!dd || dd.refs.some((r) => r === null)) return {};
    const info = dimensionTypeInfo(dd.type);
    const key = stemKey(info);
    const n = s.nextOfDimGroup[key] ?? 1;
    if (dd.editId !== void 0) {
      const old = s.dimensions.find((d) => d.id === dd.editId);
      const typed = dd.name?.trim();
      const renamed = Boolean(typed) && typed !== old?.name;
      const regroup = !renamed && old !== void 0 && stemKey(dimensionTypeInfo(old.type)) !== key;
      const name = regroup ? `${info.stem} ${n}` : typed || (old?.name ?? "");
      return {
        dimensions: s.dimensions.map(
          (d) => d.id === dd.editId ? {
            ...d,
            type: dd.type,
            refs: dd.refs,
            anchor: dd.anchor,
            name,
            limit: dd.limit,
            basic: dd.basic
          } : d
        ),
        nextOfDimGroup: regroup ? { ...s.nextOfDimGroup, [key]: n + 1 } : s.nextOfDimGroup,
        dimDraft: null
      };
    }
    return {
      dimensions: [
        ...s.dimensions,
        {
          id: s.nextDimensionId,
          type: dd.type,
          name: `${info.stem} ${n}`,
          refs: dd.refs,
          anchor: dd.anchor,
          visible: true,
          limit: dd.limit,
          basic: dd.basic
        }
      ],
      nextDimensionId: s.nextDimensionId + 1,
      nextOfDimGroup: { ...s.nextOfDimGroup, [key]: n + 1 },
      // The box stays open for the next one of the same type, its slots
      // empty — the way the sketch's Dimension tool stays in hand — until
      // Cancel or Escape closes it.
      dimDraft: { type: dd.type, refs: info.slots.map(() => null), anchor: "center", pickSlot: null }
    };
  }),
  removeDimension: (id) => set((s) => ({
    dimensions: s.dimensions.filter((d) => d.id !== id),
    dimDraft: s.dimDraft?.editId === id ? null : s.dimDraft
  })),
  toggleDimensionVisible: (id) => set((s) => ({
    dimensions: s.dimensions.map(
      (d) => d.id === id ? { ...d, visible: d.visible === false } : d
    )
  })),
  setAllDimensionsVisible: (visible, family) => set((s) => ({
    dimensions: s.dimensions.map(
      (d) => family === void 0 || dimensionTypeInfo(d.type).family === family ? { ...d, visible } : d
    )
  })),
  setDraftSigma: (sigma) => set((s) => {
    const settings = { ...s.draft?.settings ?? s.settings, sigma };
    const { knownDiameter: _known, ...remembered } = settings;
    return { settings: remembered, draft: s.draft ? { ...s.draft, settings } : null };
  }),
  setDraftKnownDiameter: (mm) => set((s) => {
    if (!s.draft) return {};
    const { knownDiameter: _known, ...rest } = s.draft.settings;
    const settings = mm !== void 0 && Number.isFinite(mm) && mm > 0 ? { ...rest, knownDiameter: mm } : rest;
    return { draft: { ...s.draft, settings } };
  }),
  setSelectMode: (selectMode) => set({ selectMode }),
  setShowLabels: (showLabels) => set({ showLabels }),
  setScanHidden: (scanHidden) => set({ scanHidden }),
  setElementsHidden: (elementsHidden) => set({ elementsHidden }),
  setShowBackfaces: (showBackfaces) => set({ showBackfaces }),
  setTranslucent: (translucent) => set({ translucent }),
  setWireframe: (wireframe) => set({ wireframe }),
  setShowScanColors: (showScanColors) => set({ showScanColors }),
  setNavScheme: (navScheme) => {
    try {
      localStorage.setItem(NAV_SCHEME_KEY, navScheme);
    } catch {
    }
    set({ navScheme });
  },
  setViewTheme: (viewTheme) => {
    try {
      localStorage.setItem(VIEW_THEME_KEY, viewTheme);
    } catch {
    }
    set({ viewTheme });
  },
  setStepStyle: (stepStyle) => {
    try {
      localStorage.setItem(STEP_STYLE_KEY, stepStyle);
    } catch {
    }
    set({ stepStyle });
  },
  setCloudFormat: (cloudFormat) => {
    try {
      localStorage.setItem(CLOUD_FORMAT_KEY, cloudFormat);
    } catch {
    }
    set({ cloudFormat });
  },
  setCreaseMode: (creaseMode) => {
    try {
      localStorage.setItem(CREASE_KEY, creaseMode);
    } catch {
    }
    set({ creaseMode });
  },
  setCreaseAngle: (deg2) => {
    const creaseAngle = creaseAngleOf(deg2);
    try {
      localStorage.setItem(CREASE_ANGLE_KEY, String(creaseAngle));
    } catch {
    }
    set({ creaseAngle });
  },
  openImprint: (imprintOpen) => set({ imprintOpen })
}));
class FitError extends Error {
}
const AXIS_DOMINANCE = 10;
function distanceCalibration(a, b, trueMm, opts) {
  if (!(trueMm > 0)) throw new FitError("The true distance must be a positive length.");
  const dx = Math.abs(b[0] - a[0]);
  const dy = Math.abs(b[1] - a[1]);
  const lengthPx = Math.hypot(dx, dy);
  if (!(lengthPx > 1)) throw new FitError("The two points coincide — pick the two ends of the reference.");
  const f = lengthPx / trueMm;
  if (!opts.splitAxes) return { x: f, y: f };
  if (dx >= AXIS_DOMINANCE * dy) return { x: f, y: opts.current?.y ?? f };
  if (dy >= AXIS_DOMINANCE * dx) return { x: opts.current?.x ?? f, y: f };
  throw new FitError(
    "To calibrate one axis, the reference must run along it — this one is diagonal. Align the reference with an image edge, or calibrate both axes together."
  );
}
function diameterCalibration(picks, trueMm) {
  if (!(trueMm > 0)) throw new FitError("The true diameter must be a positive length.");
  if (picks.length < 3) throw new FitError("A circle needs at least three points around its edge.");
  const pu = new Float64Array(picks.length);
  const pv = new Float64Array(picks.length);
  for (let i = 0; i < picks.length; i++) {
    pu[i] = picks[i][0];
    pv[i] = picks[i][1];
  }
  const fit = fitCircle2d(pu, pv);
  if (!fit) throw new FitError("Couldn't fit a circle through these points.");
  const f = 2 * fit.r / trueMm;
  if (!(f > 0)) throw new FitError("Couldn't fit a circle through these points.");
  return { x: f, y: f };
}
function mulberry32(seed) {
  let a = seed >>> 0;
  return function() {
    a |= 0;
    a = a + 1831565813 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function flatPoint(at2) {
  return { kind: "point", at: [at2[0], at2[1]], sigma: 0, usedPoints: 0 };
}
function fitLinePoints(points) {
  const n = points.length;
  if (n < 2) throw new FitError("A line needs at least two points.");
  let mx = 0, my = 0;
  for (const p of points) {
    mx += p[0];
    my += p[1];
  }
  mx /= n;
  my /= n;
  let sxx = 0, sxy = 0, syy = 0;
  let spread = 0;
  for (const p of points) {
    const x = p[0] - mx;
    const y = p[1] - my;
    sxx += x * x;
    sxy += x * y;
    syy += y * y;
    spread = Math.max(spread, x * x + y * y);
  }
  if (!(spread > 0)) throw new FitError("The points coincide — they do not define a line.");
  const theta = 0.5 * Math.atan2(2 * sxy, sxx - syy);
  let dx = Math.cos(theta);
  let dy = Math.sin(theta);
  if (dx < 0 || dx === 0 && dy < 0) {
    dx = -dx;
    dy = -dy;
  }
  let tMin = Infinity;
  let tMax = -Infinity;
  let sumSq = 0;
  let eMin = Infinity;
  let eMax = -Infinity;
  for (const p of points) {
    const x = p[0] - mx;
    const y = p[1] - my;
    const t = x * dx + y * dy;
    const e = -x * dy + y * dx;
    if (t < tMin) tMin = t;
    if (t > tMax) tMax = t;
    if (e < eMin) eMin = e;
    if (e > eMax) eMax = e;
    sumSq += e * e;
  }
  const tMid = (tMin + tMax) / 2;
  return {
    kind: "line",
    center: [mx + tMid * dx, my + tMid * dy],
    dir: [dx, dy],
    length: tMax - tMin,
    sigma: Math.sqrt(sumSq / n),
    usedPoints: n,
    formError: eMax - eMin
  };
}
function circleWithResiduals(points, what) {
  const n = points.length;
  if (n < 3) throw new FitError(`A ${what} needs at least three points.`);
  const pu = new Float64Array(n);
  const pv = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    pu[i] = points[i][0];
    pv[i] = points[i][1];
  }
  const fit = fitCircle2d(pu, pv);
  if (!fit) throw new FitError(`Couldn't fit a ${what} through these points.`);
  let sumSq = 0;
  let eMin = Infinity;
  let eMax = -Infinity;
  for (let i = 0; i < n; i++) {
    const e = Math.hypot(pu[i] - fit.cu, pv[i] - fit.cv) - fit.r;
    if (e < eMin) eMin = e;
    if (e > eMax) eMax = e;
    sumSq += e * e;
  }
  return { fit, sigma: Math.sqrt(sumSq / n), formError: eMax - eMin };
}
function fitCirclePoints(points) {
  const { fit, sigma, formError } = circleWithResiduals(points, "circle");
  return {
    kind: "circle",
    center: [fit.cu, fit.cv],
    radius: fit.r,
    sigma,
    usedPoints: points.length,
    formError
  };
}
const RANSAC_ROUNDS = 96;
const INLIER_BAND = 3;
function consensus(points, residualsOf) {
  const rand = mulberry32(7);
  let bestMedian = Infinity;
  let bestResiduals = null;
  for (let round = 0; round < RANSAC_ROUNDS; round++) {
    const residuals = residualsOf(rand);
    if (!residuals) continue;
    const sorted = residuals.map(Math.abs).sort((a, b) => a - b);
    const median2 = sorted[Math.floor(sorted.length / 2)];
    if (median2 < bestMedian) {
      bestMedian = median2;
      bestResiduals = residuals;
    }
  }
  if (!bestResiduals) return points.map(() => true);
  const band = Math.max(INLIER_BAND * 1.4826 * bestMedian, 0.35);
  return bestResiduals.map((r) => Math.abs(r) <= band);
}
function fitLineRegion(points) {
  if (points.length < 8) throw new FitError("The region caught too few edge points for a line.");
  const keep = consensus(points, (rand) => {
    const a = points[rand() * points.length | 0];
    const b = points[rand() * points.length | 0];
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    const len3 = Math.hypot(dx, dy);
    if (len3 < 1e-9) return null;
    return points.map((p) => ((p[0] - a[0]) * dy - (p[1] - a[1]) * dx) / len3);
  });
  const inliers = points.filter((_, i) => keep[i]);
  if (inliers.length < 8) throw new FitError("The region caught too few edge points for a line.");
  return fitLinePoints(inliers);
}
function circleResiduals(points, rand) {
  const pick = () => points[rand() * points.length | 0];
  const sample = [pick(), pick(), pick()];
  const fit = fitCircle2d(
    Float64Array.from(sample.map((p) => p[0])),
    Float64Array.from(sample.map((p) => p[1]))
  );
  if (!fit) return null;
  return points.map((p) => Math.hypot(p[0] - fit.cu, p[1] - fit.cv) - fit.r);
}
function fitCircleRegion(points) {
  if (points.length < 12) throw new FitError("The region caught too few edge points for a circle.");
  const keep = consensus(points, (rand) => circleResiduals(points, rand));
  const inliers = points.filter((_, i) => keep[i]);
  if (inliers.length < 12) throw new FitError("The region caught too few edge points for a circle.");
  return fitCirclePoints(inliers);
}
function fitArcRegion(points) {
  if (points.length < 12) throw new FitError("The region caught too few edge points for an arc.");
  const keep = consensus(points, (rand) => circleResiduals(points, rand));
  const inliers = points.filter((_, i) => keep[i]);
  if (inliers.length < 12) throw new FitError("The region caught too few edge points for an arc.");
  return fitArcPoints(inliers);
}
function fitArcPoints(points) {
  const { fit, sigma, formError } = circleWithResiduals(points, "arc");
  const angles = points.map((p) => Math.atan2(p[1] - fit.cv, p[0] - fit.cu)).sort((a, b) => a - b);
  let gapAt = angles.length - 1;
  let gap = angles[0] + 2 * Math.PI - angles[angles.length - 1];
  for (let i = 1; i < angles.length; i++) {
    if (angles[i] - angles[i - 1] > gap) {
      gap = angles[i] - angles[i - 1];
      gapAt = i - 1;
    }
  }
  const start = angles[(gapAt + 1) % angles.length];
  return {
    kind: "arc",
    center: [fit.cu, fit.cv],
    radius: fit.r,
    start,
    sweep: 2 * Math.PI - gap,
    sigma,
    usedPoints: points.length,
    formError
  };
}
const FLAT_ROLE_PROVIDERS = {
  point: ["point", "circle", "arc"],
  line: ["line"]
};
function flatRefPoint(fit) {
  if (fit.kind === "point") return fit.at;
  if (fit.kind === "circle" || fit.kind === "arc") return fit.center;
  return null;
}
function flatRefLine(fit) {
  if (fit.kind !== "line") return null;
  return { origin: fit.center, dir: fit.dir, halfLength: fit.length / 2 };
}
const HANDLE_REACH = 1 / 3;
function splineSegmentCount(pointCount, closed) {
  return closed ? pointCount : pointCount - 1;
}
function chords(points, closed) {
  const n = points.length;
  const out = [];
  for (let k = 0; k < splineSegmentCount(n, closed); k++) {
    const a = points[k];
    const b = points[(k + 1) % n];
    out.push(Math.hypot(b[0] - a[0], b[1] - a[1]));
  }
  return out;
}
function reaches(points, closed, h) {
  const n = points.length;
  const out = [];
  for (let i = 0; i < n; i++) {
    const before = closed ? h[(i - 1 + n) % n] : i > 0 ? h[i - 1] : null;
    const after = closed ? h[i % n] : i < n - 1 ? h[i] : null;
    const mean = before !== null && after !== null ? (before + after) / 2 : before ?? after ?? 1;
    out.push(mean * HANDLE_REACH);
  }
  return out;
}
function fitSplinePoints(points, handles, closed) {
  const n = points.length;
  if (n < 2) throw new FitError("A spline needs at least two points.");
  if (closed && n < 3) throw new FitError("A closed spline needs at least three points.");
  const h = chords(points, closed);
  if (h.some((c) => !(c > 1e-9))) {
    throw new FitError("Two consecutive points coincide — move one of them apart.");
  }
  const reach = reaches(points, closed, h);
  const a = new Float64Array(n * n);
  const bx = new Float64Array(n);
  const by = new Float64Array(n);
  const segments = splineSegmentCount(n, closed);
  for (let i = 0; i < n; i++) {
    const handle = handles[i] ?? null;
    if (handle) {
      a[i * n + i] = 1;
      bx[i] = handle[0] / reach[i];
      by[i] = handle[1] / reach[i];
      continue;
    }
    const prev = closed ? (i - 1 + n) % n : i - 1;
    const next = closed ? (i + 1) % n : i + 1;
    const hPrev = closed ? h[(i - 1 + n) % n] : i > 0 ? h[i - 1] : 0;
    const hNext = closed ? h[i % segments] : i < n - 1 ? h[i] : 0;
    if (!closed && i === 0) {
      a[i * n + i] = 2;
      a[i * n + next] = 1;
      bx[i] = 3 * (points[next][0] - points[i][0]) / hNext;
      by[i] = 3 * (points[next][1] - points[i][1]) / hNext;
      continue;
    }
    if (!closed && i === n - 1) {
      a[i * n + prev] = 1;
      a[i * n + i] = 2;
      bx[i] = 3 * (points[i][0] - points[prev][0]) / hPrev;
      by[i] = 3 * (points[i][1] - points[prev][1]) / hPrev;
      continue;
    }
    a[i * n + prev] += 1 / hPrev;
    a[i * n + i] += 2 * (1 / hPrev + 1 / hNext);
    a[i * n + next] += 1 / hNext;
    bx[i] = 3 * ((points[i][0] - points[prev][0]) / (hPrev * hPrev) + (points[next][0] - points[i][0]) / (hNext * hNext));
    by[i] = 3 * ((points[i][1] - points[prev][1]) / (hPrev * hPrev) + (points[next][1] - points[i][1]) / (hNext * hNext));
  }
  const mx = solveLinear(n, a.slice(), bx);
  const my = solveLinear(n, a.slice(), by);
  if (!mx || !my) throw new FitError("Couldn't lay a curve through these points.");
  const fit = {
    kind: "spline",
    points: points.map((p) => [p[0], p[1]]),
    tangents: Array.from({ length: n }, (_, i) => [mx[i], my[i]]),
    fixed: Array.from({ length: n }, (_, i) => (handles[i] ?? null) !== null),
    closed,
    length: 0,
    sigma: 0,
    usedPoints: n
  };
  fit.length = arcLength(fit);
  return fit;
}
function evalSpline(fit, k, u) {
  const n = fit.points.length;
  const p0 = fit.points[k];
  const p1 = fit.points[(k + 1) % n];
  const h = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]);
  const m0 = fit.tangents[k];
  const m1 = fit.tangents[(k + 1) % n];
  const u2 = u * u;
  const u3 = u2 * u;
  const c0 = 2 * u3 - 3 * u2 + 1;
  const c1 = (u3 - 2 * u2 + u) * h;
  const c2 = -2 * u3 + 3 * u2;
  const c3 = (u3 - u2) * h;
  return [
    c0 * p0[0] + c1 * m0[0] + c2 * p1[0] + c3 * m1[0],
    c0 * p0[1] + c1 * m0[1] + c2 * p1[1] + c3 * m1[1]
  ];
}
function evalSplineDerivative(fit, k, u) {
  const n = fit.points.length;
  const p0 = fit.points[k];
  const p1 = fit.points[(k + 1) % n];
  const h = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]);
  const m0 = fit.tangents[k];
  const m1 = fit.tangents[(k + 1) % n];
  const u2 = u * u;
  const c0 = 6 * u2 - 6 * u;
  const c1 = (3 * u2 - 4 * u + 1) * h;
  const c2 = -6 * u2 + 6 * u;
  const c3 = (3 * u2 - 2 * u) * h;
  return [
    c0 * p0[0] + c1 * m0[0] + c2 * p1[0] + c3 * m1[0],
    c0 * p0[1] + c1 * m0[1] + c2 * p1[1] + c3 * m1[1]
  ];
}
const GAUSS_X = [0, 0.5384693101056831, -0.5384693101056831, 0.906179845938664, -0.906179845938664];
const GAUSS_W = [0.5688888888888889, 0.4786286704993665, 0.4786286704993665, 0.2369268850561891, 0.2369268850561891];
const PANELS = 4;
function arcLength(fit) {
  let total = 0;
  for (let k = 0; k < splineSegmentCount(fit.points.length, fit.closed); k++) {
    for (let panel = 0; panel < PANELS; panel++) {
      const u0 = panel / PANELS;
      const half = 1 / (2 * PANELS);
      let sum = 0;
      for (let g = 0; g < GAUSS_X.length; g++) {
        const d = evalSplineDerivative(fit, k, u0 + half * (1 + GAUSS_X[g]));
        sum += GAUSS_W[g] * Math.hypot(d[0], d[1]);
      }
      total += sum * half;
    }
  }
  return total;
}
function splinePolyline(fit, perSegment = 24) {
  const out = [[fit.points[0][0], fit.points[0][1]]];
  for (let k = 0; k < splineSegmentCount(fit.points.length, fit.closed); k++) {
    for (let i = 1; i <= perSegment; i++) out.push(evalSpline(fit, k, i / perSegment));
  }
  return out;
}
function nearestSplineSegment(fit, p, perSegment = 24) {
  const pts = splinePolyline(fit, perSegment);
  let best = Infinity;
  let segment = 0;
  for (let i = 0; i + 1 < pts.length; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    const len22 = dx * dx + dy * dy;
    const t = len22 > 0 ? Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / len22)) : 0;
    const d = Math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy));
    if (d < best) {
      best = d;
      segment = Math.floor(i / perSegment);
    }
  }
  return { segment, dist: best };
}
const add2 = (a, b) => [a[0] + b[0], a[1] + b[1]];
const sub2 = (a, b) => [a[0] - b[0], a[1] - b[1]];
const scale2 = (a, s) => [a[0] * s, a[1] * s];
const dot2 = (a, b) => a[0] * b[0] + a[1] * b[1];
const len2 = (a) => Math.hypot(a[0], a[1]);
const mid2 = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
const cross2 = (a, b) => a[0] * b[1] - a[1] * b[0];
function acuteAngle2(a, b) {
  const c = Math.abs(dot2(a, b)) / (len2(a) * len2(b));
  return Math.acos(Math.min(1, c)) * 180 / Math.PI;
}
function footOnLine2(p, origin, dir) {
  const t = dot2(sub2(p, origin), dir);
  return { foot: add2(origin, scale2(dir, t)), t };
}
function distToSegment2(p, a, b) {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const l2 = dx * dx + dy * dy;
  let t = l2 > 0 ? ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l2 : 0;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy));
}
const FLAT_METHODS = [
  {
    id: "flat-point-pick",
    kind: "point",
    mode: "pick",
    label: "Picked point",
    hint: "Click the point on the image. Clicking again moves it.",
    minPicks: 1
  },
  {
    id: "flat-point-midpoint",
    kind: "point",
    mode: "construct",
    label: "Midpoint",
    hint: "Halfway between two points or centers.",
    slots: [
      { role: "point", label: "From" },
      { role: "point", label: "To" }
    ]
  },
  {
    id: "flat-point-intersect",
    kind: "point",
    mode: "construct",
    label: "Line intersection",
    hint: "Where two lines cross — the corner two edges meet at, however rounded the part is there.",
    slots: [
      { role: "line", label: "Line A" },
      { role: "line", label: "Line B" }
    ]
  },
  {
    id: "flat-point-center",
    kind: "point",
    mode: "construct",
    label: "Center point",
    hint: "The center of a circle or arc, as a point of its own.",
    slots: [{ role: "point", label: "From" }]
  },
  {
    id: "flat-line-pick",
    kind: "line",
    mode: "pick",
    label: "Through points",
    hint: "Click two or more points along the edge — more points give the best-fit line.",
    minPicks: 2
  },
  {
    id: "flat-line-seed",
    kind: "line",
    mode: "seed",
    label: "Fit to edge",
    hint: "Click anywhere on a straight stretch of a detected edge — the line grows along the edge from there and stops where it bends away, at a corner or into a fillet.",
    minPicks: 4
  },
  {
    id: "flat-line-edge",
    kind: "line",
    mode: "edge",
    label: "From edge region",
    hint: "Click a detected edge to take the whole of it, or drag a box along it — every edge point collected feeds the fit, strays from other edges are voted out.",
    minPicks: 8
  },
  {
    id: "flat-circle-pick",
    kind: "circle",
    mode: "pick",
    label: "Through points",
    hint: "Click three or more points around the circle — more points give the best fit.",
    minPicks: 3
  },
  {
    id: "flat-circle-seed",
    kind: "circle",
    mode: "seed",
    label: "Fit to edge",
    hint: "Click anywhere on a round stretch of a detected edge — the circle grows along the edge from there and stops where it leaves the arc; a hole's rim is taken all the way round.",
    minPicks: 6
  },
  {
    id: "flat-circle-edge",
    kind: "circle",
    mode: "edge",
    label: "From edge region",
    hint: "Click the circle's detected edge to take the whole of it, or drag a box over it — every edge point collected feeds the fit, strays are voted out.",
    minPicks: 12
  },
  {
    id: "flat-circle-centers",
    kind: "circle",
    mode: "construct",
    label: "Through centers",
    hint: "The best-fit circle through the centers of three or more holes, arcs or points — a bolt circle. Click each center on the sheet, or choose them below.",
    slots: [
      { role: "point", label: "Center 1" },
      { role: "point", label: "Center 2" },
      { role: "point", label: "Center 3" }
    ],
    repeat: { label: "Center" }
  },
  {
    id: "flat-arc-pick",
    kind: "arc",
    mode: "pick",
    label: "Through points",
    hint: "Click three or more points along the arc — the fit covers what the points cover.",
    minPicks: 3
  },
  {
    id: "flat-arc-edge",
    kind: "arc",
    mode: "edge",
    label: "From edge region",
    hint: "Click the arc's detected edge to take the whole of it, or drag a box along it — every edge point collected feeds the fit, strays are voted out.",
    minPicks: 12
  },
  {
    id: "flat-spline-pick",
    kind: "spline",
    mode: "pick",
    label: "Through fit points",
    hint: "Click the points the curve runs through, in order along the edge — the curve bends smoothly through every one.",
    minPicks: 2
  }
];
function flatMethod(id) {
  const m = FLAT_METHODS.find((x) => x.id === id);
  if (!m) throw new Error(`Unknown flat method "${id}".`);
  return m;
}
function flatSlotRole(m, i) {
  const slots = m.slots ?? [];
  if (i < slots.length) return slots[i].role;
  return m.repeat && slots.length > 0 ? slots[slots.length - 1].role : null;
}
function flatConstructRefs(m, refs) {
  if (!m.repeat) return [...refs];
  const n = m.slots?.length ?? 0;
  const kept = refs.filter((r) => r !== null);
  return kept.length >= n ? kept : [...kept, ...new Array(n - kept.length).fill(null)];
}
function collectsEdgePoints(m) {
  return m.mode === "seed" || m.mode === "edge";
}
function evaluateFlatPicks(methodId, points, spline = {}) {
  switch (methodId) {
    case "flat-spline-pick":
      return fitSplinePoints(
        points,
        points.map((_, i) => spline.tangents?.[i] ?? null),
        spline.closed ?? false
      );
    case "flat-point-pick": {
      if (points.length < 1) throw new FitError("Click the point first.");
      return flatPoint(points[points.length - 1]);
    }
    // A click's grown points are the straight or round stretch itself, so
    // the plain least squares is the fit — the growing did the choosing.
    case "flat-line-pick":
    case "flat-line-seed":
      return fitLinePoints(points);
    case "flat-circle-pick":
    case "flat-circle-seed":
      return fitCirclePoints(points);
    case "flat-arc-pick":
      return fitArcPoints(points);
    case "flat-line-edge":
      return fitLineRegion(points);
    case "flat-circle-edge":
      return fitCircleRegion(points);
    case "flat-arc-edge":
      return fitArcRegion(points);
    default:
      throw new Error(`"${methodId}" is not a pick method.`);
  }
}
function evaluateFlatConstruction(methodId, refs) {
  switch (methodId) {
    case "flat-point-midpoint": {
      const a = flatRefPoint(refs[0]);
      const b = flatRefPoint(refs[1]);
      if (!a || !b) throw new FitError("Both references must provide a point.");
      return flatPoint(mid2(a, b));
    }
    case "flat-point-intersect": {
      const a = flatRefLine(refs[0]);
      const b = flatRefLine(refs[1]);
      if (!a || !b) throw new FitError("Both references must be lines.");
      const denom = cross2(a.dir, b.dir);
      if (Math.abs(denom) < 1e-9) {
        throw new FitError("The lines are parallel — they do not intersect.");
      }
      const t = cross2(sub2(b.origin, a.origin), b.dir) / denom;
      return flatPoint([a.origin[0] + t * a.dir[0], a.origin[1] + t * a.dir[1]]);
    }
    case "flat-point-center": {
      const p = flatRefPoint(refs[0]);
      if (!p) throw new FitError("The reference must provide a point.");
      return flatPoint(p);
    }
    // A bolt circle: the circle fit through the centres, so its form is how
    // far the holes stray from one pitch circle.
    case "flat-circle-centers": {
      const points = refs.map(flatRefPoint);
      if (points.some((p) => p === null)) throw new FitError("Every reference must provide a point.");
      if (points.length < 3) throw new FitError("A circle needs at least three centers.");
      return fitCirclePoints(points);
    }
    default:
      throw new Error(`"${methodId}" is not a construction.`);
  }
}
const FLAT_KIND_LABELS = {
  point: "Point",
  line: "Line",
  circle: "Circle",
  arc: "Arc",
  spline: "Spline"
};
function picksToDocument(picks, pxPerMm) {
  if (!pxPerMm) return picks.map((p) => [p[0], p[1]]);
  return picks.map((p) => [p[0] / pxPerMm.x, p[1] / pxPerMm.y]);
}
function tangentsToDocument(tangents, pxPerMm) {
  if (!tangents) return [];
  return tangents.map((t) => t ? picksToDocument([t], pxPerMm)[0] : null);
}
function evaluateFlatSource(source, pxPerMm, fitOf) {
  if (source.type === "picks") {
    return evaluateFlatPicks(source.method, picksToDocument(source.picks, pxPerMm), {
      tangents: tangentsToDocument(source.tangents, pxPerMm),
      closed: source.closed
    });
  }
  const refs = source.refs.map((id) => {
    const fit = fitOf(id);
    if (!fit) throw new FitError("A referenced element is unavailable.");
    return fit;
  });
  return evaluateFlatConstruction(source.method, refs);
}
function evaluateFlatElements(elements, pxPerMm) {
  const fits = /* @__PURE__ */ new Map();
  return [...elements].sort((a, b) => a.id - b.id).map((el) => {
    try {
      const fit = evaluateFlatSource(el.source, pxPerMm, (id) => fits.get(id) ?? null);
      fits.set(el.id, fit);
      return { ...el, fit, error: null };
    } catch (e) {
      fits.set(el.id, null);
      if (e instanceof FitError) return { ...el, fit: null, error: e.message };
      throw e;
    }
  });
}
function flatPicksNeeded(method, closed = false) {
  const m = flatMethod(method);
  const min = m.minPicks ?? 1;
  return m.kind === "spline" && closed ? Math.max(min, 3) : min;
}
function flatPicksReady(method, picks, closed = false) {
  return picks.length >= flatPicksNeeded(method, closed);
}
function flatDependentsOf(id, elements) {
  const doomed = /* @__PURE__ */ new Set([id]);
  let grew = true;
  while (grew) {
    grew = false;
    for (const el of elements) {
      if (doomed.has(el.id) || el.source.type !== "construct") continue;
      if (el.source.refs.some((r) => doomed.has(r))) {
        doomed.add(el.id);
        grew = true;
      }
    }
  }
  return doomed;
}
function sheetLength(v, su, mmDecimals = 3, opts) {
  if (su !== "px") return fmtLen(v, su, mmDecimals, opts);
  const text = v.toFixed(mmDecimals);
  const signed = opts?.signed && v > 0 ? `+${text}` : text;
  return opts?.bare ? signed : `${signed} px`;
}
function sheetWord(su) {
  return su === "px" ? "px" : unitWord(su);
}
const FLAT_DIMENSION_TYPES = [
  {
    id: "flat-dist-point-point",
    group: "distance",
    label: "Point – Point",
    hint: "Straight-line distance between two points or centers.",
    slots: [
      { role: "point", label: "From" },
      { role: "point", label: "To" }
    ]
  },
  {
    id: "flat-dist-point-line",
    group: "distance",
    label: "Point – Line",
    hint: "Perpendicular distance from a point to a line.",
    slots: [
      { role: "point", label: "Point" },
      { role: "line", label: "Line" }
    ]
  },
  {
    id: "flat-dist-line-line",
    group: "distance",
    label: "Line – Line",
    hint: "Distance between two near-parallel lines — the width of a slot or a wall.",
    slots: [
      { role: "line", label: "From" },
      { role: "line", label: "To" }
    ]
  },
  {
    id: "flat-angle-line-line",
    group: "angle",
    label: "Line – Line",
    hint: "Angle between two lines (0–90°).",
    slots: [
      { role: "line", label: "Line A" },
      { role: "line", label: "Line B" }
    ]
  }
];
function flatDimensionTypeInfo(id) {
  const info = FLAT_DIMENSION_TYPES.find((t) => t.id === id);
  if (!info) throw new Error(`Unknown flat dimension type "${id}".`);
  return info;
}
const FLAT_PARALLEL_MAX_DEG = 3;
const FLAT_PARALLEL_WARN_DEG = 0.5;
const EXTENT_MARGIN = 1.3;
const deg = (v) => `${v.toFixed(2)}°`;
const invalid = (label, why) => ({ label, invalid: why });
function deltaDetail(a, b, su) {
  const f = (v) => {
    const s = sheetLength(v, su, 3, { bare: true });
    return Number(s) === 0 ? `+${s.replace("-", "")}` : v >= 0 ? `+${s}` : s;
  };
  return `ΔX ${f(b[0] - a[0])} · ΔY ${f(b[1] - a[1])} ${sheetWord(su)}`;
}
function evaluateFlatDimension(type, fits, units = "mm") {
  const mm = (v) => sheetLength(v, units);
  switch (type) {
    case "flat-dist-point-point": {
      const a = flatRefPoint(fits[0]);
      const b = flatRefPoint(fits[1]);
      if (!a || !b) return invalid("Distance", "A reference is not a point.");
      const d = len2(sub2(b, a));
      return {
        label: "Center distance",
        value: mm(d),
        raw: d,
        segment: [a, b],
        detail: deltaDetail(a, b, units)
      };
    }
    case "flat-dist-point-line": {
      const p = flatRefPoint(fits[0]);
      const line = flatRefLine(fits[1]);
      if (!p || !line) return invalid("Distance to line", "A reference is missing.");
      const { foot, t } = footOnLine2(p, line.origin, line.dir);
      const d = len2(sub2(p, foot));
      return {
        label: "Distance to line",
        value: mm(d),
        raw: d,
        segment: [p, foot],
        warning: Math.abs(t) > line.halfLength * EXTENT_MARGIN ? "The perpendicular foot lies beyond the measured section of the line." : void 0
      };
    }
    case "flat-dist-line-line": {
      const a = flatRefLine(fits[0]);
      const b = flatRefLine(fits[1]);
      if (!a || !b) return invalid("Line distance", "A reference is missing.");
      const fold = acuteAngle2(a.dir, b.dir);
      if (fold > FLAT_PARALLEL_MAX_DEG) {
        return invalid(
          "Line distance",
          `The lines are ${deg(fold)} apart — a distance between non-parallel lines has no meaning. Use an angle dimension instead.`
        );
      }
      const { foot, t } = footOnLine2(a.origin, b.origin, b.dir);
      const warnings = [];
      if (fold > FLAT_PARALLEL_WARN_DEG)
        warnings.push(
          `The lines are ${deg(fold)} off parallel — the value depends on where along them it is taken.`
        );
      if (Math.abs(t) > b.halfLength * EXTENT_MARGIN)
        warnings.push("Measured beyond the fitted section of the second line.");
      const d = len2(sub2(a.origin, foot));
      return {
        label: "Line distance",
        value: mm(d),
        raw: d,
        segment: [a.origin, foot],
        detail: `Lines ${deg(fold)} apart`,
        warning: warnings.length ? warnings.join(" ") : void 0
      };
    }
    case "flat-angle-line-line": {
      const a = flatRefLine(fits[0]);
      const b = flatRefLine(fits[1]);
      if (!a || !b) return invalid("Line angle", "A reference is missing.");
      const v = acuteAngle2(a.dir, b.dir);
      const denom = a.dir[0] * b.dir[1] - a.dir[1] * b.dir[0];
      let vertex;
      if (Math.abs(denom) > 1e-9) {
        const r = sub2(b.origin, a.origin);
        const t = (r[0] * b.dir[1] - r[1] * b.dir[0]) / denom;
        vertex = [a.origin[0] + t * a.dir[0], a.origin[1] + t * a.dir[1]];
      } else {
        vertex = [(a.origin[0] + b.origin[0]) / 2, (a.origin[1] + b.origin[1]) / 2];
      }
      const dirB = dot2(a.dir, b.dir) < 0 ? scale2(b.dir, -1) : b.dir;
      return {
        label: "Line angle",
        value: deg(v),
        raw: v,
        detail: v < 90 ? `Supplement ${deg(180 - v)}` : void 0,
        arc: { vertex, dirA: a.dir, dirB }
      };
    }
    default:
      return invalid("Dimension", `Unknown flat dimension type "${type}".`);
  }
}
const INIT_HALF = 6;
const CIRCLE_SCALES = [6, 10, 16, 25, 40, 64, 100, 160, 250, 400, 640, 1e3, 1600, 2500, 4e3, 6400];
const BAND_SIGMAS = 2.5;
const BAND_SCATTERS = 3;
const STOP_RUN = 3;
const REFIT_GROWTH = 1.3;
const COS_TILT_MAX = Math.cos(10 * Math.PI / 180);
const TANGENT_HALF = 2;
const FIT_SCATTERS_MAX = 4;
const LINE_ARC_F_CRIT = 16;
const LINE_ARC_RADIUS_LENGTHS = 20;
const MIN_SWEEP = 8 * Math.PI / 180;
const SCATTER_FLOOR = 0.05;
const SCATTER_FROM_MEDIAN = 1 / (0.6745 * Math.sqrt(1.5));
const SAMPLE = 2048;
function median(values) {
  if (values.length === 0) return 0;
  const sorted = values.slice().sort((a, b) => a - b);
  return sorted[sorted.length >> 1];
}
function viewChain(chain) {
  const n0 = chain.length;
  const step = Math.max(1, Math.floor(n0 / SAMPLE));
  const gaps = [];
  for (let i = step; i < n0; i += step) {
    gaps.push(Math.hypot(chain[i][0] - chain[i - step][0], chain[i][1] - chain[i - step][1]) / step);
  }
  const spacing = median(gaps) || 1;
  let points = chain;
  let closed = false;
  if (n0 >= 4) {
    const gap = Math.hypot(chain[0][0] - chain[n0 - 1][0], chain[0][1] - chain[n0 - 1][1]);
    if (gap <= 2 * spacing) {
      closed = true;
      if (gap < 0.01 * spacing) points = chain.slice(0, n0 - 1);
    }
  }
  const n = points.length;
  const seconds = [];
  const step2 = Math.max(1, Math.floor(n / SAMPLE));
  for (let i = 1; i + 1 < n; i += step2) {
    const ax = points[i + 1][0] - points[i - 1][0];
    const ay = points[i + 1][1] - points[i - 1][1];
    const len3 = Math.hypot(ax, ay);
    if (len3 < 1e-9) continue;
    const bx = points[i][0] - points[i - 1][0];
    const by = points[i][1] - points[i - 1][1];
    seconds.push(Math.abs(ax * by - ay * bx) / len3);
  }
  const scatter = Math.max(median(seconds) * SCATTER_FROM_MEDIAN, SCATTER_FLOOR * spacing);
  return { points, closed, spacing, scatter };
}
function at(view, i) {
  const n = view.points.length;
  return view.points[view.closed ? (i % n + n) % n : i];
}
function slice(view, lo, hi) {
  const out = [];
  for (let i = lo; i <= hi; i++) out.push(at(view, i));
  return out;
}
function tangentAt(view, i) {
  const n = view.points.length;
  const lo = view.closed ? i - TANGENT_HALF : Math.max(0, i - TANGENT_HALF);
  const hi = view.closed ? i + TANGENT_HALF : Math.min(n - 1, i + TANGENT_HALF);
  const a = at(view, lo);
  const b = at(view, hi);
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const len3 = Math.hypot(dx, dy);
  return len3 > 1e-9 ? [dx / len3, dy / len3] : null;
}
function windowAround(view, seed, half) {
  const n = view.points.length;
  if (!view.closed) return [Math.max(0, seed - half), Math.min(n - 1, seed + half)];
  if (2 * half + 1 >= n) {
    const lo = seed - Math.floor((n - 1) / 2);
    return [lo, lo + n - 1];
  }
  return [seed - half, seed + half];
}
function covers(view, lo, hi) {
  return view.closed ? hi - lo + 1 >= view.points.length : lo === 0 && hi === view.points.length - 1;
}
function tryFit(fit, points) {
  try {
    return fit(points);
  } catch (e) {
    if (e instanceof FitError) return null;
    throw e;
  }
}
const LINE_SPEC = {
  fit: (points) => {
    const fit = tryFit(fitLinePoints, points);
    return fit && { model: { center: fit.center, dir: fit.dir }, sigma: fit.sigma };
  },
  residual: (m, p) => -(p[0] - m.center[0]) * m.dir[1] + (p[1] - m.center[1]) * m.dir[0],
  align: (m, _p, t) => Math.abs(t[0] * m.dir[0] + t[1] * m.dir[1])
};
const CIRCLE_SPEC = {
  fit: (points) => {
    const fit = tryFit(fitCirclePoints, points);
    return fit && { model: { center: fit.center, radius: fit.radius }, sigma: fit.sigma };
  },
  residual: (m, p) => Math.hypot(p[0] - m.center[0], p[1] - m.center[1]) - m.radius,
  align: (m, p, t) => {
    const rx = p[0] - m.center[0];
    const ry = p[1] - m.center[1];
    const r = Math.hypot(rx, ry);
    return r > 1e-9 ? Math.abs((rx * t[1] - ry * t[0]) / r) : 0;
  }
};
function belongs(view, i, model, band, spec) {
  const p = at(view, i);
  if (!(Math.abs(spec.residual(model, p)) <= band)) return false;
  const t = tangentAt(view, i);
  return t === null || spec.align(model, p, t) >= COS_TILT_MAX;
}
function grow(view, seed, half, spec) {
  let [lo, hi] = windowAround(view, seed, half);
  let fit = spec.fit(slice(view, lo, hi));
  if (!fit) return null;
  let { model, sigma } = fit;
  let lastCount = hi - lo + 1;
  let hiDone = covers(view, lo, hi);
  let loDone = hiDone;
  let hiRun = 0;
  let loRun = 0;
  while (!hiDone || !loDone) {
    const band2 = Math.max(BAND_SIGMAS * sigma, BAND_SCATTERS * view.scatter);
    const refitAt = Math.ceil(lastCount * REFIT_GROWTH);
    while (!hiDone && hi - lo + 1 < refitAt) {
      if (covers(view, lo, hi) || !view.closed && hi >= view.points.length - 1) {
        hiDone = true;
        break;
      }
      if (belongs(view, hi + 1, model, band2, spec)) {
        hi++;
        hiRun = 0;
      } else if (++hiRun >= STOP_RUN) {
        hi -= hiRun - 1;
        hiDone = true;
      } else {
        hi++;
      }
    }
    while (!loDone && hi - lo + 1 < refitAt) {
      if (covers(view, lo, hi) || !view.closed && lo <= 0) {
        loDone = true;
        break;
      }
      if (belongs(view, lo - 1, model, band2, spec)) {
        lo--;
        loRun = 0;
      } else if (++loRun >= STOP_RUN) {
        lo += loRun - 1;
        loDone = true;
      } else {
        lo--;
      }
    }
    if (covers(view, lo, hi)) hiDone = loDone = true;
    if (hi - lo + 1 >= refitAt) {
      const next = spec.fit(slice(view, lo, hi));
      if (!next) break;
      ({ model, sigma } = next);
      lastCount = hi - lo + 1;
    }
  }
  if (hiRun > 0 && hiRun < STOP_RUN) hi -= hiRun;
  if (loRun > 0 && loRun < STOP_RUN) lo += loRun;
  let members = slice(view, lo, hi);
  fit = spec.fit(members);
  if (!fit) return null;
  ({ model, sigma } = fit);
  const band = Math.max(BAND_SIGMAS * sigma, BAND_SCATTERS * view.scatter);
  const m = model;
  const kept = members.filter((p) => Math.abs(spec.residual(m, p)) <= band);
  if (kept.length < members.length) {
    const refit = spec.fit(kept);
    if (!refit) return null;
    members = kept;
    ({ model, sigma } = refit);
  }
  return { members: members.map((p) => [p[0], p[1]]), model, sigma };
}
function seedIndex(view, seed) {
  const n = view.points.length;
  return Math.max(0, Math.min(n - 1, seed)) % n;
}
function growLineFromSeed(chain, seed) {
  const view = viewChain(chain);
  if (view.points.length < 4) throw new FitError("Too few edge points here for a line.");
  const run = grow(view, seedIndex(view, seed), INIT_HALF, LINE_SPEC);
  if (!run || run.members.length < 4) {
    throw new FitError("Couldn't fit a line at this point — too little straight edge under the click.");
  }
  const curved = "Couldn't fit a line at this point — the edge here is curved. Click on a straight stretch of it.";
  if (run.sigma > FIT_SCATTERS_MAX * view.scatter) throw new FitError(curved);
  const circle = CIRCLE_SPEC.fit(run.members);
  if (circle) {
    const n = run.members.length;
    const noise = Math.max(circle.sigma, 0.5 * view.scatter);
    const gain = n * (run.sigma * run.sigma - circle.sigma * circle.sigma);
    if (gain > LINE_ARC_F_CRIT * noise * noise) {
      const line = fitLinePoints(run.members);
      if (circle.model.radius < LINE_ARC_RADIUS_LENGTHS * line.length) throw new FitError(curved);
    }
  }
  return run.members;
}
function growCircleFromSeed(chain, seed) {
  const view = viewChain(chain);
  const n = view.points.length;
  if (n < 6) throw new FitError("Too few edge points here for a circle.");
  const s = seedIndex(view, seed);
  const maxSigma = FIT_SCATTERS_MAX * view.scatter;
  for (const half of CIRCLE_SCALES) {
    const [lo, hi] = windowAround(view, s, half);
    const window2 = slice(view, lo, hi);
    const circle = CIRCLE_SPEC.fit(window2);
    const line = LINE_SPEC.fit(window2);
    const resolved = circle !== null && circle.sigma <= maxSigma && (line === null || line.sigma >= 3 * circle.sigma + 3 * view.scatter);
    if (resolved) {
      const run = grow(view, s, half, CIRCLE_SPEC);
      if (run && run.members.length >= 6 && run.sigma <= maxSigma) {
        const arc = tryFit(fitArcPoints, run.members);
        if (arc && arc.sweep >= MIN_SWEEP) return run.members;
      }
    }
    if (covers(view, lo, hi)) break;
  }
  throw new FitError(
    "Couldn't fit a circle at this point — the edge here is straight or not round. Click on the round part of the edge."
  );
}
function growFromSeed(kind, chain, seed) {
  return kind === "circle" ? growCircleFromSeed(chain, seed) : growLineFromSeed(chain, seed);
}
function snapRadiusPx(meta, pxPerUnit) {
  return 10 * meta.unitsPerScreenPx * pxPerUnit;
}
function snapPick(px, index, radiusPx, snap, alt) {
  if (snap === alt || !index) return px;
  return index.nearest(px[0], px[1], radiusPx) ?? px;
}
function nearestCenter(at2, fits, reach) {
  let best = null;
  let bestSq = reach * reach;
  for (const fit of fits) {
    const c = flatRefPoint(fit);
    if (!c) continue;
    const d = (c[0] - at2[0]) ** 2 + (c[1] - at2[1]) ** 2;
    if (d <= bestSq) {
      bestSq = d;
      best = c;
    }
  }
  return best;
}
function distanceToFit(fit, at2) {
  switch (fit.kind) {
    case "point":
      return Math.hypot(at2[0] - fit.at[0], at2[1] - fit.at[1]);
    case "line": {
      const h = fit.length / 2;
      const a = [fit.center[0] - fit.dir[0] * h, fit.center[1] - fit.dir[1] * h];
      const b = [fit.center[0] + fit.dir[0] * h, fit.center[1] + fit.dir[1] * h];
      return distToSegment2(at2, a, b);
    }
    case "circle":
    case "arc": {
      const d = Math.hypot(at2[0] - fit.center[0], at2[1] - fit.center[1]);
      let onRim = true;
      if (fit.kind === "arc") {
        const turn = 2 * Math.PI;
        const from = Math.atan2(at2[1] - fit.center[1], at2[0] - fit.center[0]) - fit.start;
        onRim = (from % turn + turn) % turn <= fit.sweep;
      }
      return Math.min(d, onRim ? Math.abs(d - fit.radius) : Infinity);
    }
    case "spline":
      return Infinity;
  }
}
function elementNear(at2, elements, reach, takes = () => true) {
  let best = null;
  let bestD = reach;
  for (const el of elements) {
    if (!el.fit || !takes(el)) continue;
    const d = distanceToFit(el.fit, at2);
    if (d <= bestD) {
      bestD = d;
      best = el;
    }
  }
  return best;
}
function thinEdgePoints(points, cap = 4e3) {
  return points.length > cap ? points.filter((_, i) => i % Math.ceil(points.length / cap) === 0) : points;
}
function sheetKeyOf(subject) {
  return subject.kind === "image" ? "image" : `section:${subject.id}`;
}
const NO_TOOL = { kind: "none" };
function toolOf(s, kind) {
  return s.tool.kind === kind ? s.tool : null;
}
function flatDraftHolds(d) {
  return d !== null && (d.editId !== void 0 || d.picks.length > 0 || d.refs.some((r) => r !== null));
}
function flatBlockedRefs(editId, elements) {
  return editId === void 0 ? /* @__PURE__ */ new Set() : flatDependentsOf(editId, elements);
}
function flatCountColor(id) {
  return PALETTE[(id + 3) % PALETTE.length];
}
function freshDraft(kind, method, edit) {
  return {
    kind,
    method,
    picks: [],
    tangents: [],
    closed: false,
    refs: new Array(flatMethod(method).slots?.length ?? 0).fill(null),
    fit: null,
    error: null,
    ...edit
  };
}
function tangentsFor(count, tangents) {
  return Array.from({ length: count }, (_, i) => tangents[i] ?? null);
}
function pickSource(draft) {
  return draft.kind === "spline" ? { type: "picks", method: draft.method, picks: draft.picks, tangents: draft.tangents, closed: draft.closed } : { type: "picks", method: draft.method, picks: draft.picks };
}
function putAway(s, kind) {
  return s.tool.kind === kind ? { tool: NO_TOOL } : {};
}
function docToPx(s, spot) {
  return s.pxPerMm ? [spot[0] * s.pxPerMm.x, spot[1] * s.pxPerMm.y] : [spot[0], spot[1]];
}
function evaluateDraft(draft, elements, pxPerMm) {
  const m = flatMethod(draft.method);
  try {
    if (m.mode !== "construct") {
      if (!flatPicksReady(draft.method, draft.picks, draft.closed)) return { fit: null, error: null };
      return { fit: evaluateFlatSource(pickSource(draft), pxPerMm, () => null), error: null };
    }
    const slots = m.slots?.length ?? 0;
    if (draft.refs.length < slots || draft.refs.some((r) => r === null)) {
      return { fit: null, error: null };
    }
    return {
      fit: evaluateFlatSource(
        { type: "construct", method: draft.method, refs: draft.refs },
        pxPerMm,
        (id) => elements.find((e) => e.id === id)?.fit ?? null
      ),
      error: null
    };
  } catch (e) {
    if (e instanceof FitError) return { fit: null, error: e.message };
    throw e;
  }
}
function sheetOf(s) {
  return {
    pxPerMm: s.pxPerMm,
    calSource: s.calSource,
    elements: s.elements,
    nextId: s.nextId,
    nameCounts: s.nameCounts,
    dimensions: s.dimensions,
    nextDimId: s.nextDimId,
    dimCounts: s.dimCounts,
    datum: s.datum,
    counts: s.counts,
    nextCountId: s.nextCountId,
    notes: s.notes,
    nextNoteId: s.nextNoteId,
    turns: s.turns,
    mirror: s.mirror
  };
}
function freshSheet(pxPerMm, calSource) {
  return {
    pxPerMm,
    calSource,
    elements: [],
    nextId: 1,
    nameCounts: {},
    dimensions: [],
    nextDimId: 1,
    dimCounts: {},
    datum: null,
    counts: [],
    nextCountId: 1,
    notes: [],
    nextNoteId: 1,
    turns: 0,
    mirror: false
  };
}
const freshSectionSheet = () => freshSheet({ x: 1, y: 1 }, "section");
const STAGE_CLEARED = {
  draft: null,
  dimDraft: null,
  tool: NO_TOOL,
  edgeStatus: "idle",
  edgeCount: 0
};
const PROFILE_KEY = "scanruler.flat.profiles.v1";
function loadProfiles() {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (p) => typeof p === "object" && p !== null && typeof p.name === "string" && typeof p.pxPerMm?.x === "number" && typeof p.pxPerMm?.y === "number"
    );
  } catch {
    return [];
  }
}
function storeProfiles(profiles) {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profiles));
  } catch {
  }
}
function centerNear(s, spot, meta) {
  const editId = s.draft?.editId;
  const fits = s.elements.flatMap((e) => e.visible && e.fit && e.id !== editId ? [e.fit] : []);
  const at2 = nearestCenter(spot, fits, 10 * meta.unitsPerScreenPx);
  return at2 && docToPx(s, at2);
}
create()((set, get) => ({
  imageName: null,
  imageWidth: 0,
  imageHeight: 0,
  imageBusy: false,
  imageVersion: 0,
  metaPxPerMm: null,
  edgeStatus: "idle",
  edgeCount: 0,
  edgeVersion: 0,
  edgeSensitivity: 0.5,
  // On by default so the first detection is visible feedback for the slider;
  // a chip on the stage puts them away while measuring.
  showEdges: true,
  snapToEdge: true,
  pxPerMm: null,
  calSource: "none",
  subject: { kind: "image" },
  subjectVersion: 0,
  sheets: {},
  splitAxes: false,
  tool: NO_TOOL,
  setSubject: (subject) => set((s) => {
    const from = sheetKeyOf(s.subject);
    const to = sheetKeyOf(subject);
    if (from === to) return {};
    const sheets = { ...s.sheets, [from]: sheetOf(s) };
    const restored = sheets[to] ?? (subject.kind === "section" ? freshSectionSheet() : freshSheet(s.metaPxPerMm, s.metaPxPerMm ? "metadata" : "none"));
    delete sheets[to];
    return {
      subject,
      subjectVersion: s.subjectVersion + 1,
      sheets,
      ...restored,
      ...STAGE_CLEARED
    };
  }),
  dropSections: (liveIds) => set((s) => {
    const live = new Set(liveIds);
    const sheets = {};
    for (const [key, sheet] of Object.entries(s.sheets)) {
      if (!key.startsWith("section:") || live.has(Number(key.slice(8)))) sheets[key] = sheet;
    }
    if (s.subject.kind === "image" || live.has(s.subject.id)) {
      return Object.keys(sheets).length === Object.keys(s.sheets).length ? {} : { sheets };
    }
    const restored = sheets.image ?? freshSheet(s.metaPxPerMm, s.metaPxPerMm ? "metadata" : "none");
    delete sheets.image;
    return {
      subject: { kind: "image" },
      subjectVersion: s.subjectVersion + 1,
      sheets,
      ...restored,
      ...STAGE_CLEARED
    };
  }),
  stageClick: (spot, meta, edges) => {
    const s = get();
    const px = docToPx(s, spot);
    const radius = snapRadiusPx(meta, s.pxPerMm?.x ?? 1);
    const center = centerNear(s, spot, meta);
    const onEdge = !meta.alt && center || snapPick(px, edges, radius, true, meta.alt);
    const asSet = s.snapToEdge !== meta.alt && center || snapPick(px, edges, radius, s.snapToEdge, meta.alt);
    switch (s.tool.kind) {
      case "calibrate":
        s.addCalPick(onEdge);
        return;
      case "datum":
        s.addDatumPick(onEdge);
        return;
      case "note":
        if (s.tool.editId === null) {
          s.addNote(px);
          return;
        }
        break;
      case "count":
        s.addCountPick(asSet);
        return;
    }
    if (s.draft ? flatMethod(s.draft.method).mode === "construct" : s.dimDraft !== null) {
      s.clickSlotElement(spot, meta);
      return;
    }
    if (!s.draft) return;
    const mode = flatMethod(s.draft.method).mode;
    if (mode === "seed") {
      const hit = edges?.chainHit(px[0], px[1], radius);
      if (!hit) {
        s.noteDraftError("No detected edge under the click — click on one of the detected edge lines.");
        return;
      }
      try {
        const kind = s.draft.kind === "circle" ? "circle" : "line";
        s.addDraftPoints(thinEdgePoints(growFromSeed(kind, hit.chain, hit.index)));
      } catch (e) {
        if (!(e instanceof FitError)) throw e;
        s.noteDraftError(e.message);
      }
      return;
    }
    if (mode === "edge") {
      const chain = edges?.chainNear(px[0], px[1], radius);
      if (chain) s.addDraftPoints(thinEdgePoints(chain));
      return;
    }
    if (s.draft.fit?.kind === "spline") {
      const near = nearestSplineSegment(s.draft.fit, spot);
      if (near.dist <= 10 * meta.unitsPerScreenPx) {
        s.insertDraftPick(near.segment + 1, asSet);
        return;
      }
    }
    s.addDraftPick(asSet);
  },
  clickSlotElement: (spot, meta) => {
    const s = get();
    const reach = 10 * meta.unitsPerScreenPx;
    const shown = s.elements.filter((e) => e.visible);
    if (s.draft) {
      const m = flatMethod(s.draft.method);
      const refs = s.draft.refs;
      const blocked = flatBlockedRefs(s.draft.editId, s.elements);
      const open = [...refs.keys(), ...m.repeat ? [refs.length] : []].filter((i) => refs[i] == null);
      const fits2 = (el3, i) => {
        const role = flatSlotRole(m, i);
        return role !== null && FLAT_ROLE_PROVIDERS[role].includes(el3.kind);
      };
      const el2 = elementNear(spot, shown, reach, (e) => !blocked.has(e.id) && (refs.includes(e.id) || open.some((i) => fits2(e, i))));
      if (!el2) return;
      const used2 = refs.indexOf(el2.id);
      if (used2 >= 0) s.setDraftRef(used2, null);
      else s.setDraftRef(open.find((i) => fits2(el2, i)), el2.id);
      return;
    }
    const dd = s.dimDraft;
    if (!dd) return;
    const slots = flatDimensionTypeInfo(dd.type).slots;
    const fits = (el2, i) => dd.refs[i] === null && FLAT_ROLE_PROVIDERS[slots[i].role].includes(el2.kind);
    const el = elementNear(spot, shown, reach, (e) => dd.refs.includes(e.id) || slots.some((_, i) => fits(e, i)));
    if (!el) return;
    const used = dd.refs.indexOf(el.id);
    if (used >= 0) s.setDimRef(used, null);
    else s.setDimRef(slots.findIndex((_, i) => fits(el, i)), el.id);
  },
  stageDrag: (index, spot, meta, edges) => {
    const s = get();
    const radius = snapRadiusPx(meta, s.pxPerMm?.x ?? 1);
    const center = s.snapToEdge !== meta.alt ? centerNear(s, spot, meta) : null;
    s.moveDraftPick(index, center ?? snapPick(docToPx(s, spot), edges, radius, s.snapToEdge, meta.alt));
  },
  stageHandleDrag: (index, end, spot, meta) => {
    const s = get();
    if (!s.draft || index < 0 || index >= s.draft.picks.length) return;
    const px = docToPx(s, spot);
    const at2 = s.draft.picks[index];
    const off = [px[0] - at2[0], px[1] - at2[1]];
    if (Math.hypot(off[0], off[1]) < 3 * meta.unitsPerScreenPx * (s.pxPerMm?.x ?? 1)) return;
    s.setDraftTangent(index, end === "a" ? off : [-off[0], -off[1]]);
  },
  stageRegion: (min, max, edges) => {
    const s = get();
    if (!s.draft || !edges) return;
    const lo = docToPx(s, min);
    const hi = docToPx(s, max);
    s.addDraftPoints(thinEdgePoints(edges.inBox(lo[0], lo[1], hi[0], hi[1])));
  },
  stageNoteDrag: (id, spot) => {
    const s = get();
    s.moveNote(id, docToPx(s, spot));
  },
  confirmable: () => {
    const s = get();
    if (s.tool.kind === "calibrate" || s.tool.kind === "datum") return null;
    if (s.draft) return s.draft.fit ? () => get().commitDraft() : null;
    if (s.tool.kind === "count") return s.tool.picks.length > 0 ? () => get().finishCount() : null;
    if (s.tool.kind === "note" && s.tool.editId !== null) return () => get().finishNote();
    const dd = s.dimDraft;
    if (!dd || dd.refs.some((r) => r === null)) return null;
    const fits = dd.refs.map((id) => s.elements.find((e) => e.id === id)?.fit);
    if (!fits.every((x) => x !== void 0 && x !== null)) return null;
    return evaluateFlatDimension(dd.type, fits).invalid ? null : () => get().commitDim();
  },
  retreat: () => {
    const s = get();
    const backOutOfDraft = () => s.draft.editId === void 0 && flatDraftHolds(s.draft) ? s.restartDraft() : s.cancelDraft();
    switch (s.tool.kind) {
      case "calibrate":
        s.cancelCalibration();
        return true;
      case "datum":
        s.cancelDatum();
        return true;
      case "note":
        if (s.tool.editId === null) s.cancelNote();
        else s.finishNote();
        return true;
      case "count":
        if (s.draft) backOutOfDraft();
        else s.cancelCount();
        return true;
    }
    if (s.draft) {
      backOutOfDraft();
      return true;
    }
    if (s.dimDraft) {
      s.cancelDimDraft();
      return true;
    }
    return false;
  },
  dimensions: [],
  dimDraft: null,
  nextDimId: 1,
  dimCounts: {},
  // One thing in hand at a time: a dimension closes the element draft, so a
  // click on the sheet has one taker.
  startDimDraft: () => set({
    draft: null,
    dimDraft: {
      type: FLAT_DIMENSION_TYPES[0].id,
      refs: FLAT_DIMENSION_TYPES[0].slots.map(() => null)
    }
  }),
  editDimension: (id) => set((s) => {
    const d = s.dimensions.find((x) => x.id === id);
    if (!d) return {};
    return { dimDraft: { type: d.type, refs: [...d.refs], editId: d.id, name: d.name } };
  }),
  cancelDimDraft: () => set({ dimDraft: null }),
  // Slots re-shape with the type; whatever was chosen stays only if a slot of
  // the new type could still hold it — simplest is to start the slots over.
  setDimType: (type) => set((s) => ({
    dimDraft: { ...s.dimDraft, type, refs: flatDimensionTypeInfo(type).slots.map(() => null) }
  })),
  setDimName: (name) => set((s) => s.dimDraft ? { dimDraft: { ...s.dimDraft, name } } : {}),
  setDimRef: (slot, id) => set((s) => {
    if (!s.dimDraft) return {};
    const refs = [...s.dimDraft.refs];
    refs[slot] = id;
    return { dimDraft: { ...s.dimDraft, refs } };
  }),
  commitDim: () => set((s) => {
    const dd = s.dimDraft;
    if (!dd || dd.refs.some((r) => r === null)) return {};
    const group = flatDimensionTypeInfo(dd.type).group;
    const n = (s.dimCounts[group] ?? 0) + 1;
    const groupName = `${group === "distance" ? "Distance" : "Angle"} ${n}`;
    if (dd.editId !== void 0) {
      const old = s.dimensions.find((d) => d.id === dd.editId);
      if (!old) return { dimDraft: null };
      const typed = dd.name?.trim();
      const renamed = Boolean(typed) && typed !== old.name;
      const regroup = !renamed && flatDimensionTypeInfo(old.type).group !== group;
      return {
        dimensions: s.dimensions.map(
          (d) => d.id === dd.editId ? { ...d, type: dd.type, refs: dd.refs, name: regroup ? groupName : typed || old.name } : d
        ),
        dimCounts: regroup ? { ...s.dimCounts, [group]: n } : s.dimCounts,
        dimDraft: null
      };
    }
    const dim = {
      id: s.nextDimId,
      type: dd.type,
      name: groupName,
      refs: dd.refs,
      visible: true
    };
    return {
      dimensions: [...s.dimensions, dim],
      // The box stays open for the next one of the same type, its slots
      // empty — as the sketch's Dimension tool stays in hand — until
      // Cancel or Escape closes it.
      dimDraft: { type: dd.type, refs: flatDimensionTypeInfo(dd.type).slots.map(() => null) },
      nextDimId: s.nextDimId + 1,
      dimCounts: { ...s.dimCounts, [group]: n }
    };
  }),
  deleteDimension: (id) => set((s) => ({
    dimensions: s.dimensions.filter((d) => d.id !== id),
    dimDraft: s.dimDraft?.editId === id ? null : s.dimDraft
  })),
  toggleDimensionVisible: (id) => set((s) => ({
    dimensions: s.dimensions.map((d) => d.id === id ? { ...d, visible: !d.visible } : d)
  })),
  setAllDimensionsVisible: (visible) => set((s) => ({ dimensions: s.dimensions.map((d) => ({ ...d, visible })) })),
  counts: [],
  nextCountId: 1,
  startCount: () => set({ tool: { kind: "count", picks: [] } }),
  editCount: (id) => set((s) => {
    const c = s.counts.find((x) => x.id === id);
    return c ? { tool: { kind: "count", picks: [...c.picks], editId: id } } : {};
  }),
  cancelCount: () => set((s) => putAway(s, "count")),
  addCountPick: (px) => set((s) => {
    const t = toolOf(s, "count");
    return t ? { tool: { ...t, picks: [...t.picks, px] } } : {};
  }),
  undoCountPick: () => set((s) => {
    const t = toolOf(s, "count");
    return t ? { tool: { ...t, picks: t.picks.slice(0, -1) } } : {};
  }),
  finishCount: () => set((s) => {
    const t = toolOf(s, "count");
    if (!t) return {};
    if (t.picks.length === 0) return { tool: NO_TOOL };
    if (t.editId !== void 0) {
      return {
        counts: s.counts.map((c) => c.id === t.editId ? { ...c, picks: t.picks } : c),
        tool: NO_TOOL
      };
    }
    const id = s.nextCountId;
    const count = {
      id,
      name: `Count ${id}`,
      color: flatCountColor(id),
      picks: t.picks,
      visible: true
    };
    return { counts: [...s.counts, count], tool: NO_TOOL, nextCountId: id + 1 };
  }),
  deleteCount: (id) => set((s) => ({
    counts: s.counts.filter((c) => c.id !== id),
    tool: toolOf(s, "count")?.editId === id ? NO_TOOL : s.tool
  })),
  toggleCountVisible: (id) => set((s) => ({
    counts: s.counts.map((c) => c.id === id ? { ...c, visible: !c.visible } : c)
  })),
  renameCount: (id, name) => set(
    (s) => name.trim() === "" ? {} : { counts: s.counts.map((c) => c.id === id ? { ...c, name: name.trim() } : c) }
  ),
  notes: [],
  nextNoteId: 1,
  startNote: () => set({ tool: { kind: "note", editId: null } }),
  cancelNote: () => set((s) => putAway(s, "note")),
  addNote: (px) => set((s) => {
    const id = s.nextNoteId;
    return {
      notes: [...s.notes, { id, text: "", at: px, visible: true }],
      tool: { kind: "note", editId: id },
      nextNoteId: id + 1
    };
  }),
  editNote: (id) => set((s) => s.notes.some((n) => n.id === id) ? { tool: { kind: "note", editId: id } } : {}),
  setNoteText: (id, text) => set((s) => ({ notes: s.notes.map((n) => n.id === id ? { ...n, text } : n) })),
  moveNote: (id, px) => set((s) => ({ notes: s.notes.map((n) => n.id === id ? { ...n, at: px } : n) })),
  finishNote: () => set((s) => {
    const editId = toolOf(s, "note")?.editId ?? null;
    return {
      notes: s.notes.filter((n) => n.id !== editId || n.text.trim() !== ""),
      ...putAway(s, "note")
    };
  }),
  deleteNote: (id) => set((s) => ({
    notes: s.notes.filter((n) => n.id !== id),
    tool: toolOf(s, "note")?.editId === id ? NO_TOOL : s.tool
  })),
  toggleNoteVisible: (id) => set((s) => ({ notes: s.notes.map((n) => n.id === id ? { ...n, visible: !n.visible } : n) })),
  datum: null,
  // On while the alignment is being placed and after — the sheet rolls square
  // to the frame, and the grid is the ruling that shows where zero runs; a
  // checkbox puts it away.
  showGrid: true,
  turns: 0,
  mirror: false,
  profiles: loadProfiles(),
  elements: [],
  draft: null,
  nextId: 1,
  nameCounts: {},
  startDraft: (kind, method) => set({ draft: freshDraft(kind, method) }),
  // The element comes back exactly as it was made: its picks on the sheet for
  // a picked or region-fitted one, its slots filled for a construction.
  editElement: (id) => set((s) => {
    const el = s.elements.find((e) => e.id === id);
    if (!el) return {};
    const src = el.source;
    const base = freshDraft(el.kind, src.method, { editId: el.id, name: el.name });
    const draft = src.type === "picks" ? {
      ...base,
      picks: [...src.picks],
      tangents: tangentsFor(src.picks.length, src.tangents ?? []),
      closed: src.closed ?? false
    } : { ...base, refs: [...src.refs] };
    return { draft: { ...draft, ...evaluateDraft(draft, s.elements, s.pxPerMm) } };
  }),
  cancelDraft: () => set({ draft: null }),
  restartDraft: () => set((s) => s.draft && s.draft.editId === void 0 ? { draft: freshDraft(s.draft.kind, s.draft.method) } : {}),
  addDraftPick: (px) => set((s) => {
    if (!s.draft || flatMethod(s.draft.method).mode !== "pick") return {};
    const picks = flatMethod(s.draft.method).minPicks === 1 && s.draft.kind === "point" ? [px] : [...s.draft.picks, px];
    const draft = { ...s.draft, picks, tangents: tangentsFor(picks.length, s.draft.tangents) };
    return { draft: { ...draft, ...evaluateDraft(draft, s.elements, s.pxPerMm) } };
  }),
  insertDraftPick: (index, px) => set((s) => {
    if (!s.draft || flatMethod(s.draft.method).mode !== "pick") return {};
    const at2 = Math.max(0, Math.min(index, s.draft.picks.length));
    const picks = [...s.draft.picks.slice(0, at2), px, ...s.draft.picks.slice(at2)];
    const kept = tangentsFor(s.draft.picks.length, s.draft.tangents);
    const tangents = [...kept.slice(0, at2), null, ...kept.slice(at2)];
    const draft = { ...s.draft, picks, tangents };
    return { draft: { ...draft, ...evaluateDraft(draft, s.elements, s.pxPerMm) } };
  }),
  moveDraftPick: (index, px) => set((s) => {
    if (!s.draft || index < 0 || index >= s.draft.picks.length) return {};
    const picks = s.draft.picks.map((p, i) => i === index ? px : p);
    const draft = { ...s.draft, picks };
    return { draft: { ...draft, ...evaluateDraft(draft, s.elements, s.pxPerMm) } };
  }),
  removeDraftPick: (index) => set((s) => {
    if (!s.draft || index < 0 || index >= s.draft.picks.length) return {};
    const picks = s.draft.picks.filter((_, i) => i !== index);
    const tangents = tangentsFor(s.draft.picks.length, s.draft.tangents).filter((_, i) => i !== index);
    const draft = { ...s.draft, picks, tangents };
    return { draft: { ...draft, ...evaluateDraft(draft, s.elements, s.pxPerMm) } };
  }),
  clickDraftPin: (index) => {
    const s = get();
    if (!s.draft) return;
    const d = s.draft;
    if (d.kind === "spline" && index === 0 && !d.closed && d.picks.length >= flatPicksNeeded(d.method, true)) {
      s.setDraftClosed(true);
      return;
    }
    s.removeDraftPick(index);
  },
  setDraftTangent: (index, handle) => set((s) => {
    if (!s.draft || index < 0 || index >= s.draft.picks.length) return {};
    const tangents = tangentsFor(s.draft.picks.length, s.draft.tangents);
    tangents[index] = handle ? [handle[0], handle[1]] : null;
    const draft = { ...s.draft, tangents };
    return { draft: { ...draft, ...evaluateDraft(draft, s.elements, s.pxPerMm) } };
  }),
  freeDraftTangents: () => set((s) => {
    if (!s.draft) return {};
    const draft = { ...s.draft, tangents: tangentsFor(s.draft.picks.length, []) };
    return { draft: { ...draft, ...evaluateDraft(draft, s.elements, s.pxPerMm) } };
  }),
  setDraftClosed: (closed) => set((s) => {
    if (!s.draft || s.draft.closed === closed) return {};
    const draft = { ...s.draft, closed };
    return { draft: { ...draft, ...evaluateDraft(draft, s.elements, s.pxPerMm) } };
  }),
  addDraftPoints: (px) => set((s) => {
    if (!s.draft || !collectsEdgePoints(flatMethod(s.draft.method)) || px.length === 0) return {};
    const draft = { ...s.draft, picks: [...s.draft.picks, ...px] };
    return { draft: { ...draft, ...evaluateDraft(draft, s.elements, s.pxPerMm) } };
  }),
  noteDraftError: (message) => set((s) => s.draft ? { draft: { ...s.draft, error: message } } : {}),
  // For an edge draft this clears the lot: the unit of input was the dragged
  // region or the clicked stretch, and un-clicking one of its thousand
  // points would mean nothing.
  undoDraftPick: () => set((s) => {
    if (!s.draft) return {};
    const picks = collectsEdgePoints(flatMethod(s.draft.method)) ? [] : s.draft.picks.slice(0, -1);
    const draft = { ...s.draft, picks, tangents: tangentsFor(picks.length, s.draft.tangents) };
    return { draft: { ...draft, ...evaluateDraft(draft, s.elements, s.pxPerMm) } };
  }),
  setDraftRef: (slot, id) => set((s) => {
    if (!s.draft) return {};
    if (id !== null && flatBlockedRefs(s.draft.editId, s.elements).has(id)) return {};
    const refs = [...s.draft.refs];
    while (refs.length < slot) refs.push(null);
    refs[slot] = id;
    const draft = { ...s.draft, refs: flatConstructRefs(flatMethod(s.draft.method), refs) };
    return { draft: { ...draft, ...evaluateDraft(draft, s.elements, s.pxPerMm) } };
  }),
  setDraftMethod: (method) => set((s) => {
    if (!s.draft) return {};
    const { editId, name } = s.draft;
    return { draft: freshDraft(s.draft.kind, method, { editId, name }) };
  }),
  setDraftName: (name) => set((s) => s.draft ? { draft: { ...s.draft, name } } : {}),
  commitDraft: () => {
    const s = get();
    if (!s.draft?.fit) return null;
    const m = flatMethod(s.draft.method);
    const source = m.mode !== "construct" ? pickSource(s.draft) : { type: "construct", method: s.draft.method, refs: s.draft.refs };
    if (s.draft.editId !== void 0) {
      const editId = s.draft.editId;
      const name = s.draft.name?.trim();
      set({
        draft: null,
        elements: evaluateFlatElements(
          s.elements.map((e) => e.id === editId ? { ...e, name: name || e.name, source } : e),
          s.pxPerMm
        )
      });
      return editId;
    }
    const id = s.nextId;
    const count = (s.nameCounts[s.draft.kind] ?? 0) + 1;
    const element = {
      id,
      kind: s.draft.kind,
      name: `${FLAT_KIND_LABELS[s.draft.kind]} ${count}`,
      color: PALETTE[(id - 1) % PALETTE.length],
      source,
      fit: s.draft.fit,
      error: null,
      visible: true
    };
    set({
      elements: [...s.elements, element],
      draft: freshDraft(s.draft.kind, s.draft.method),
      nextId: id + 1,
      nameCounts: { ...s.nameCounts, [s.draft.kind]: count }
    });
    return id;
  },
  // Constructions referencing the deleted element keep their row and say why
  // they cannot be evaluated any more, exactly like the 3D side. Open editors
  // drop the reference; an editor open on the element itself closes.
  deleteElement: (id) => set((s) => {
    const dropRef = (r) => r === id ? null : r;
    const elements = evaluateFlatElements(
      s.elements.filter((e) => e.id !== id),
      s.pxPerMm
    );
    let draft = s.draft;
    if (draft?.editId === id) draft = null;
    else if (draft && draft.refs.includes(id)) {
      const next = { ...draft, refs: flatConstructRefs(flatMethod(draft.method), draft.refs.map(dropRef)) };
      draft = { ...next, ...evaluateDraft(next, elements, s.pxPerMm) };
    }
    return {
      elements,
      draft,
      dimDraft: s.dimDraft ? { ...s.dimDraft, refs: s.dimDraft.refs.map(dropRef) } : null
    };
  }),
  toggleElementVisible: (id) => set((s) => ({
    elements: s.elements.map((e) => e.id === id ? { ...e, visible: !e.visible } : e)
  })),
  setAllElementsVisible: (visible) => set((s) => ({
    elements: s.elements.map((e) => ({ ...e, visible })),
    counts: s.counts.map((c) => ({ ...c, visible })),
    notes: s.notes.map((n) => ({ ...n, visible }))
  })),
  beginImageLoad: (imageName) => set({ imageBusy: true, imageName }),
  // A new image adopts its own metadata scale — unless a measured calibration
  // is in force, which describes the scanner rather than the file and is
  // exactly the thing that should survive an image swap. The image goes on
  // the stage: a section that was there is stashed with what was measured
  // on it.
  finishImageLoad: (imageName, imageWidth, imageHeight, metaPxPerMm) => set((s) => {
    const onImage = s.subject.kind === "image";
    const image = onImage ? sheetOf(s) : s.sheets.image;
    const scale3 = image?.calSource === "measured" && image.pxPerMm ? { pxPerMm: image.pxPerMm, calSource: "measured" } : { pxPerMm: metaPxPerMm, calSource: metaPxPerMm ? "metadata" : "none" };
    const sheets = { ...s.sheets };
    if (!onImage) sheets[sheetKeyOf(s.subject)] = sheetOf(s);
    delete sheets.image;
    const kept = onImage ? s : image ?? freshSheet(null, "none");
    return {
      imageBusy: false,
      imageName,
      imageWidth,
      imageHeight,
      metaPxPerMm,
      imageVersion: s.imageVersion + 1,
      subject: { kind: "image" },
      subjectVersion: onImage ? s.subjectVersion : s.subjectVersion + 1,
      sheets,
      ...freshSheet(scale3.pxPerMm, scale3.calSource),
      nextId: kept.nextId,
      nextDimId: kept.nextDimId,
      nextCountId: kept.nextCountId,
      nextNoteId: kept.nextNoteId,
      ...STAGE_CLEARED
    };
  }),
  imageFailed: () => set({ imageBusy: false, imageName: null, imageWidth: 0, imageHeight: 0, metaPxPerMm: null }),
  beginEdges: () => set({ edgeStatus: "running" }),
  resolveEdges: (edgeCount) => set((s) => ({ edgeStatus: "ready", edgeCount, edgeVersion: s.edgeVersion + 1 })),
  failEdges: () => set((s) => ({ edgeStatus: "idle", edgeCount: 0, edgeVersion: s.edgeVersion + 1 })),
  setEdgeSensitivity: (edgeSensitivity) => set({ edgeSensitivity }),
  setShowEdges: (showEdges) => set({ showEdges }),
  setSnapToEdge: (snapToEdge) => set({ snapToEdge }),
  startDatum: () => set({ tool: { kind: "datum", picks: [] } }),
  cancelDatum: () => set((s) => putAway(s, "datum")),
  addDatumPick: (px) => set((s) => {
    const t = toolOf(s, "datum");
    if (!t) return {};
    const picks = [...t.picks, px];
    if (picks.length < 2) return { tool: { kind: "datum", picks } };
    return { datum: { originPx: picks[0], xRefPx: picks[1] }, tool: NO_TOOL };
  }),
  clearDatum: () => set((s) => ({ datum: null, ...putAway(s, "datum") })),
  setShowGrid: (showGrid) => set({ showGrid }),
  turnSheet: (quarters) => set((s) => ({ turns: ((s.turns + Math.round(quarters)) % 4 + 4) % 4 })),
  // The sheet is shown mirrored across its X axis and then turned; a mirror
  // across the screen's vertical is that with the turns run the other way,
  // and one across its horizontal is the same plus a half turn — so the
  // button flips what is on the screen whichever way round it is shown, and
  // Rotate 90° keeps turning the way it says afterwards.
  mirrorSheet: (way) => set((s) => ({
    mirror: !s.mirror,
    turns: ((way === "left-right" ? 2 - s.turns : -s.turns) % 4 + 4) % 4
  })),
  startCalibration: (mode) => set((s) => s.subject.kind === "image" ? { tool: { kind: "calibrate", mode, picks: [] } } : {}),
  cancelCalibration: () => set((s) => putAway(s, "calibrate")),
  addCalPick: (px) => set((s) => {
    const t = toolOf(s, "calibrate");
    if (!t) return {};
    const limit = t.mode === "distance" ? 2 : Infinity;
    const picks = t.picks.length < limit ? [...t.picks, px] : [...t.picks.slice(0, limit - 1), px];
    return { tool: { ...t, picks } };
  }),
  undoCalPick: () => set((s) => {
    const t = toolOf(s, "calibrate");
    return t ? { tool: { ...t, picks: t.picks.slice(0, -1) } } : {};
  }),
  applyCalibration: (trueMm) => {
    const s = get();
    const t = toolOf(s, "calibrate");
    if (!t) return "The calibration tool is not collecting.";
    if (s.subject.kind !== "image") return "A section is at true size already — there is nothing to calibrate.";
    try {
      const pxPerMm = t.mode === "distance" ? distanceCalibration(t.picks[0], t.picks[1], trueMm, {
        current: s.calSource === "measured" ? s.pxPerMm : null,
        splitAxes: s.splitAxes
      }) : diameterCalibration(t.picks, trueMm);
      set({
        pxPerMm,
        calSource: "measured",
        tool: NO_TOOL,
        elements: evaluateFlatElements(s.elements, pxPerMm)
      });
      return null;
    } catch (e) {
      if (e instanceof FitError) return e.message;
      throw e;
    }
  },
  setSplitAxes: (splitAxes) => set({ splitAxes }),
  saveProfile: (name) => set((s) => {
    const trimmed = name.trim();
    if (!trimmed || !s.pxPerMm) return {};
    const profiles = [
      ...s.profiles.filter((p) => p.name !== trimmed),
      { name: trimmed, pxPerMm: { ...s.pxPerMm } }
    ];
    storeProfiles(profiles);
    return { profiles };
  }),
  // A profile is a measured calibration by construction — applying one puts
  // the workspace in the calibrated state it was saved from.
  applyProfile: (name) => set((s) => {
    const p = s.profiles.find((x) => x.name === name);
    if (!p || s.subject.kind !== "image") return {};
    return {
      pxPerMm: { ...p.pxPerMm },
      calSource: "measured",
      elements: evaluateFlatElements(s.elements, p.pxPerMm)
    };
  }),
  deleteProfile: (name) => set((s) => {
    const profiles = s.profiles.filter((p) => p.name !== name);
    storeProfiles(profiles);
    return { profiles };
  })
}));
const NICE_STEPS = [1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10];
function niceCeil(x) {
  if (!(x > 0)) return 0.1;
  const exp = Math.floor(Math.log10(x));
  const m = x / Math.pow(10, exp);
  for (const step of NICE_STEPS) if (m <= step + 1e-9) return scaleByDecade(step, exp);
  return scaleByDecade(10, exp);
}
function scaleByDecade(step, exp) {
  const v = exp >= 0 ? step * Math.pow(10, exp) : step / Math.pow(10, -exp);
  const digits = Math.max(0, 1 - exp);
  return Number(v.toFixed(Math.min(digits, 100)));
}
const MIN_DEFLECTION_SCALE = 1;
const MAX_DEFLECTION_SCALE = 1e4;
const DEFAULT_MAP_FACING_DEG = 90;
const MAX_AUTO_RANGE = 1;
const DEFAULT_FACING_DEG = 60;
function probeSlice(set) {
  return {
    probes: [],
    nextProbeId: 1,
    addProbe: (point, value) => set((s) => ({
      probes: [...s.probes, { id: s.nextProbeId, point, value }],
      nextProbeId: s.nextProbeId + 1
    })),
    removeProbe: (id) => set((s) => ({ probes: s.probes.filter((p) => p.id !== id) })),
    clearProbes: () => set(() => ({ probes: [] }))
  };
}
const NO_VOLUME = { volume: null, volumeStatus: "idle", volumeMessage: null, volumeHover: null };
const CLEARED$1 = {
  alignStatus: "idle",
  align: null,
  alignMessage: null,
  alignStopping: false,
  globalAlign: null,
  mapStatus: "idle",
  referenceStatus: "idle",
  volume: null,
  volumeStatus: "idle",
  volumeMessage: null,
  volumeHover: null,
  stats: null,
  histogram: null,
  probes: [],
  picking: false,
  pairs: [],
  pendingScan: null,
  marking: false,
  maxDistanceAuto: true,
  // A new scan or a new reference starts at rest: the motion was a way of
  // looking at a map that has gone with them.
  animate: false
};
const NO_TARGET = {
  targetId: null,
  targetSide: 1,
  elementStatus: "idle"
};
function clearedReadout(shown) {
  return shown ? { stats: null, histogram: null, probes: [] } : {};
}
create()((set, get) => ({
  source: "reference",
  nominalName: null,
  nominalTriangles: 0,
  nominalVertices: 0,
  nominalBusy: false,
  nominalStep: null,
  nominalFromSession: false,
  // The pinned readings and their actions, shared with the thickness store.
  ...probeSlice(set),
  ...CLEARED$1,
  ...NO_TARGET,
  mapVersion: 0,
  mapOn: "scan",
  referenceVersion: 0,
  showVolume: true,
  elementVersion: 0,
  targetScope: "all",
  scopeCount: 0,
  scopeVersion: 0,
  targetFacingDeg: DEFAULT_FACING_DEG,
  mapFacingDeg: DEFAULT_MAP_FACING_DEG,
  // On, and it earns its place: the map is measured against a surface that is
  // nowhere on the part, so without the element drawn there is no way to see
  // where the zero of the scale actually is.
  showElement: true,
  // A millimetre: further than any residual a global fit leaves behind, closer
  // than the next feature on almost any part.
  localMaxDistance: 1,
  // The widest the scale ever opens by itself — see MAX_AUTO_RANGE. Starting
  // there rather than tighter means the first map a session measures is never
  // read off a scale narrower than the one the tool would have chosen.
  range: MAX_AUTO_RANGE,
  rangeAuto: true,
  maxDistance: 3,
  bands: null,
  tolerance: 0.1,
  showHistogram: false,
  // On by default: the reference appears the moment it is loaded so it can be
  // checked for being the right part, and stays visible through the alignment
  // so the fit can be watched. It is switched off once the map exists, since
  // by then the reading is on the scan and the ghost only gets in the way.
  showNominal: true,
  showScan: true,
  nominalSeeThrough: false,
  nominalMesh: false,
  nominalBackfaces: true,
  showMap: true,
  split: false,
  animScale: 10,
  animScaleAuto: true,
  // Both maps stay measured, so switching back and forth costs nothing. The
  // pinned readings do not: a reading off one map and a reading off the other
  // are both millimetres on the same part and look identical on it, so keeping
  // them would be a way to misread one for the other.
  setSource: (source) => set({ source, probes: [], stats: null, histogram: null }),
  // A different element is a different measurement — the map on the old one goes
  // with the choice, and the field itself is recomputed by whoever owns it.
  //
  // Choosing the element already in use has to be nothing at all, not a reset:
  // the map is recomputed off a change to the choice, so putting the status back
  // to idle when the choice has not moved would take the map away and leave
  // nothing to bring it back.
  setTarget: (targetId, side = 1) => set(
    (s) => s.targetId === targetId && s.targetSide === side ? {} : {
      ...NO_TARGET,
      targetId,
      targetSide: side,
      ...clearedReadout(s.source === "element")
    }
  ),
  flipTargetSide: () => set((s) => ({ targetSide: s.targetSide === 1 ? -1 : 1 })),
  setTargetFacing: (targetFacingDeg) => set({
    targetFacingDeg: targetFacingDeg === null ? null : Math.min(90, Math.max(1, targetFacingDeg))
  }),
  // Same bargain as the reference map: the suggested scale only takes effect
  // while the user has not overridden it.
  //
  // The scale and the pins belong to whichever map is being read, and this one
  // is also recomputed behind the reference map whenever the element it measures
  // against changes under it — so neither is touched unless it is this map's.
  resolveElementMap: (range, preserveProbes = false) => set((s) => ({
    elementStatus: "ready",
    elementVersion: s.elementVersion + 1,
    ...s.source === "element" ? { range: s.rangeAuto ? range : s.range, ...preserveProbes ? {} : { probes: [] } } : {}
  })),
  clearElementMap: () => set((s) => ({ ...NO_TARGET, ...clearedReadout(s.source === "element") })),
  setShowElement: (showElement) => set({ showElement }),
  setTargetScope: (targetScope) => set({ targetScope }),
  markScope: (scopeCount) => set((s) => ({ scopeCount, scopeVersion: s.scopeVersion + 1 })),
  clearScope: () => set((s) => ({ targetScope: "all", scopeCount: 0, scopeVersion: s.scopeVersion + 1 })),
  beginNominalLoad: (name) => set({ nominalBusy: true, nominalName: name, nominalStep: null, ...CLEARED$1 }),
  finishNominalLoad: (nominalName, nominalVertices, nominalTriangles, step = null, fromSession = false) => set({
    nominalBusy: false,
    nominalName,
    nominalVertices,
    nominalTriangles,
    nominalStep: step,
    nominalFromSession: fromSession,
    showNominal: true
  }),
  nominalFailed: () => get().clearNominal(),
  clearNominal: () => set({
    nominalBusy: false,
    nominalName: null,
    nominalVertices: 0,
    nominalTriangles: 0,
    nominalStep: null,
    nominalFromSession: false
  }),
  // Showing the reference again for the duration: the whole point of streaming
  // the intermediate poses is that the fit can be watched happening.
  beginAlign: () => set({ alignStatus: "running", alignMessage: null, alignStopping: false, showNominal: true }),
  stoppingAlign: () => set({ alignStopping: true }),
  // Back to whatever was true before the fit started. A stopped fit leaves no
  // trace: the pose it had reached is not a measurement, and the map (if any)
  // was measured under the alignment that is still standing.
  alignStopped: () => set((s) => ({
    alignStatus: s.align ? "done" : "idle",
    alignStopping: false,
    alignMessage: "Alignment stopped."
  })),
  // A new alignment invalidates the map that was measured under the old one.
  resolveAlign: (align) => set((s) => ({
    alignStatus: "done",
    align,
    alignMessage: null,
    alignStopping: false,
    // A local fit refines whatever whole-scan fit is in hand; it never
    // becomes the thing to fall back to.
    globalAlign: align.source === "local" ? s.globalAlign : align,
    mapStatus: "idle",
    referenceStatus: "idle",
    ...NO_VOLUME,
    stats: null,
    histogram: null,
    probes: []
  })),
  failAlign: (alignMessage) => set({ alignStatus: "failed", alignStopping: false, alignMessage }),
  // A local fit that refuses leaves the alignment it was refining exactly
  // where it was — only the message is new.
  failLocal: (alignMessage) => set({ alignStatus: "done", alignStopping: false, alignMessage }),
  // A measurement that refuses leaves no map behind — and must not tear down
  // the alignment it was measured under.
  failMap: (alignMessage) => set({ mapStatus: "idle", alignMessage }),
  clearAlign: (keepSearch = false) => set((s) => ({ ...CLEARED$1, ...keepSearch ? { maxDistanceAuto: s.maxDistanceAuto } : {} })),
  // Opening the tools arms nothing: the camera keeps its buttons until a
  // gesture is picked, and picking one is one click. The tools themselves are
  // put back to that state by whoever opens the session (App), because the
  // elements workspace opens the same ones.
  //
  // The motion stops: marking lands where the scan is, and a surface swinging
  // out from under the brush would be marked somewhere it is not drawn.
  startMarking: () => set({ marking: true, animate: false }),
  stopMarking: () => set({ marking: false }),
  setLocalMaxDistance: (d) => set({ localMaxDistance: Math.max(1e-4, d) }),
  // Back to the whole-scan fit, with the map it implies to be measured again.
  revertToGlobal: () => set(
    (s) => s.globalAlign ? {
      align: s.globalAlign,
      alignStatus: "done",
      alignMessage: null,
      mapStatus: "idle",
      referenceStatus: "idle",
      ...NO_VOLUME,
      stats: null,
      histogram: null,
      probes: []
    } : {}
  ),
  beginMap: () => set({ mapStatus: "running" }),
  // The suggested scale only takes effect while the user has not overridden it;
  // re-measuring a part they have already dialled in should not reset the view.
  resolveMap: (range, maxDistance) => set((s) => ({
    mapStatus: "ready",
    mapVersion: s.mapVersion + 1,
    range: s.rangeAuto ? range : s.range,
    maxDistance: s.maxDistanceAuto ? maxDistance : s.maxDistance,
    // The map is on the scan now, so the ghost stops earning its place —
    // unless the map is read on the reference.
    showNominal: s.mapOn === "reference",
    probes: []
  })),
  // The readout and the pins belong to the map on screen. Read on the
  // reference, the scan would hide it, and the other way round.
  setMapOn: (mapOn) => set(
    (s) => s.mapOn === mapOn ? {} : { mapOn, probes: [], stats: null, histogram: null, showScan: mapOn === "scan", showNominal: mapOn === "reference" ? true : s.mapStatus !== "ready" }
  ),
  beginReferenceMap: () => set({ referenceStatus: "running" }),
  resolveReferenceMap: () => set((s) => ({ referenceStatus: "ready", referenceVersion: s.referenceVersion + 1, ...s.mapOn === "reference" ? { probes: [] } : {} })),
  failReferenceMap: (alignMessage) => set({ referenceStatus: "idle", alignMessage }),
  clearReferenceMap: () => set({ referenceStatus: "idle", ...NO_VOLUME }),
  beginVolume: () => set({ volumeStatus: "running", volumeMessage: null }),
  // The regions are drawn in the map's red and blue: over the colour plot
  // they could not be told from it, so it is put away — one key on the view
  // bar brings it back.
  resolveVolume: (volume) => set({ volume, volumeStatus: "ready", volumeMessage: null, volumeHover: null, showVolume: true, showMap: false }),
  failVolume: (volumeMessage) => set({ volumeStatus: "idle", volumeMessage }),
  setShowVolume: (showVolume) => set({ showVolume }),
  setVolumeHover: (volumeHover) => set({ volumeHover }),
  setMapFacing: (mapFacingDeg) => set({ mapFacingDeg: mapFacingDeg === null ? null : Math.min(90, Math.max(1, mapFacingDeg)) }),
  setReadout: (stats, histogram) => set({ stats, histogram }),
  setRange: (range) => set({ range: Math.max(1e-4, range), rangeAuto: false }),
  setMaxDistance: (maxDistance) => set({ maxDistance: Math.max(1e-4, maxDistance), maxDistanceAuto: false }),
  setBands: (bands) => set({ bands }),
  setTolerance: (tolerance) => set({ tolerance: Math.max(1e-4, tolerance) }),
  setShowHistogram: (showHistogram) => set({ showHistogram }),
  setShowNominal: (showNominal) => set({ showNominal }),
  setShowScan: (showScan) => set({ showScan }),
  setNominalSeeThrough: (nominalSeeThrough) => set({ nominalSeeThrough }),
  setNominalMesh: (nominalMesh) => set({ nominalMesh }),
  setNominalBackfaces: (nominalBackfaces) => set({ nominalBackfaces }),
  setShowMap: (showMap) => set({ showMap }),
  // The left half is the scan, so opening the split view with the scan switched
  // off would open onto an empty half — the switch goes back on with it.
  setSplit: (split) => set(split ? { split, showScan: true } : { split }),
  setAnimate: (animate) => set({ animate }),
  setAnimScale: (animScale) => set({
    animScale: Math.min(MAX_DEFLECTION_SCALE, Math.max(MIN_DEFLECTION_SCALE, animScale)),
    animScaleAuto: false
  }),
  suggestAnimScale: (animScale) => set((s) => s.animScaleAuto ? { animScale } : {}),
  // The picker covers the viewport, and points are picked on the scan as it is.
  startPicking: () => set({ picking: true, pendingScan: null, animate: false }),
  stopPicking: () => set({ picking: false, pendingScan: null }),
  // Picks alternate: a point on the scan, then its counterpart on the nominal.
  addPickPoint: (side, point) => {
    const pending = get().pendingScan;
    if (side === "scan") {
      set({ pendingScan: point });
      return;
    }
    if (!pending) return;
    set((s) => ({ pairs: [...s.pairs, { scan: pending, nominal: point }], pendingScan: null }));
  },
  undoPair: () => set(
    (s) => s.pendingScan ? { pendingScan: null } : { pairs: s.pairs.slice(0, -1) }
  ),
  clearPairs: () => set({ pairs: [], pendingScan: null })
}));
const DEFAULT_CONE_ANGLE_DEG = 30;
const DEFAULT_NORMAL_DEVIATION_DEG = 60;
function defaultMaxThickness(bboxDiagonal) {
  return niceCeil(bboxDiagonal * 0.2);
}
const CLEARED = {
  status: "idle",
  message: null,
  stats: null,
  histogram: null,
  probes: []
};
create()((set) => ({
  // The pinned readings and their actions, shared with the deviation store.
  ...probeSlice(set),
  ...CLEARED,
  mapVersion: 0,
  method: "ray",
  maxThickness: 10,
  maxThicknessAuto: true,
  coneRays: 0,
  coneAngleDeg: DEFAULT_CONE_ANGLE_DEG,
  normalDeviationDeg: DEFAULT_NORMAL_DEVIATION_DEG,
  low: 0,
  high: 3,
  scaleAuto: true,
  bands: null,
  limit: 1,
  // A wall map is read for how much of the part is thin, not only where — so
  // the distribution stands beside the scale from the start.
  showHistogram: true,
  begin: () => set({ status: "running", message: null }),
  // The suggested scale only takes effect while the user has not overridden
  // it; re-measuring a part they have already dialled in should not reset the
  // view. The thin-wall limit is theirs from the start — it is a
  // specification, not a property of this particular scan.
  resolve: (low, high) => set((s) => ({
    status: "ready",
    message: null,
    mapVersion: s.mapVersion + 1,
    low: s.scaleAuto ? low : s.low,
    high: s.scaleAuto ? high : s.high,
    probes: []
  })),
  fail: (message) => set({ status: "idle", message }),
  setReadout: (stats, histogram) => set({ stats, histogram }),
  setMethod: (method) => set({ method }),
  setMaxThickness: (maxThickness) => set({ maxThickness: Math.max(1e-3, maxThickness), maxThicknessAuto: false }),
  suggestMaxThickness: (bboxDiagonal) => set((s) => s.maxThicknessAuto ? { maxThickness: defaultMaxThickness(bboxDiagonal) } : {}),
  setConeRays: (coneRays) => set({ coneRays }),
  setConeAngle: (coneAngleDeg) => set({ coneAngleDeg: Math.min(89, Math.max(0, coneAngleDeg)) }),
  setNormalDeviation: (normalDeviationDeg) => set({
    normalDeviationDeg: normalDeviationDeg === null ? null : Math.min(90, Math.max(0, normalDeviationDeg))
  }),
  // The two ends may not cross: a scale that runs backwards paints nothing
  // meaningful, so each end pushes the other ahead of it instead.
  setLow: (low) => set((s) => ({
    low: Math.max(0, low),
    high: Math.max(s.high, Math.max(0, low) + 1e-3),
    scaleAuto: false
  })),
  setHigh: (high) => set((s) => ({
    high: Math.max(1e-3, high),
    low: Math.min(s.low, Math.max(1e-3, high) - 1e-3),
    scaleAuto: false
  })),
  setBands: (bands) => set({ bands }),
  setLimit: (limit) => set({ limit: Math.max(1e-4, limit) }),
  setShowHistogram: (showHistogram) => set({ showHistogram }),
  clear: () => set({ ...CLEARED })
}));
create()((set) => ({
  workspace: "elements",
  setWorkspace: (workspace) => set({ workspace })
}));
create(() => ({ past: [], future: [], restoring: false, importing: false, revision: 0 }));
create(() => ({ running: null, progress: null }));
class CommandError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "CommandError";
  }
  toJSON() {
    return { code: this.code, message: this.message };
  }
}
let staleSince = null;
function markPageStale() {
  staleSince ??= (/* @__PURE__ */ new Date()).toISOString();
}
if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
  window.addEventListener("vite:preloadError", () => markPageStale());
}
const COMMAND_TIMEOUT_MS = 10 * 6e4;
Promise.resolve();
Promise.resolve();
function limited(name, ms, abort, run) {
  let timer;
  const late = new Promise((_, reject) => {
    timer = setTimeout(() => {
      const e = new CommandError(
        "timeout",
        `${name} did not finish in ${ms / 1e3} s and was given up on. It may have changed the session in part — read session.state (history.undo says the last step) before running it again.`
      );
      abort.abort(e);
      reject(e);
    }, ms);
  });
  let ran;
  try {
    ran = run();
  } catch (e) {
    ran = Promise.reject(e);
  }
  ran.catch(() => {
  });
  return Promise.race([ran, late]).finally(() => clearTimeout(timer));
}
export {
  COMMAND_TIMEOUT_MS,
  CommandError,
  limited
};
//# sourceMappingURL=registry.mjs.map
