import { create } from "zustand";
create(() => ({ running: null, progress: null }));
const busyChecks = /* @__PURE__ */ new Map();
const busyStores = /* @__PURE__ */ new Map();
const busyStops = /* @__PURE__ */ new Map();
function registerBusy(id, check, stores = [], stop) {
  if (busyChecks.has(id)) throw new Error(`Two busy checks share the id "${id}".`);
  busyChecks.set(id, check);
  busyStores.set(id, stores);
  if (stop) busyStops.set(id, stop);
  return () => {
    if (busyChecks.get(id) !== check) return;
    busyChecks.delete(id);
    busyStores.delete(id);
    busyStops.delete(id);
  };
}
function pluginBusy() {
  for (const check of busyChecks.values()) {
    try {
      const busy = check();
      if (busy) return busy;
    } catch {
    }
  }
  return null;
}
export {
  busyChecks,
  busyStops,
  busyStores,
  pluginBusy,
  registerBusy
};
//# sourceMappingURL=activity.mjs.map
