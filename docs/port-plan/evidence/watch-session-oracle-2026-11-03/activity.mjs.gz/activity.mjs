import { create } from "zustand";
create(() => ({ running: null, progress: null }));
const busyChecks = /* @__PURE__ */ new Map();
const busyStores = /* @__PURE__ */ new Map();
const busyStops = /* @__PURE__ */ new Map();
let sessionStores = [];
function watchSessionStores(stores) {
  sessionStores = stores;
  return () => {
    if (sessionStores === stores) sessionStores = [];
  };
}
function registerBusy(id, check, stores = [], stop) {
  if (busyChecks.has(id)) throw new Error(`Two busy checks share the id "${id}".`);
  busyChecks.set(id, check);
  busyStores.set(id, stores);
  if (stop) busyStops.set(id, stop);
  return () => {
    if (busyChecks.get(id) !== check) return;
    busyChecks.delete(id);
    busyStores.delete(id);
    busyStops.delete(id);
  };
}
function watchSession(listener, also = []) {
  const stops = [.../* @__PURE__ */ new Set([...sessionStores, ...also, ...[...busyStores.values()].flat()])].map((s) => s.subscribe(listener));
  return () => {
    for (const stop of stops) stop();
  };
}
export {
  registerBusy,
  watchSession,
  watchSessionStores
};
//# sourceMappingURL=activity.mjs.map
