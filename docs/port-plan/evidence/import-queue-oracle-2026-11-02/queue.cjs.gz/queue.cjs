"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImportQueue = void 0;
// SPDX-License-Identifier: AGPL-3.0-only
/** One queue for every import entry point. Project members are prepared inside
 *  their project's job, never enqueued as separate user imports. A failed job
 *  must not prevent the next file from opening. */
class ImportQueue {
    tail = Promise.resolve();
    pending = 0;
    listeners = new Set();
    get busy() { return this.pending > 0; }
    subscribe(listener) {
        this.listeners.add(listener);
        return () => { this.listeners.delete(listener); };
    }
    changed() { for (const listener of this.listeners)
        listener(); }
    run(job) {
        this.pending++;
        this.changed();
        const result = this.tail.then(job).finally(() => { this.pending--; this.changed(); });
        this.tail = result.then(() => { }, () => { });
        return result;
    }
}
exports.ImportQueue = ImportQueue;
//# sourceMappingURL=importQueue.js.map