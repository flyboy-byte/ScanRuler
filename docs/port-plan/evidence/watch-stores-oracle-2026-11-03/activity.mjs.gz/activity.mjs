import { create } from "zustand";
create(() => ({ running: null, progress: null }));
let sessionStores = [];
function watchSessionStores(stores) {
  sessionStores = stores;
  return () => {
    if (sessionStores === stores) sessionStores = [];
  };
}
export {
  sessionStores,
  watchSessionStores
};
//# sourceMappingURL=activity.mjs.map
