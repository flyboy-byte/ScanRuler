const sections = /* @__PURE__ */ new Map();
const briefs = /* @__PURE__ */ new Map();
function registerStateSection(id, describe, brief) {
  if (sections.has(id)) throw new Error(`Two state sections share the id "${id}".`);
  sections.set(id, describe);
  if (brief) briefs.set(id, brief);
  return () => {
    if (sections.get(id) === describe) {
      sections.delete(id);
      briefs.delete(id);
    }
  };
}
function readStateSections() {
  return readAll(sections);
}
function readStateBriefs() {
  return readAll(briefs);
}
function readAll(parts) {
  const out = {};
  for (const [id, describe] of parts) {
    try {
      out[id] = describe();
    } catch (e) {
      out[id] = { error: e instanceof Error ? e.message : String(e) };
    }
  }
  return out;
}
export {
  readStateBriefs,
  readStateSections,
  registerStateSection
};
//# sourceMappingURL=activity.mjs.map
