import { create } from "zustand";
const useCommandActivity = create(() => ({ running: null, progress: null }));
const commandRunning = () => useCommandActivity.getState().running !== null;
export {
  commandRunning,
  useCommandActivity
};
//# sourceMappingURL=activity.mjs.map
